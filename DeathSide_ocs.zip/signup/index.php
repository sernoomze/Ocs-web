<?php include "includes/functions.php"; ?>
<?php

if(isset($_POST['submit'])) {
    addUser();
}

?>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="DeathSide VPN">
    <meta name="author" content="DeathSide VPN">
    <title>DeathSide VPN</title>
    <!-- Bootstrap Core CSS -->
    <link rel="stylesheet" href="/signup/css/bootstrap.min.css" type="text/css">
    <!-- Custom Fonts -->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Merriweather:400,300,300italic,400italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="/signup/font-awesome/css/font-awesome.min.css" type="text/css">
    <!-- Plugin CSS -->
    <link rel="stylesheet" href="/signup/css/animate.min.css" type="text/css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="/signup/css/creative.css" type="text/css">
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
   
    <meta name="msapplication-TileColor" content="#ffffff">
    <meta name="msapplication-TileImage" content="img/favicon/ms-icon-144x144.png">
    <meta name="theme-color" content="#ffffff">
</head>
<body id="page-top">
    <nav id="mainNav" class="navbar navbar-default bg-dark navbar-fixed-top">
        <div class="container-fluid">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand page-scroll" href="/">
                   DeathSide VPN</a>
            </div>           
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right">
                    <li>
                        <a class="page-scroll" href="/">เข้าสู่ระบบ</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="https://fb.me/">FACEBOOK</a>
                    </li>
                </ul>
           </div>       
        </div>  
    </nav>
<section id="services">
         <div class="container">
            <div class="row">
				<div class="text-center">
<i class="fa fa-4x fa fa-user-secret bounceIn text-primary"></i>
<font color=red><h3><b>D e a t h S  i d e - V P N</h3></b></font>
                 <div class="text-center">
<font color=black><h3><b>[----- ยินดีต้อนรับ -----] </h3></b></font>
             </div>   
            </div>
        </div>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-6 col-md-offset-3">                  
					<div class="col-md-6">
						<form class="form-signin" method="POST">
							<div class="col-lg-12">				
								<div class="panel-body">		
									<div class="col-md-12">						
										<div class="form-group">
											<label for="username">ชื่อบัญชี</label>
												<input type="text" name="username" placeholder="Username ภาษาอังกฤษนะครับ " class="form-control"required>
											</div>
										<div class="form-group">
											<label for="email">Email</label>
												<input type="email" name="email" placeholder="Email ไม่เน้นใส่เท่ๆ" class="form-control" required>
											</div>
										<div class="form-group">
								 			<label for="firstname">First name</label>
				    							<input type="firstname" name="firstname" placeholder="First name ภาษาอังกฤษนะครับ" class="form-control" required>                     
              				 	 		 </div>
			   						  <div class="form-group">
				    						 <label for="lastname">Last name</label>
												<input type="lastname" name="lastname" placeholder="Last name ภาษาอังกฤษนะครับ" class="form-control" required>
                  							</div>
											<div class="form-group">
												<label for="password">รหัสผ่าน</label>
													<input type="password" name="password" placeholder="Password" class="form-control" required>
												</div>
													<div class="form-group">
														<label for="password_confirm">ยืนยันรหัสผ่าน</label>
															<input type="password" name="password_confirm" placeholder="Password Confirm" class="form-control" required>
													</div>
												<div class="form-group">						
													<button type="submit" name="submit" class="btn btn-success btn-block"><i class="fa fa-lock"></i> ยืนยันการสมัคร</button><br>
													<a class="btn btn-info btn-sm form-control" href="/"><i class="fa fa-unlock"></i> กลับไปหน้า LOGIN </a>
												</div>
											</div>
				   					</div>
								 </div>														
	                		</form>			                	
                      </div>               
               </div>
         </div>
<?php include "includes/footer.php"; ?>