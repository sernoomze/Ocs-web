<?php
$host = 'localhost';
$user = 'root';
$pass = 'ninjanum'; //ใส่รหัสครับ database
$db = 'sernoomze'; //ใส่ชื่อ database
$con = mysqli_connect($host,$user,$pass,$db);
mysqli_set_charset($con);