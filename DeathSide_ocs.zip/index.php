<?php

$f3 = require('lib/base.php');
$f3->config('config/inc.php');
$f3->config('config/route.php');
$f3->run();