<?php
    $connection = mysqli_connect("localhost", "root", "ninjanum", "deathside");    
    if (!$connection) {
        die("<br/>Database connection failed<br/>");
    }
?>