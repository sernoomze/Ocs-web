<?php die();

[globals]
AUTOLOAD="system/controller/;installation/"
UI="installation/"

 ?>