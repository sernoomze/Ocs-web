<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
  <div class="content-wrapper">
    <section class="content-header">
      <h1>
       <span class="description-text"><span style="font-size: 25px;"  class="badge bg-orange">TRUE MONEY</span></span>
      </h1>
    <ol class="breadcrumb">
        <li><a href="/main"><i class="fa fa-home"></i> หน้าหลัก</a></li>
        <li class="active">TRUE MONEY</li>
    </ol>
    </section>

    <section class="content">
       <div class="row">
	        <check if="{{ @message }}">     
				<div class="alert alert-{{ @message['type'] }} alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
               <i class="icon fa fa-info"></i>
                {{ @message['data'] }}
              </div>
            </check>
   
		  <div class="col-sm-6 col-md-4 col-lg-6">
          <div class="box box-widget widget-user">
         	<div class="widget-user-header bg-red">
              <h3 class="widget-user-username"> <B> USERNAME </B><span class="pull-right"><B> ยอดเงินคงเหลือ </span></h3>
              <h4 class="widget-user-desc"><span style="font-size: 16px;" class="badge bg-purple"><B>  {{ $me->username }} </B></span><span style="font-size: 16px;" class="pull-right badge bg-navy"><B>  {{ $me->saldo }} บาท </B></span></h4>
            </div>
            <div class="widget-user-image">
              <img class="img-circle" src="/bootstrap/asset/img/boy.png" alt="User Avatar">
            </div>
 
				 <div class="box-footer no-padding">
      	<div class="description-block"><br><br>
            <span class="description-text"><span style="font-size: 16px;"  class="badge bg-red">รายละเอียด</span></span>
         </div>
              <ul class="nav nav-stacked text-center">
                <li><a href="#"><B> <span style="font-size: 16px;" class="badge bg-aqua"> เติมผ่านบริการ true money มีค่าทำเนียม 14%. </span></B></span></a></li>
                <li><a href="#"> <span style="font-size: 16px;" class="badge bg-orange"> ตัวอย่าง เติม 50 บาท จะได้ 43 บาท </span></a></li>                                        
              </ul>
            </div>

	<div class="box-footer">
           <center><span class="description-text"><span style="font-size: 16px;"  class="badge bg-purple">กรอกหมายเลขบัตรเงินสด</span></span></center>
        <br >
    	<div class="form-group">
						<input name="tmn_password" type="number" id="tmn_password" maxlength="14" class="form-control" placeholder="กรอกบัตรทรูมันนี่ 14 หลัก">
				 <input name="ref1" type="hidden" value="{{ @me->id }}" id="ref1">
				 <input name="ref2" type="hidden" value="{{ @me->username }}" id="ref2">
				 <input name="ref3" type="hidden" value="{{ @me->email }}" id="ref3">    
					</div>
						<center><button type="button" class="btn btn-success btn-md" onclick="submit_tmnc()"><i class="fa fa-btc"></i> ยืนยันเติมเงิน</button>
           <a href="/main" class="btn btn-warning"><i class="fa fa-home"></i> ย้อนกลับ</a>
								</center>
	<div class="box-body">
<div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
<ol class="carousel-indicators">
<li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
<li data-target="#carousel-example-generic" data-slide-to="1" class=""></li>
<li data-target="#carousel-example-generic" data-slide-to="2" class=""></li>
</ol>
<div class="carousel-inner">
<div class="item active">
<img src="/topup/pic/21.png" alt="First slide">
<div class="carousel-caption">
</div>
</div>
<div class="item">
<img src="/topup/pic/20.png" alt="Second slide">
<div class="carousel-caption">
</div>
</div>
<a class="left carousel-control" href="#carousel-example-generic" data-slide="prev">
<span class="fa fa-angle-left"></span>
</a>
<a class="right carousel-control" href="#carousel-example-generic" data-slide="next">
<span class="fa fa-angle-right"></span>
</a>
</div>
 						</div>
					 </div>        
 				</div> 			                         
            </div>
          </div>
        </div>
      </div>
    </section>
</div>
 
