  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
                <?php if ($server->id): ?>
                    
                        <?php echo $server->servername; ?>
                    
                    <?php else: ?>
                        Add Server
                    
                <?php endif; ?>
      </h1>
      <ol class="breadcrumb">
                 <?php if ($server->id): ?>
                    
        <li><a href="/home"><i class="fa fa-dashboard"></i> หน้าหลัก</a></li>
        <li><a href="/home/admin/server">รายชื่อเซิร์ฟเวอร์</a></li>
        <li class="active">แก้ไข <?php echo $server->servername; ?></li>
                    
                    <?php else: ?>
                             <li><a href="/home"><i class="fa fa-dashboard"></i> หน้าหลัก</a></li>
        <li><a href="/home/admin/server">รายชื่อเซิร์ฟเวอร์</a></li>
        <li class="active">เพิ่มเซิร์ฟเวอร์</li>
                    
                <?php endif; ?>     
     
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">			
 		<div class="row">
        <div class="col-md-6">	
	        <?php if ($message): ?>     
				<div class="alert alert-danger alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <h4><i class="icon fa fa-info"></i><?php echo $message['type']; ?></h4>
                <?php echo $message['data']; ?>
              </div>
            <?php endif; ?>
        
		 <div class="box box-primary">
            <div class="box-header with-border">
               <i class="fa fa-user fa-fw"></i><h3 class="box-title"> Server Settings</h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->   

            <form role="form" action="<?php echo $URI; ?>" method="POST">
              <div class="box-body">
                        <div class="form-group">
                            <label>เซิร์ฟเวอร์</label>
                            <input class="form-control" placeholder="Singapore, Malaysia" name="country" type="text" value="<?php echo $server->country; ?>" required>
                        </div>
						<div class="form-group">
                            <label>ชื่อของ CLOUD VPS</label>
                            <input class="form-control" placeholder="Digital Ocean, Vultr" name="servername" type="text" value="<?php echo $server->servername; ?>" required>
                        </div>
                        <div class="form-group">
                            <label>Host</label>
                            <input class="form-control" placeholder="128.199.xxx.xx" name="host" type="text" value="<?php echo $server->host; ?>" required>
                        </div>
                        <div class="form-group">
                            <label>IP</label>
                            <input class="form-control" placeholder="SerNooMzE" name="ip" type="text" value="<?php echo $server->ip; ?>" required>
                        </div>
						<div class="form-group">
                            <label>OPENVPN PORT</label>
                            <input class="form-control" placeholder="1194" name="dropbear" type="text" value="<?php echo $server->dropbear; ?>" required>
                        </div>
						<div class="form-group">
                            <label>สมัครได้ต่อเดือน</label>
                            <input class="form-control" placeholder="50" name="limitacc" type="text" value="<?php echo $server->limitacc; ?>" required>
                        </div>
                        <div class="form-group">
                            <label>จำกัด VPN</label>
                            <input class="form-control" placeholder="1" name="limitvpn" type="text" value="<?php echo $server->limitvpn; ?>" required>
                        </div>
						<div class="form-group">
								<label>จำกัดวันใช้งาน</label>
                            <input class="form-control" placeholder="30" name="Exp" type="text" value="<?php echo $server->Exp; ?>" required>
								</div>
						<div class="form-group">
                      <label>Squid Port</label>
                      <input class="form-control" placeholder="8000, 8080, 3128" name="info" type="text" value="<?php echo $server->info; ?>" required>
                        </div>                 												
												<div class="form-group">
                            <label>ไฟล์ VPN</label>
                            <input class="form-control" placeholder="ovpn" name="config" type="text" value="<?php echo $server->config; ?>" required>
                        </div>            
                        <div class="form-group">
                            <label>ราคา/เดือน</label>
                            <div class="input-group">
                                <span class="input-group-addon">ราคา</span>
                                <input class="form-control" placeholder="10" name="price" type="number" step="1" value="<?php echo $server->price; ?>" required>
                            </div>
                        </div>
                        <div class="form-group">
                            <label>Root Password</label>
                            <input class="form-control" placeholder="root" name="root_pass" type="password">
                        </div>
						
              </div>
              <!-- /.box-body -->

              <div class="box-footer">
                <button type="submit" class="btn btn-primary">ยืนยัน</button>
                       <?php if ($server->id): ?>
                            <?php if ($server->active==1): ?>
                                
                                    <a href="<?php echo $URI.'/active/0'; ?>" class="btn btn-warning">เซิฟว่าง</a>
                                
                                <?php else: ?>
                                    <a href="<?php echo $URI.'/active/1'; ?>" class="btn btn-success">เซิฟเต็ม</a>
                                
                            <?php endif; ?>
                            <a href="<?php echo $URI.'/delete'; ?>" class="btn btn-danger hapus">ลบ</a>
                        <?php endif; ?>
                        <a href="/home/admin/server" class="btn btn-default">กลับ</a>
              </div>
            
            </form>
          </div>
          <!-- /.box -->
          </div>		           
         
     </div>	     
         
         
         
         
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->