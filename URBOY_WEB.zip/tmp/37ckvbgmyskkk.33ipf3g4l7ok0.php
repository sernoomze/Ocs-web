
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
     <section class="content-header">
     <h1><span class="description-text"><span style="font-size: 25px;"  class="badge bg-orange">Server List</span></span>
    <ol class="breadcrumb">
    <a href="<?php echo $URI; ?>/add" class="btn btn-info pull-right"><i class="fa fa-plus fa-fw"></i> Add Server</a>
    </ol>
     </h1>
     </section>

    <!-- Main content -->
    <section class="content">
    <div class="row">    
	        <?php if ($message): ?>     
				<div class="alert alert-<?php echo $message['type']; ?> alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
               <i class="icon fa fa-info"></i>
                <?php echo $message['data']; ?>
              </div>
            <?php endif; ?>

        <?php foreach (($servers?:array()) as $server): ?>
        
 <div class="col-sm-6 col-md-4 col-lg-3">
      <div class="box box-solid box-primary">
        <div class="box-header">
     <i class="icon fa fa-server"></i><h3 class="box-title"><b><?php echo $server->servername; ?></b> <?php echo $server->active==1?'':'( Locked )'; ?></h3>
    <div class="box-tools pull-right">
            <button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
    </div><!-- /.box-tools -->
        </div><!-- /.box-header -->
        <div class="box-body">
                    <table class="table">
                        <tr>
                            <td>Server</td><td><?php echo $server->country; ?></td>
                        </tr>
						<tr>
                            <td>ID SERVER</td><td><?php echo $server->id; ?></td>
                        </tr>
                        <tr>
                            <td>IP</td><td><?php echo $server->host; ?></td>
                        </tr>
                        <tr>
                            <td>HOST</td><td><?php echo $server->ip; ?></td>
                        </tr>
                        <tr>
                            <td>ราคา</td><td><?php echo $server->price; ?></td>
                        </tr>
                    </table>
        </div><!-- /.box-body -->
     
        <div class="box-footer text-center">                
                        <a href="<?php echo $URI.'/'.$server->id; ?>" class="btn btn-success"><i class="fa fa-edit fa-fw"></i> แก้ไข</a>
                        <a href="<?php echo $URI.'/'.$server->id; ?>/account" class="btn btn-warning"><i class="fa fa-group fa-fw"></i>เช็ครายชื่อ</a>                       
                 </div><!-- /.box-footer-->
     			   </div><!-- /.box -->
          </div>
		 <?php endforeach; ?>               
	</div>                

                                                            
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->