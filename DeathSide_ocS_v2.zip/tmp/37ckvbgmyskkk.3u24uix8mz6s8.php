<!DOCTYPE html>
<html lang="en-US">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>OceanVPN Panel Installer</title>
  <!-- Tell the browser to be responsive to screen width -->
   <meta name="theme-color" content="#29b6f6" />
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- CSS Design -->
	<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet" />
	<link href="/asset/bonveizen/plugins/jquery-ui/jquery-ui.min.css" rel="stylesheet" />
	<link href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" rel="stylesheet" />
	<link href="/asset/bonveizen/plugins/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" />
	<link href="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.8.5/css/mdb.min.css" rel="stylesheet">
	<link href="/asset/bonveizen/plugins/animate/animate.min.css" rel="stylesheet" />
	<!-- / CSS Design-->

	<!-- Javascript -->
	<script src="/asset/bonveizen/plugins/pace/pace.min.js"></script>
	<!-- / Javascript -->
	
    <link rel="stylesheet" type="text/css" href="//cdn.datatables.net/1.10.16/css/dataTables.bootstrap4.min.css">
    <link rel="stylesheet" type="text/css" href="//cdn.datatables.net/responsive/2.2.1/css/responsive.bootstrap4.min.css">

  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->
</head>

<body>
    <?php if ($PHP): ?>
    
    <div class="alert alert-danger alert-dismissible">
    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
    <i class="icon fa fa-info"></i><h1>Error !!</h1> 
    PHP Version must be higher than 5.3.4, Please upgrade your PHP Version to PHP 5.6
    </div>
     
     <?php else: ?>

	   <?php if ($message): ?>     
		<div class="alert alert-<?php echo $message['type']; ?> alert-dismissible">
       <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
        <i class="icon fa fa-info"></i>
          <?php echo $message['data']; ?>
         </div>
        <?php endif; ?>

<h1 class="page-header"><i class="fa fa-dragon cyan-text"></i> OceanVPN Installer</h1>
 <div class="col-md-8 col-lg-4">
 <div class="panel blue-gradient">
 <div class="panel-heading">
	<div class="panel-title text-white"><i class="fa fa-server"></i> Installation Wizard</div>
	</div>
	<div class="panel-body bg-white text-black">
   <form action="<?php echo $URI; ?>" method="POST">
     <div class="form-group has-feedback">
      <label>Database Host</label>
      <input class="form-control" placeholder="localhost" name="DB_HOST" type="text" value="localhost" required>
     <span class="glyphicon glyphicon-hdd form-control-feedback"></span>
      </div>

      <div class="form-group has-feedback">
                                            <label>Database Name</label>
                                            <input class="form-control" placeholder="OCSPanel" name="DB_NAME" type="text" required>
        <span class="glyphicon glyphicon-tasks form-control-feedback"></span>
      </div>
      <div class="form-group has-feedback">
                                            <label>Database User</label>
                                            <input class="form-control" placeholder="root" name="DB_USER" type="text">
        <span class="glyphicon glyphicon-user form-control-feedback"></span>
      </div>
          <div class="form-group has-feedback">
                                            <label>Database Pass</label>
                                            <input class="form-control" placeholder="Bonveio" name="DB_PASS" type="text">
        <span class="glyphicon glyphicon-lock form-control-feedback"></span>
      </div><br><br>
    <p class="login-box-msg"><i class="fa fa-user-secret"></i> Panel Administrator Settings</p>
    
       <div class="form-group has-feedback">
       <label>Username</label>
        <input class="form-control" placeholder="Admin" name="username" type="text" required>
        <span class="glyphicon glyphicon-user form-control-feedback"></span>
      </div>
      <div class="form-group has-feedback">
      <label>Email</label>
        <input class="form-control" placeholder="bon-chan@phcorner.net" name="email" type="text" required>
        <span class="glyphicon glyphicon-envelope form-control-feedback"></span>
      </div>
      <div class="form-group has-feedback">
      <label>New Password</label>
        <input class="form-control" placeholder="New Password" name="password" type="password" required>
        <span class="glyphicon glyphicon-lock form-control-feedback"></span>
      </div>
      <div class="form-group has-feedback">
      <label>Re-enter New Password</label>
        <input class="form-control" placeholder="Re-enter New Password" name="password_confirmation" type="password" required>
        <span class="glyphicon glyphicon-lock form-control-feedback"></span>
      </div>
      </div>
    
      <div class="panel-footer bg-white">
      <div align="right">
         <button class="btn blue-gradient btn-block text-white text-capitalize">Install</button>
      </div>
      </div>
    </form>

  </div></div>
          
       <?php endif; ?>
</div>


<script src="/plugins/jQuery/jquery-2.2.3.min.js"></script>
  <link rel="stylesheet" href="/asset/css/bootstrap.min.css">
<script src="/../plugins/iCheck/icheck.min.js"></script>
<script>
  $(function () {
    $('input').iCheck({
      checkboxClass: 'icheckbox_square-blue',
      radioClass: 'iradio_square-blue',
      increaseArea: '20%' // optional
    });
  });
</script>
</body>
</html>
