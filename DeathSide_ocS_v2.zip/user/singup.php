<!doctype html>
<html>
<head>
<title>Singup SSerNooMze VPN</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="author" content="SerNooMzE VPN">
<meta name="keywords" content="Install SerNooMze VPN"> 
<!-- font files  -->
<link href='//fonts.googleapis.com/css?family=Muli:400,300' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Nunito:400,300,700' rel='stylesheet' type='text/css'>
<!-- /font files  -->
<!-- css files -->
<link href="../asset/css/sb-admin-2.css" rel="stylesheet">
<link href="../css/style.css" rel='stylesheet' type='text/css' media="all" />
<!-- /css files -->
</head>
<body>

		<div class="log" align="center">
		<font color="red">
<check if="{{ @PHP }}">
                    <true>
                       <div class="content2 w3agile">
		 <form role="form">
		</form>
		<h3>			<?php 
if ($_POST) { 

//Setting
$lineapi = "GV7pLZkjIbOI48ChkjurrekdJV5WwlKpWdyPHVmpACB";

$singup =  "มีคนมาสมัครสมาชิกเจ้าค่ะ รายละเอียดการสมัคร";
$suser =  "ชื่อผู้ใช้";
$user =  trim($_POST['iuser']);
$spass =  "รหัสผ่าน";
$pass =  trim($_POST['ipass']);
$semail =  "อีเมล์";
$email =  trim($_POST['iemail']);

date_default_timezone_set("Asia/Bangkok");
//line Send

$chOne = curl_init(); 
curl_setopt( $chOne, CURLOPT_URL, "https://notify-api.line.me/api/notify"); 
// SSL USE 
curl_setopt( $chOne, CURLOPT_SSL_VERIFYHOST, 0); 
curl_setopt( $chOne, CURLOPT_SSL_VERIFYPEER, 0); 
//POST 
curl_setopt( $chOne, CURLOPT_POST, 1); 
// Message 
curl_setopt( $chOne, CURLOPT_POSTFIELDS, "message=$singup&message=$suser&message=$user&message=$spass&message=$pass&message=$semail&message=$email");
// follow redirects 
curl_setopt( $chOne, CURLOPT_FOLLOWLOCATION, 1); 
//ADD header array 
$headers = array( 'Content-type: application/x-www-form-urlencoded', 'Authorization: Bearer '.$lineapi.'', ); 
curl_setopt($chOne, CURLOPT_HTTPHEADER, $headers); 
//RETURN 
curl_setopt( $chOne, CURLOPT_RETURNTRANSFER, 1); 
$result = curl_exec( $chOne ); 
//Check error 
if(curl_error($chOne)) { echo 'error:' . curl_error($chOne); } 
else { $result_ = json_decode($result, true); 
echo "status : ".$result_['status']; echo "message : ". $result_['message']; } 
//Close connect 
curl_close( $chOne );      
}
?>
                        </h3>
	</div>
                    </true>
                    <false>
                        <check if="{{ @message }}">
                            <div class="content2 w3agile">
		 <form role="form">
		</form>กรุณากรอกข้อมูลให้ครบถ้วน  </h3>
	</div>
                        </check>
						</font>
	<div class="content2 w3agile">
		<h2>สมัครสมาชิก</h2>
		 <form role="form" method="post">
            <input type="text" name="iuser" value="ชื่อผู้ใช้/ชื่อมาสเตอร์" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'ชื่อผู้ใช้/ชื่อมาสเตอร์';}">
			<input type="email" name="iemail" value="อีเมล์" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'อีเมล์';}">
			<input type="text" name="ipass" value="รหัสผ่าน" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'รหัสผ่าน';}">
			<input type="text" name="password_confirmation" value="ยืนยันรหัสผ่านอีกครั้ง" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'ยืนยันรหัสผ่านอีกครั้ง';}">
			<button type="submit" class="register" value="สมัครสมาชิก">สมัครสมาชิก</button>
		</form>
                    </false>
                </check>
		<h3>หากคุณคิดว่ามาโดยหน้านี้โดยการผิดพลาดโปรด? <a href="../">คลิ๊กที่นี่</a></h3>
	</div>
</div>
<div class="footer">
	<p>© 2017 SerNooMzE All Rights Reserved </a></p>
</div>
    <script src="../asset/js/sb-admin-2.js"></script>
<script src="https://code.jquery.com/jquery-2.1.3.min.js"></script>
</body>
</html>