<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Server extends CI_Controller {
	public function __construct() {
		parent::__construct();
		$this->load->model('user_model');
		$this->load->model('server_model');
		$this->load->model('wallet_model');
		$this->load->model('openvpn_model');
		$this->load->model('log_model');
		$this->load->model('website_model');
		$this->load->helper('url_helper');
		$this->load->library(array('session'));
		$this->load->model('new_wallet_model');
	}
	private function _set_view($file, $init) {
		$data = new stdClass();
		$website_name = $this->website_model->get_website_name()['value'];
		$icon = $this->website_model->get_website_icon()['value'];
		if($website_name!=""){
			$data->websitename = $website_name;
		}
		if($icon!=""){
			$data->icon = $icon;
		}
		$this->load->view('base/header', $data);
		$this->load->view($file, $init);
        $this->load->view('base/footer', $data);
	}
	
	public function addServer(){
		if(isset($_SESSION['admin'])&&($_SESSION['admin']==true)){
			$data = new stdClass();
			
			$data->s_name 		= $this->input->post('s_name');
			$data->s_ip 		= $this->input->post('s_ip');
			$data->s_price 		= $this->input->post('s_price');
			$data->s_expire 	= $this->input->post('s_expire');
			$data->s_limit 		= $this->input->post('s_limit');
			$data->s_status 	= $this->input->post('s_status');
			$data->s_pass 		= $this->input->post('s_pass');
			
			$status = true;
			
			foreach($data as $d){
				if($d==""){
					$status = false;
				}
			}
			
			if($status==true){
				if($this->server_model->add_server($data)){
					echo "complete";
					
					$data_tmp['text'] = $_SESSION['username']." ได้เพิ่มเซิร์ฟเวอร์ ".$data->s_ip;
					$data_tmp['user'] = $_SESSION['username'];
					$data_tmp['date'] = $this->user_model->get_time_now();
					$this->log_model->insert_log($data_tmp);
				}
			}else{
				echo "emptyvalue";
			}
		}else{
			echo "notadmin";
		}
	}
	
	public function create_user_ssh(){
		if(empty($_SESSION['logged_in'])){
			echo "needlogin";
		}else{
			$data = new stdClass();
			$data->ssh_id = $this->input->post('ssh_id');
			$data->ssh_user = $this->input->post('ssh_user');
			$data->ssh_pass = $this->input->post('ssh_pass');
			
			$status = true;
			
			foreach($data as $d){
				if($d==""){
					$status = false;
				}
			}
			if($status==true){
				$row = $this->server_model->get_server_by_id($data->ssh_id);
				if(preg_match("/^[a-zA-Z0-9\-]+$/", $data->ssh_user)==1){
					if(preg_match("/^[a-zA-Z0-9\-]+$/", $data->ssh_pass)==1){
						if(strtolower($data->ssh_user)!="root"){
							if($this->server_model->check_ssh_user($data->ssh_user)){
								if($this->server_model->check_status_server($data->ssh_id)){
									if($this->server_model->checkConnect($data->ssh_id)){
										if($this->user_model->decrease_balance(($row->s_price))){
											if($this->server_model->create_user_ssh($data)){
												echo "complete";
												
												$data_tmp['text'] = $_SESSION['username']." ได้สมัครบัญชี ".$data->ssh_user;
												$data_tmp['user'] = $_SESSION['username'];
												$data_tmp['date'] = $this->user_model->get_time_now();
												$this->log_model->insert_log($data_tmp);
											}else{
												echo "incomplete";
											}
										}else{
											echo "notenough";
										}
									}else{
										echo "cannotcn";
									}
								}else{
									echo "full";
								}
							}else{
								echo "repeat";
							}
						}else{
							echo "mustnotroot";
						}
					}else{
						echo "engonly";
					}
				}else{
					echo "engonly";
				}
			}else{
				echo "emptyvalue";
			}
		}
	}
	
	public function open_server(){
		if(isset($_SESSION['admin'])&&($_SESSION['admin']==true)){
			$data = new stdClass();
			$data->s_id  = $this->input->post('s_id');
			$data->value = $this->input->post('value');
			if($this->server_model->open_server($data)){
				echo true;
				
				if($data->value==1){
					$s_tmp = "เปิด";
				}else{
					$s_tmp = "ปิด";
				}
				$data_tmp['text'] = $_SESSION['username']." ได้".$s_tmp."เซิร์ฟเวอร์ ".$data->s_id;
				$data_tmp['user'] = $_SESSION['username'];
				$data_tmp['date'] = $this->user_model->get_time_now();
				$this->log_model->insert_log($data_tmp);
			}
		}else{
			echo "notadmin";
		}
	}
	
	public function delserver(){
		if(isset($_SESSION['admin'])&&($_SESSION['admin']==true)){
			if($this->server_model->del_server($this->input->post('s_id'))){
				echo "true";
			}
		}else{
			echo "notadmin";
		}
	}
	
	public function getinfo(){
		$sid = $this->input->get('s_id');
		
		$row = $this->server_model->get_server_by_id($sid);
		
		$myJSON = json_encode($row, JSON_UNESCAPED_UNICODE);

		echo $myJSON;
	}
	
	public function update_server(){
		if(isset($_SESSION['admin'])&&($_SESSION['admin']==true)){
			$data = new stdClass();
				
			$data->s_id			= $this->input->post('s_id');
			$data->s_name 		= $this->input->post('s_name');
			$data->s_ip 		= $this->input->post('s_ip');
			$data->s_price 		= $this->input->post('s_price');
			$data->s_expire 	= $this->input->post('s_expire');
			$data->s_limit 		= $this->input->post('s_limit');
			$data->s_status 	= $this->input->post('s_status');
			$data->s_pass 		= $this->input->post('s_pass');
			
			$status = true;
			
			foreach($data as $d){
				if($d==""){
					$status = false;
				}
			}
			
			if($status==true){
				if($this->server_model->update_server($data)){
					echo "complete";
					
					$data_tmp['text'] = $_SESSION['username']." ได้แก้ไขเซิร์ฟเวอร์ ".$this->input->post('s_id');
					$data_tmp['user'] = $_SESSION['username'];
					$data_tmp['date'] = $this->user_model->get_time_now();
					$this->log_model->insert_log($data_tmp);
				}
			}else{
				echo "emptyvalue";
			}
		}else{
			echo "notadmin";
		}
	}
	
	public function addwallet(){
		if(empty($_SESSION['logged_in'])){
			redirect(base_url('/'));
		}else{
			if($_SESSION['admin']){
				if($this->wallet_model->get_wallet()){
					$data = new stdClass();
					$data->edit = $this->wallet_model->get_wallet();
					$this->_set_view('panel/addwallet', $data);
				}else{
					$data = new stdClass();
					$this->_set_view('panel/addwallet', $data);
				}
			}else{
				redirect(base_url('/main/addpoint'));
			}
		}
	}
	
	public function delwallet(){
		if(empty($_SESSION['logged_in'])){
			redirect(base_url('/'));
		}else{
			if($_SESSION['admin']){
				$this->wallet_model->del_wallet();
				$data = new stdClass();
				$data->message = '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a><strong>สำเร็จ!</strong> ลบวอเล็ทแล้ว</div>';	
				$this->_set_view('panel/addwallet', $data);
			}else{
				redirect(base_url('/main/addpoint'));
			}
		}
	}
	
	public function confirmaddwallet(){
		if(empty($_SESSION['logged_in'])){
			redirect(base_url('/'));
		}else{
			if($_SESSION['admin']){
				$data = new stdClass();
				$data->mobile		= $this->input->post('mobile');
				$data->pin			= $this->input->post('pin');
				
				if($this->wallet_model->get_wallet()){
					$data->message = '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a><strong>ผิดพลาด!</strong> มีเบอร์วอเล็ทอยู่แล้ว</div>';
					$data->edit = $this->wallet_model->get_wallet();
					$this->_set_view('panel/addwallet', $data);
				}else{
					if($this->wallet_model->add_wallet($data)){
						$data->message = '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a><strong>สำเร็จ!</strong> เพิ่มวอเล็ทแล้ว</div>';
						$data->edit = $this->wallet_model->get_wallet();
						$this->_set_view('panel/addwallet', $data);
					}
				}
			}else{
				redirect(base_url('/main/addpoint'));
			}
		}
	}
	
	public function confirmeditwallet(){
		if(empty($_SESSION['logged_in'])){
			redirect(base_url('/'));
		}else{
			if($_SESSION['admin']){
				$data = new stdClass();
				$data->mobile		= $this->input->post('mobile');
				$data->pin			= $this->input->post('pin');
				$data->ref_token	= $this->input->post('ref_token');
				if($this->wallet_model->update_wallet($data)){
					$data->message = '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a><strong>สำเร็จ!</strong> แก้ไขวอเล็ทแล้ว</div>';
					$data->edit = $this->wallet_model->get_wallet();
					$this->_set_view('panel/addwallet', $data);
				}else{
					redirect(base_url('/main/addpoint'));
				}
			}else{
				redirect(base_url('/main/addpoint'));
			}
		}
	}
	
	public function generate_ref_token(){
		if(empty($_SESSION['logged_in'])){
			$d['text'] = "notlogin";
			$d['code'] = 100;
			
			$d = json_encode($d, JSON_UNESCAPED_UNICODE);
			echo $d;
		}else{
			if($_SESSION['admin']){
				$tmp = $this->new_wallet_model->get_wallet();
				
				$this->new_wallet_model->setup($tmp->mobile, $tmp->pin);
				
				$row = $this->new_wallet_model->RequestLoginOTP();
				
				if(isset($row['code'])&&$row['code']==200){
					$_SESSION['truemoney_tmp']['get_otp'] = true;
					$_SESSION['truemoney_tmp']['mobile_number'] = $row['data']['mobile_number'];
					$_SESSION['truemoney_tmp']['otp_reference'] = $row['data']['otp_reference'];
					$_SESSION['truemoney_tmp']['data']['username'] = $tmp->mobile;
					$_SESSION['truemoney_tmp']['data']['password'] = $tmp->pin;
					
					$d['otp_reference'] = $row['data']['otp_reference'];
					$d['text'] = "sent";
					$d['code'] = 200;
					
					$d = json_encode($d, JSON_UNESCAPED_UNICODE);
					echo $d;
				}else{
					$d['text'] = $row['messageTh'];
					$d['code'] = 300;
					
					$d = json_encode($d, JSON_UNESCAPED_UNICODE);
					echo $d;
				}
			}else{
				$d['text'] = "notlogin";
				$d['code'] = 400;
				
				$d = json_encode($d, JSON_UNESCAPED_UNICODE);
				echo $d;
			}
		}
	}
	
	public function generate_ref_token_otp(){
		if(empty($_SESSION['logged_in'])){
			$d['text'] = "notlogin";
			$d['code'] = 100;
			
			$d = json_encode($d, JSON_UNESCAPED_UNICODE);
			echo $d;
		}else{
			if($_SESSION['admin']){
				$row = $this->new_wallet_model->SubmitLoginOTP($this->input->post('wallet_otp'), $_SESSION['truemoney_tmp']['mobile_number'], $_SESSION['truemoney_tmp']['otp_reference'], $_SESSION['truemoney_tmp']['data']);
				
				if(isset($row['code'])&&$row['code']==200){
					unset($_SESSION['truemoney_tmp']);
					
					$d['reference_token'] = $row['data']['reference_token'];
					$d['text'] = "";
					$d['code'] = 200;
					
					$d = json_encode($d, JSON_UNESCAPED_UNICODE);
					echo $d;
				}else{
					$d['text'] = $row['messageTh'];
					$d['code'] = 300;
					
					$d = json_encode($d, JSON_UNESCAPED_UNICODE);
					echo $d;
				}
			}else{
				$d['text'] = "notlogin";
				$d['code'] = 400;
				
				$d = json_encode($d, JSON_UNESCAPED_UNICODE);
				echo $d;
			}
		}
	}
	
	public function online($sid){
		if(empty($_SESSION['logged_in'])){
			redirect(base_url('/'));
		}else{
			$row = $this->server_model->get_server_by_id($sid);
			$d['hostname'] = $row->s_ip;
			$d['rootpass'] = $row->s_pass;
			
			$this->openvpn_model->create_openvpn_log($d, $sid);
			$data = new stdClass();
			$data->data = $this->openvpn_model->get_openvpn_log($sid);
			$data->servername = $row->s_name;
			$data->usage = $this->openvpn_model->get_server_usage($d);
			$this->_set_view('panel/server/online', $data);
		}
	}
	
	public function download(){
		if(empty($_SESSION['logged_in'])){
			redirect(base_url('/'));
		}else{
			$data = new stdClass();
			$data->row = $this->server_model->get_all_config();
			$this->_set_view('panel/server/download', $data);
		}
	}
	
	public function addfile(){
		if(empty($_SESSION['logged_in'])){
			redirect(base_url('/'));
		}else{
			if($_SESSION['admin']){
				$data = new stdClass();
				$data->row = $this->server_model->get_all_server();
				$this->_set_view('panel/server/addfile', $data);
			}else{
				redirect(base_url('/server/download'));
			}
		}
	}
	
	public function confirmaddfile(){
		if(empty($_SESSION['logged_in'])){
			redirect(base_url('/'));
		}else{
			if($_SESSION['admin']){
				if(pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION)!="ovpn"){
					$data = new stdClass();
					$data->row = $this->server_model->get_all_server();
					$data->message = '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a><strong>ผิดพลาด!</strong> อนุญาตไฟล์ ovpn เท่านั้น</div>';
					$this->_set_view('panel/server/addfile', $data);
				}else{
					$config['upload_path'] = "upload/";
					$config['allowed_types'] = '*';
					$this->load->library('upload', $config);
					if(!$this->upload->do_upload('file')){
						$data = new stdClass();
						$data->row = $this->server_model->get_all_server();
						$data->message = '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a><strong>ผิดพลาด!</strong> อัพโหลดไม่สำเร็จ</div>';
						$this->_set_view('panel/server/addfile', $data);
					}else{
						$data2 = array('upload_data' => $this->upload->data());
						$d['s_id'] = $this->input->post('s_id');
						$d['link'] = 'upload/'.$data2['upload_data']['file_name'];
						if($this->server_model->get_config_by_id($d['s_id'])){
							$this->server_model->update_config($d);
						}else{
							$this->server_model->insert_config($d);
						}
						$data = new stdClass();
						$data->row = $this->server_model->get_all_server();
						$data->message = '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a><strong>สำเร็จ!</strong> เพิ่มไฟล์แล้ว</div>';
						$this->_set_view('panel/server/addfile', $data);
					}
				}
			}else{
				redirect(base_url('/server/download'));
			}
		}
	}
	
	public function delfile($sid){
		if(isset($_SESSION['admin'])&&($_SESSION['admin']==true)){
			unlink($this->server_model->get_file_by_id($sid)->link);
			if($this->server_model->del_file($sid)){
				redirect(base_url('/server/download'));
			}else{
				redirect(base_url('/server/download'));
			}
		}else{
			redirect(base_url('/server/download'));
		}
	}
	
	public function sshuser($action=false, $user=false){
		if(empty($_SESSION['logged_in'])){
			redirect(base_url('/'));
		}else{
			if($action==false||$user==false){
				$data = new stdClass();
				$data->row = $this->server_model->get_ssh_user_by_user($_SESSION['username']);
				for($i=0;$i<count($data->row);$i++){
					$data->row[$i]['expire_at'] = $this->user_model->timeToDate($data->row[$i]['expire_at']);
				}
				$this->_set_view('panel/server/sshuser', $data);
			}else if($action=="renew"){
				if($_SERVER['REQUEST_METHOD'] == 'POST'){
					$user = $this->input->post('user');
					$date = $this->input->post('renew');
					$row = $this->server_model->get_ssh_user_by_id($user);
					if($row['create_by']==$_SESSION['username']){
						if($_SESSION['balance']>=$date){
							if($this->server_model->renew_user_ssh($user, $date)){
								if($this->user_model->decrease_balance($date)){
									$data = new stdClass();
									$data->row = $this->server_model->get_ssh_user_by_user($_SESSION['username']);
									for($i=0;$i<count($data->row);$i++){
										$data->row[$i]['expire_at'] = $this->user_model->timeToDate($data->row[$i]['expire_at']);
									}
									$data->message = '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a><strong></strong> ต่ออายุแล้ว</div>';
									$this->_set_view('panel/server/sshuser', $data);
								}else{
									$data = new stdClass();
									$data->row = $this->server_model->get_ssh_user_by_user($_SESSION['username']);
									for($i=0;$i<count($data->row);$i++){
										$data->row[$i]['expire_at'] = $this->user_model->timeToDate($data->row[$i]['expire_at']);
									}
									$data->message = '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a><strong></strong> ไม่สามารถหักเงินได้!!</div>';
									$this->_set_view('panel/server/sshuser', $data);
								}
							}else{
								redirect(base_url('/server/sshuser'));
							}
						}else{
							$data = new stdClass();
							$data->row = $this->server_model->get_ssh_user_by_user($_SESSION['username']);
							for($i=0;$i<count($data->row);$i++){
								$data->row[$i]['expire_at'] = $this->user_model->timeToDate($data->row[$i]['expire_at']);
							}
							$data->message = '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a><strong></strong> เงินไม่พอ!!</div>';
							$this->_set_view('panel/server/sshuser', $data);
						}
					}else{
						redirect(base_url('/server/sshuser'));
					}
				}else{
					$data = new stdClass();
					$data->user = $user;
					$data->expire = $this->user_model->timeToDate($this->server_model->get_ssh_user_by_id($user)['expire_at']);
					$this->_set_view('panel/admin/renew', $data);
				}
			}else if($action=="del"){
				$row = $this->server_model->get_ssh_user_by_id($user);
				if($row['create_by']==$_SESSION['username']){
					if($this->server_model->del_user_ssh($user)){
						$data = new stdClass();
						$data->row = $this->server_model->get_ssh_user_by_user($_SESSION['username']);
						for($i=0;$i<count($data->row);$i++){
							$data->row[$i]['expire_at'] = $this->user_model->timeToDate($data->row[$i]['expire_at']);
						}
						$data->message = '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a><strong></strong> ลบแล้ว</div>';
						$this->_set_view('panel/server/sshuser', $data);
					}else{
						redirect(base_url('/server/sshuser'));
					}
				}else{
					redirect(base_url('/server/sshuser'));
				}
			}else{
				$data = new stdClass();
				$data->row = $this->server_model->get_ssh_user_by_user($_SESSION['username']);
				for($i=0;$i<count($data->row);$i++){
					$data->row[$i]['expire_at'] = $this->user_model->timeToDate($data->row[$i]['expire_at']);
				}
				$this->_set_view('panel/server/sshuser', $data);
			}
			
		}
	}
}