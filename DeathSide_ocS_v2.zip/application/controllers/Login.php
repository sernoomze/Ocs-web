<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {
	public function __construct() {
		parent::__construct();
		$this->load->model('user_model');
		$this->load->model('log_model');
		$this->load->helper('url_helper');
		$this->load->model('website_model');
		$this->load->library(array('session'));
	}
	private function _set_view($file, $init) {
		$data = new stdClass();
		$website_name = $this->website_model->get_website_name()['value'];
		$icon = $this->website_model->get_website_icon()['value'];
		if($website_name!=""){
			$data->websitename = $website_name;
		}
		if($icon!=""){
			$data->icon = $icon;
		}
		$this->load->view('base/header', $data);
		$this->load->view($file, $init);
        $this->load->view('base/footer', $data);
	}
	public function logout() {
		if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true) {
			session_destroy();
		}
		redirect(base_url('/'));
	}
	public function login(){
		if(empty($this->input->post('username'))||empty($this->input->post('password'))){
			redirect(base_url('/'));
		}else{
			$user = $this->input->post('username');
			$password = $this->input->post('password');
			//if($this->user_model->check_login($user, $password)==true){ //old login
			if($this->user_model->login($user, $password)){
				$row = $this->user_model->get_info_user($user);
				if($row->active==false){
					echo "ban";
				}else{
					$_SESSION['logged_in'] = true;
					$_SESSION['username'] = $user;
					$_SESSION['admin'] = false;
					$_SESSION['balance'] = $row->balance;
					if($this->user_model->check_admin($user)==true){
						$_SESSION['admin'] = true;
					}
					$data['text'] = $_SESSION['username']." เข้าสู่ระบบ ";
					$data['user'] = $_SESSION['username'];
					$data['date'] = $this->user_model->get_time_now();
					$this->log_model->insert_log($data);
					echo true;
				}
			}else{
				echo false;
			}
		}
	}
	public function change_password(){
		if(empty($_SESSION['logged_in'])){
			redirect(base_url('/'));
		}else{
			if(empty($this->input->post('pwd_old'))||empty($this->input->post('pwd_new'))||empty($this->input->post('pwd_new_re'))){
				echo "empty";
			}else{
				if($this->input->post('pwd_new')!=$this->input->post('pwd_new_re')){
					echo 'notmatch';
				}else{
					if($this->user_model->check_password($_SESSION['username'], $this->input->post('pwd_old'))==false){
						echo "oldpasswrong";
					}else{
						if( strlen($this->input->post('pwd_new'))<6 ){
							echo "len6";
						}else{
							if($this->user_model->update_password($_SESSION['username'], $this->input->post('pwd_new'))){
								$data['text'] = $_SESSION['username']." เปลี่ยนรหัสผ่าน";
								$data['user'] = $_SESSION['username'];
								$data['date'] = $this->user_model->get_time_now();
								$this->log_model->insert_log($data);
								echo "ok";
							};
						}
					}
				}
			}
		}
	}
	
	public function get_profile(){
		$user = $this->user_model->get_info_user($this->input->post('username'));
		if($user){
			if($user->profile!=""){
				echo $user->profile;
			}else{
				echo base_url('/asset/img/profile/default.png');
			}
		}else{
			echo false;
		}
	}
	
	public function check_email(){
		echo $this->user_model->check_email($this->input->post('email'));
	}
}
