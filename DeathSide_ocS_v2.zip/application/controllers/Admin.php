<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {
	public function __construct() {
		parent::__construct();
		$this->load->model('user_model');
		$this->load->model('log_model');
		$this->load->model('wallet_model');
		$this->load->model('server_model');
		$this->load->model('website_model');
		$this->load->helper('url_helper');
		$this->load->library(array('session'));
	}
	private function _set_view($file, $init) {
		$data = new stdClass();
		$website_name = $this->website_model->get_website_name()['value'];
		$icon = $this->website_model->get_website_icon()['value'];
		if($website_name!=""){
			$data->websitename = $website_name;
		}
		if($icon!=""){
			$data->icon = $icon;
		}
		$this->load->view('base/header', $data);
		$this->load->view($file, $init);
        $this->load->view('base/footer', $data);
	}
	
	public function user($action=false, $user=false){
		if(empty($_SESSION['logged_in'])){
			redirect(base_url('/'));
		}else{
			if($_SESSION['admin']){
				if($_SERVER['REQUEST_METHOD'] == 'POST'){
					if($this->input->post('point')!=""){
						if($this->user_model->add_point_by_admin($this->input->post("user"),$this->input->post("point"))){
							$data = new stdClass();
							$data->row = $this->user_model->get_user();
							$data->message = '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a><strong></strong> เพิ่มพ้อยท์แล้ว</div>';
							$this->_set_view('panel/admin/user', $data);
						}else{
							redirect(base_url('/admin/user'));
						}
					}else{
						redirect(base_url('/admin/user'));
					}
				}else{
					if($action==false||$user==false){
						$data = new stdClass();
						$data->row = $this->user_model->get_user();
						$this->_set_view('panel/admin/user', $data);
					}else if($action=="ban"){
						if($this->user_model->ban_account($user)){
							$data = new stdClass();
							$data->row = $this->user_model->get_user();
							$data->message = '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a><strong></strong> แบน '.$user.' แล้ว</div>';
							$this->_set_view('panel/admin/user', $data);
						}else{
							redirect(base_url('/admin/user'));
						}
					}else if($action=="unban"){
						if($this->user_model->unban_account($user)){
							$data = new stdClass();
							$data->row = $this->user_model->get_user();
							$data->message = '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a><strong></strong> ปลดแบน '.$user.' แล้ว</div>';
							$this->_set_view('panel/admin/user', $data);
						}else{
							redirect(base_url('/admin/user'));
						}
					}else if($action=="del"){
						if($this->user_model->del_account($user)){
							$data = new stdClass();
							$data->row = $this->user_model->get_user();
							$data->message = '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a><strong></strong> ลบ '.$user.' แล้ว</div>';
							$this->_set_view('panel/admin/user', $data);
						}else{
							redirect(base_url('/admin/user'));
						}
					}else if($action=="addpoint"){
						$data = new stdClass();
						$data->user = $user;
						$data->balance = $this->user_model->get_info_user($user)->balance;
						$this->_set_view('panel/admin/addpoint', $data);
					}else{
						$data = new stdClass();
						$data->row = $this->user_model->get_user();
						$this->_set_view('panel/admin/user', $data);
					}
				}
			}else{
				redirect(base_url('/'));
			}
		}
	}
	
	public function sshuser($action=false, $user=false){
		if(empty($_SESSION['logged_in'])){
			redirect(base_url('/'));
		}else{
			if($_SESSION['admin']){
					if($action==false||$user==false){
						$data = new stdClass();
						$data->row = $this->server_model->get_all_ssh_user();
						for($i=0;$i<count($data->row);$i++){
							$data->row[$i]['expire_at'] = $this->user_model->timeToDate($data->row[$i]['expire_at']);
						}
						$this->_set_view('panel/admin/sshuser', $data);
					}else if($action=="del"){
						if($this->server_model->del_user_ssh($user)){
							$data = new stdClass();
							$data->row = $this->server_model->get_all_ssh_user();
							for($i=0;$i<count($data->row);$i++){
								$data->row[$i]['expire_at'] = $this->user_model->timeToDate($data->row[$i]['expire_at']);
							}
							$data->message = '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a><strong></strong> ลบแล้ว</div>';
							$this->_set_view('panel/admin/sshuser', $data);
						}else{
							redirect(base_url('/admin/sshuser'));
						}
					}else if($action=="renew"){
						if($_SERVER['REQUEST_METHOD'] == 'POST'){
							$user = $this->input->post('user');
							$date = $this->input->post('renew');
							if($this->server_model->renew_user_ssh($user, $date)){
								$data = new stdClass();
								$data->row = $this->server_model->get_all_ssh_user();
								for($i=0;$i<count($data->row);$i++){
									$data->row[$i]['expire_at'] = $this->user_model->timeToDate($data->row[$i]['expire_at']);
								}
								$data->message = '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a><strong></strong> ต่ออายุแล้ว</div>';
								$this->_set_view('panel/admin/sshuser', $data);
							}else{
								redirect(base_url('/admin/sshuser'));
							}
						}else{
							$data = new stdClass();
							$data->user = $user;
							$data->expire = $this->user_model->timeToDate($this->server_model->get_ssh_user_by_id($user)['expire_at']);
							$this->_set_view('panel/admin/renew', $data);
						}
					}else{
						$data = new stdClass();
						$data->row = $this->server_model->get_all_ssh_user();
						for($i=0;$i<count($data->row);$i++){
							$data->row[$i]['expire_at'] = $this->user_model->timeToDate($data->row[$i]['expire_at']);
						}
						$this->_set_view('panel/admin/sshuser', $data);
					}
			}else{
				redirect(base_url('/'));
			}
		}
	}
	
	public function ref(){
		if(empty($_SESSION['logged_in'])){
			redirect(base_url('/'));
		}else{
			if($_SESSION['admin']){
				$data = new stdClass();
				$data->row = $this->wallet_model->get_all_ref();
				$this->_set_view('panel/admin/ref', $data);
			}else{
				redirect(base_url('/'));
			}
		}
	}
	
	public function setting(){
		if(empty($_SESSION['logged_in'])){
			redirect(base_url('/'));
		}else{
			if($_SESSION['admin']){
				if($_SERVER['REQUEST_METHOD'] == 'POST'){
					$data = array(
						'line_token' => $this->input->post('token_line'),
						'website_name' => $this->input->post('website_name'),
						'website_icon' => $this->input->post('website_icon'),
						'website_url' => $this->input->post('website_url')
					);
					if($this->website_model->update_website_info($data)){
						$this->website_model->update_config_website($data['website_url']);
						$data = new stdClass();
						$data->line_token = $this->website_model->get_line_token()['value'];
						$data->website_name = $this->website_model->get_website_name()['value'];
						$data->website_icon = $this->website_model->get_website_icon()['value'];
						$data->website_url = $this->website_model->get_website_url()['value'];
						$data->message = '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a><strong></strong> อัพเดตเว็บไซต์แล้ว</div>';
						$this->_set_view('panel/admin/setting', $data);
					}else{
						$data = new stdClass();
						$data->line_token = $this->website_model->get_line_token()['value'];
						$data->website_name = $this->website_model->get_website_name()['value'];
						$data->website_icon = $this->website_model->get_website_icon()['value'];
						$data->website_url = $this->website_model->get_website_url()['value'];
						$data->message = '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a><strong></strong> มีบางอย่างผิดพลาด</div>';
						$this->_set_view('panel/admin/setting', $data);
					}
				}else{
					$data = new stdClass();
					$data->line_token = $this->website_model->get_line_token()['value'];
					$data->website_name = $this->website_model->get_website_name()['value'];
					$data->website_icon = $this->website_model->get_website_icon()['value'];
					$data->website_url = $this->website_model->get_website_url()['value'];
					$this->_set_view('panel/admin/setting', $data);
				}
			}else{
				redirect(base_url('/'));
			}
		}
	}
	
	public function backup_sql(){
		if(empty($_SESSION['logged_in'])){
			redirect(base_url('/'));
		}else{
			if($_SESSION['admin']){
		
				$path = $_SERVER["DOCUMENT_ROOT"]."/application/backup/";
				$webname = $this->website_model->get_website_name()['value'];
				if($webname == ""){
					$webname = "reseller";
				}
				$file = $webname.date('Y-m-j-H-i-s')."_".md5(microtime().mt_rand()).".zip";
				$this->load->dbutil();
				$backup = $this->dbutil->backup();
				$this->load->helper('file');
				write_file($path.$file, $backup);
				$this->load->helper('download');
				force_download($file, $backup);
			}
		}
	}
}
?>