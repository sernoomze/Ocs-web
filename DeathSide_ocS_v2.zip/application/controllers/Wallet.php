<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Wallet extends CI_Controller {
	public function __construct() {
		parent::__construct();
		$this->load->model('user_model');
		$this->load->helper('url_helper');
		$this->load->library(array('session'));
		$this->load->model('wallet_model');
		$this->load->model('log_model');
	}
	
	public function login(){
		if(empty($this->input->post('wallet_user'))||empty($this->input->post('wallet_psw'))||empty($this->input->post('wallet_type'))){
			echo "emptyvalue";
		}else{
			if(empty($_SESSION['truemoney'])){
				$this->wallet_model->setLogin($this->input->post('wallet_user'), $this->input->post('wallet_psw'), $this->input->post('wallet_type'));
				$token = $this->wallet_model->Login();
			
				if($token!=false){
					$profileimg = $this->wallet_model->Info($token)['profileImg'];
					if($profileimg=="https://s3-ap-southeast-1.amazonaws.com/profileimages-tewm/default-profile-image.png"){
						$_SESSION['truemoney']['profile'] = "/asset/img/wallet/iconfinder_user_925901.png";
					}else{
						$_SESSION['truemoney']['profile'] = $this->wallet_model->Info($token)['profileImg'];
					}
					$_SESSION['truemoney']['logged_in'] = true;
					$_SESSION['truemoney']['token'] = $token;
					$_SESSION['truemoney']['expire'] = $this->user_model->dateToTime($this->user_model->get_time_expire(5, 'minutes'));
					echo "login";
				}else{
					echo "wrong";
				}
			}
		}
	}
	
	public function logout(){
		if(isset($_SESSION['truemoney']['logged_in'])&&($_SESSION['truemoney']['logged_in']==true)){
			$this->wallet_model->Logout($_SESSION['truemoney']['token']);
			unset($_SESSION['truemoney']);
		}
		redirect(base_url('/truemoney/wallet'));
		
	}
	
	public function getlist(){
		$start = date('Y-m-d', strtotime('now' . "-" . 30 . " day"));
		$end = date('Y-m-d', strtotime('now'   . "+" . 1 . " day"));
		$row = $this->wallet_model->FetchActivities($_SESSION['truemoney']['token'], $start, $end);
		echo "<pre>";
		print_r($row);
		echo "</pre>";
	}
	public function get_detail(){
		$row = $this->wallet_model->FetchDetail($_SESSION['truemoney']['token'], $this->input->post('id'));
		$i = 1;
		$data = array();
		foreach($row as $key => $val ){
			$data[0]['title'] = $row['section1']['title'];
			if(empty($row['section1']['logo_url'])){
				$data[0]['value'] = "/asset/img/wallet/wallet-icon.png";
			}else{
				$data[0]['value'] = $row['section1']['logo_url'];
			}
			if(strpos($key, 'section') !== false){
				if($key != 'section1'){
					foreach($val as $subval){
						foreach($subval as $final => $final_v){
							if($final != "operator"){
								foreach($final_v as $fkey => $fval){
									if($fkey=="title"){
										$data[$i][$fkey] = $fval;
										$i++;
									}
									if($fkey=="value"){
										$data[$i-1][$fkey] = $fval;
									}
								}
							}
						}
					}
				}
			}
		}
		$tmp = "";
		for($i=0;$i<count($data);$i++){
			$d = new stdClass();
			$d->id = $i;
			$d->title = $data[$i]['title'];
			$d->value = $data[$i]['value'];
			$d = json_encode($d,JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
			if($tmp==""){
				$tmp = $d;
			}else{
				$tmp = $tmp.",".$d;
			}
		}
		echo "[".$tmp."]";
	}
	
	public function transfer(){
		if(isset($_SESSION['truemoney']['logged_in'])&&($_SESSION['truemoney']['logged_in']==true)){
			if(empty($this->input->post('wallet_number'))||empty($this->input->post('wallet_amount'))){
				echo "emptyvalue";
			}else{
				$tranid = $this->wallet_model->transaction_draft($_SESSION['truemoney']['token'], $this->input->post('wallet_number'), $this->input->post('wallet_amount'));
				$sendotp = $this->wallet_model->transaction_send_otp($_SESSION['truemoney']['token'], $tranid, $this->input->post('wallet_msg'));
				if($sendotp){
					$_SESSION['transfer']['transaction_id'] = $sendotp['data']['draftTransactionID'];
					$_SESSION['transfer']['amount'] 		= round($sendotp['data']['amount']);
					$_SESSION['transfer']['otpRefCode'] 	= $sendotp['data']['otpRefCode'];
					$_SESSION['transfer']['mobile'] 		= $sendotp['data']['mobileNumber'];
					echo $sendotp['data']['otpRefCode'];
				}
			}
		}
	}
	
	public function transfer_confirm(){
		if(isset($_SESSION['truemoney']['logged_in'])&&($_SESSION['truemoney']['logged_in']==true)){
			$transfer = $this->wallet_model->transaction_transfer($_SESSION['truemoney']['token'], $_SESSION['transfer']['mobile'], $_SESSION['transfer']['transaction_id'], $this->input->post('wallet_otp'), $_SESSION['transfer']['otpRefCode']);
			if($transfer==true){
				echo "ok";
				unset($_SESSION['transfer']['transaction_id']);
				unset($_SESSION['transfer']['amount']);
				unset($_SESSION['transfer']['mobile']);
				unset($_SESSION['transfer']['otpRefCode']);
			}else{
				echo "error";
			}
		}
	}
}
?>