<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Register extends CI_Controller {
	public function __construct() {
		parent::__construct();
		$this->load->model('user_model');
		$this->load->model('wallet_model');
		$this->load->model('server_model');
		$this->load->model('log_model');
		$this->load->model('website_model');
		$this->load->helper('url_helper');
		$this->load->library(array('session'));
	}
	private function _set_view($file, $init) {
		$data = new stdClass();
		$website_name = $this->website_model->get_website_name()['value'];
		$icon = $this->website_model->get_website_icon()['value'];
		if($website_name!=""){
			$data->websitename = $website_name;
		}
		if($icon!=""){
			$data->icon = $icon;
		}
		$this->load->view('base/header', $data);
		$this->load->view($file, $init);
        $this->load->view('base/footer', $data);
	}
	
	public function confirm_register(){
		if(!empty($_SESSION['logged_in'])){
			redirect(base_url('/'));
		}else{
			$user = $this->input->post('user');
			$pass = $this->input->post('pass');
			$pass_re = $this->input->post('pass_re');
			$email = $this->input->post('email');
			
			$valid = false;
			if($user==""||$pass==""||$email==""){
				$data = new stdClass();
				$data->message = '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a><strong>ผิดพลาด!</strong> กรอกให้ครบทุกช่อง</div>';
				$this->_set_view('register', $data);
			}else{
				if($this->user_model->check_user($user)){
					if(preg_match("/^[a-zA-Z0-9\-]+$/", $user)==1){
						if($pass==$pass_re){
							if(strlen($pass) >= 6){
								if($this->user_model->check_email($email)){
									$data = array(
										'user' => $user,
										'password' => $pass,
										'email' => $email
									);
									if($this->user_model->regis_account($data)){
										$data = new stdClass();
										$data->message = '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a><strong>สำเร็จ!</strong> สมัครบัญชีแล้ว<br> Username ของคุณคือ '.$user.'</div>';
										$this->_set_view('register', $data);
										
										$data_tmp['text'] = $user." ได้สมัครสมาชิก";
										$data_tmp['user'] = $user;
										$data_tmp['date'] = $this->user_model->get_time_now();
										$this->log_model->insert_log($data_tmp);
									}else{
										redirect(base_url('/register'));
									}
								}else{
									$data = new stdClass();
									$data->message = '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a><strong>ผิดพลาด!</strong> กรุณาใช้อีเมลล์อื่น</div>';
									$this->_set_view('register', $data);
								}
							}else{
								$data = new stdClass();
								$data->message = '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a><strong>ผิดพลาด!</strong> รหัสผ่านต้องไม่ต่ำกว่าหกตัว</div>';
								$this->_set_view('register', $data);
							}
						}else{
							$data = new stdClass();
							$data->message = '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a><strong>ผิดพลาด!</strong> รหัสผ่านไม่ตรงกัน</div>';
							$this->_set_view('register', $data);
						}
					}else{
						$data = new stdClass();
						$data->message = '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a><strong>ผิดพลาด!</strong> ใช้ภาษาอังกฤษและตัวเลขเท่านั้น</div>';	
						$this->_set_view('register', $data);
					}
				}else{
					$data = new stdClass();
					$data->message = '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a><strong>ผิดพลาด!</strong> กรุณาใช้ชื่ออื่น</div>';	
					$this->_set_view('register', $data);
				}
			}
		}
	}
}
