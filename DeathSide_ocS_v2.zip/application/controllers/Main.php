<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Main extends CI_Controller {
	
	private $tokenLine = false;
	
	public function __construct() {
		parent::__construct();
		$this->load->model('user_model');
		$this->load->model('wallet_model');
		$this->load->model('new_wallet_model');
		$this->load->model('line_model');
		$this->load->model('server_model');
		$this->load->model('log_model');
		$this->load->model('website_model');
		$this->load->helper('url_helper');
		$this->load->library(array('session'));
		if($this->line_model->get_token_db()){
			if($this->line_model->get_token_db()['value']!=""){
				$this->line_model->setToken($this->line_model->get_token_db()['value']);
				$this->tokenLine = true;
			}
		}
	}
	private function _set_view($file, $init) {
		$data = new stdClass();
		$website_name = $this->website_model->get_website_name()['value'];
		$icon = $this->website_model->get_website_icon()['value'];
		if($website_name!=""){
			$data->websitename = $website_name;
		}
		if($icon!=""){
			$data->icon = $icon;
		}
		$this->load->view('base/header', $data);
		$this->load->view($file, $init);
        $this->load->view('base/footer', $data);
	}
	public function index($action=false, $id=false){
		if(isset($_SESSION['admin'])&&$_SESSION['admin']==true){
			if($_SERVER['REQUEST_METHOD'] == 'POST'){
				if($this->website_model->add_msg($this->input->post('msg_notice'))){
					$data = new stdClass();
					if(!empty($_SESSION['logged_in'])){
						$this->user_model->set_session_balance();
					}
					$data->message = '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a><strong>สำเร็จ!</strong> เพิ่มข้อความแล้ว</div>';
					$data->msg = $this->website_model->get_msg_notice();
					$this->_set_view('index', $data);
				}else{
					redirect(base_url('/'));
				}
			}else{
				if($action==false||$id==false){
					$data = new stdClass();
					if(!empty($_SESSION['logged_in'])){
						$this->user_model->set_session_balance();
					}
					$data->msg = $this->website_model->get_msg_notice();
					$this->_set_view('index', $data);
				}else if($action=="delnotice"){
					if($this->website_model->del_msg($id)){
						$data = new stdClass();
						if(!empty($_SESSION['logged_in'])){
							$this->user_model->set_session_balance();
						}
						$data->message = '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a><strong>สำเร็จ!</strong> ลบแล้ว</div>';
						$data->msg = $this->website_model->get_msg_notice();
						$this->_set_view('index', $data);
					}else{
						$data = new stdClass();
						if(!empty($_SESSION['logged_in'])){
							$this->user_model->set_session_balance();
						}
						$data->message = '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a><strong></strong> มีบางอย่างผิดพลาด</div>';
						$data->msg = $this->website_model->get_msg_notice();
						$this->_set_view('index', $data);
					}
				}else{
					$data = new stdClass();
					if(!empty($_SESSION['logged_in'])){
						$this->user_model->set_session_balance();
					}
					$data->msg = $this->website_model->get_msg_notice();
					$this->_set_view('index', $data);
				}
			}
		}else{
			$data = new stdClass();
			if(!empty($_SESSION['logged_in'])){
				$this->user_model->set_session_balance();
			}
			$data->msg = $this->website_model->get_msg_notice();
			$this->_set_view('index', $data);
		}
	}
	public function server(){
		if(empty($_SESSION['logged_in'])){
			redirect(base_url('/'));
		}else{
			$this->server_model->del_expire_user();
			$data = new stdClass();
			$data->row = $this->server_model->get_all_server();
			
			for($i=0;$i<count($data->row);$i++){
				$data->row[$i]['user'] = $this->server_model->get_limit_user($data->row[$i]['s_id']);
			}
			$this->_set_view('panel/server/server', $data);
		}
	}
	
	public function register_account(){
		if(isset($_SESSION['logged_in'])){
			redirect(base_url('/'));
		}else{
			$data = new stdClass();
			$this->_set_view('register', $data);
		}
	}
	public function setting_account($user=false){
		if(empty($_SESSION['logged_in'])){
			redirect(base_url('/'));
		}else{
			if($user!=$_SESSION['username']){
				redirect(base_url('/panel/'.$_SESSION['username'].'/setting'));
			}else{
				$data = new stdClass();
				$this->_set_view('panel/setting', $data);
			}
		}
	}
	public function truemoney_wallet($page = false){
		if(empty($_SESSION['logged_in'])){
			redirect(base_url('/'));
		}else{
			$data = new stdClass();
			if(empty($_SESSION['truemoney']['logged_in'])){
				$this->_set_view('panel/wallet/login', $data);
			}else{
				if($this->user_model->dateToTime($this->user_model->get_time_now()) <= $_SESSION['truemoney']['expire']){
					$data->balance = $this->new_wallet_model->GetBalance($_SESSION['truemoney']['token'])['data']['currentBalance'];
					if($page == 'transfer'){
						$data->page = $page;
						$this->_set_view('panel/wallet/true_wallet', $data);
					}elseif($page == 'topup'){
						$data->page = $page;
						$this->_set_view('panel/wallet/true_wallet', $data);
					}else{
						$start = date('Y-m-d', strtotime('now' . "-" . 30 . " day"));
						$end = date('Y-m-d', strtotime('now'   . "+" . 1 . " day"));
						$row = $this->wallet_model->FetchActivities($_SESSION['truemoney']['token'], $start, $end);
						$data->row = $row;
						$data->page = "index";
						$this->_set_view('panel/wallet/true_wallet', $data);
					}
				}else{
					redirect(base_url('/wallet/logout'));
				}
			}
		}
	}
	
	public function addpoint(){
		if(empty($_SESSION['logged_in'])){
			redirect(base_url('/'));
		}else{
			if($this->wallet_model->get_wallet()){
				$data = new stdClass();
				$data->mobile = $this->wallet_model->get_wallet();
				$data->truewallet = false;
				if(isset($_SESSION['truemoney']['logged_in'])&&($_SESSION['truemoney']['logged_in']==true)){
					if($this->user_model->dateToTime($this->user_model->get_time_now()) <= $_SESSION['truemoney']['expire']){
						$data->truewallet = true;
					}
				}else{
					$this->new_wallet_model->generate_identity();
				}
				$this->_set_view('panel/addpoint', $data);
			}else{
				$data = new stdClass();
				$this->_set_view('panel/addpoint', $data);
			}
		}
	}
	
	public function newconfirmaddpoint(){
		if(empty($_SESSION['logged_in'])){
			$d['text'] = "notlogin";
			$d['code'] = 500;
			
			$d = json_encode($d, JSON_UNESCAPED_UNICODE);
			echo $d;
		}else{
			if(empty($this->input->post('wallet_amount'))){
				$d['text'] = "emptyvalue";
				$d['code'] = 100;
				
				$d = json_encode($d, JSON_UNESCAPED_UNICODE);
				echo $d;
			}else{
				if(empty($_SESSION['truemoney'])){
					$d['text'] = "notlogin";
					$d['code'] = 500;
					
					$d = json_encode($d, JSON_UNESCAPED_UNICODE);
					echo $d;
				}else{
					$mobile = $this->wallet_model->get_wallet()->mobile;
					$tranid = $this->new_wallet_model->DraftTransferP2P($_SESSION['truemoney']['token'], $mobile, $this->input->post('wallet_amount'));
					if($tranid['code']==200){
						$_SESSION['transfer']['wallet_msg'] = "";
						$_SESSION['transfer']['draftTransactionID'] = $tranid['data']['draftTransactionID'];
						$_SESSION['transfer']['referenceKey'] = $tranid['data']['referenceKey'];
						$_SESSION['transfer']['amount'] = $tranid['data']['amount'];
						
						$d['text'] = "";
						$d['recipientName'] = $tranid['data']['recipientName'];
						$d['mobileNumber'] = $tranid['data']['mobileNumber'];
						$d['amount'] = $tranid['data']['amount'];
						$d['code'] = 200;
						
						$d = json_encode($d, JSON_UNESCAPED_UNICODE);
						echo $d;
						
					}elseif($tranid['code']==1001){
						$d['text'] = $tranid['messageTh'];
						$d['code'] = 300;
						$d = json_encode($d, JSON_UNESCAPED_UNICODE);
						echo $d;
					}else{
						$d['text'] = "ผิดพลาด กรุณาตรวจสอบและลองอีกครั้ง";
						$d['code'] = 400;
						$d = json_encode($d, JSON_UNESCAPED_UNICODE);
						echo $d;
					}
				}
			}
		}
	}
	
	public function transfer_confirm(){
		if(isset($_SESSION['truemoney']['logged_in'])&&($_SESSION['truemoney']['logged_in']==true)){
			$row = $this->new_wallet_model->ConfirmTransferP2P($_SESSION['truemoney']['token'], $_SESSION['transfer']['wallet_msg'], $_SESSION['transfer']['draftTransactionID'], $_SESSION['transfer']['referenceKey']);
			if($row['code'] == 200){
				if($this->user_model->increase_balance($_SESSION['transfer']['amount'])){
					
					if($this->tokenLine){
						$this->line_model->addMsg('*******************************');
						$this->line_model->addMsg('🆔 : '.$_SESSION['username']);
						$this->line_model->addMsg('💵 : จำนวน '.$_SESSION['transfer']['amount'].' บาท');
						$this->line_model->addMsg('✔ : เติมเงินสำเร็จ');
						$this->line_model->addMsg('💵 : ยอดคงเหลือ '.$this->user_model->get_info_user($_SESSION['username'])->balance.' บาท');
						$this->line_model->addMsg('⏰ : '.$this->user_model->get_time_now());
						$this->line_model->addMsg('*******************************');
						$this->line_model->sendNotify();
					}
					
					$this->user_model->set_session_balance();
					echo "ok";
					unset($_SESSION['transfer']);
				}
			}else{
				echo "error";
			}
		}else{
			echo "error";
		}
	}
	
	public function confirmaddpoint(){
		if(empty($_SESSION['logged_in'])){
			redirect(base_url('/'));
		}else{
			$data = new stdClass();
			
			$tmp = $this->new_wallet_model->get_wallet();
			$tmp_data = array(
				"username" => $tmp->mobile,
				"password" => $tmp->pin,
				"reference_token" => $tmp->ref_token,
			);
			$tmp_nd = $this->new_wallet_model->Login($tmp_data);
			
			if(isset($tmp_nd['code'])&&$tmp_nd['code']==200){
				$token = $this->new_wallet_model->access_token;
			}else{
				$token = false;
			}
			
			if($this->wallet_model->update_ref($token)){
				$ref_no = $this->input->post('ref_no');
				if($this->wallet_model->check_ref_no($ref_no)==false){
					if($this->wallet_model->check_status($ref_no)){
						$point = $this->wallet_model->get_info_by_ref_no($ref_no);
						if($this->user_model->increase_balance($point->point)){
							if($this->tokenLine){
								$this->line_model->addMsg('*******************************');
								$this->line_model->addMsg('🆔 : '.$_SESSION['username']);
								$this->line_model->addMsg('💵 : จำนวน '.$point->point.' บาท');
								$this->line_model->addMsg('✔ : เติมเงินสำเร็จ');
								$this->line_model->addMsg('💵 : ยอดคงเหลือ '.$this->user_model->get_info_user($_SESSION['username'])->balance.' บาท');
								$this->line_model->addMsg('⏰ : '.$this->user_model->get_time_now());
								$this->line_model->addMsg('*******************************');
								$this->line_model->sendNotify();
							}
							
							$this->wallet_model->change_status($ref_no);
							$this->user_model->set_session_balance();
							$data->message = '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a><strong>สำเร็จ!</strong> เติมเงินแล้ว '.$point->point.' บาท<br>ยอดคงเหลือ : '.$this->user_model->get_info_user($_SESSION['username'])->balance.' บาท</div>';
							$data->mobile = $this->wallet_model->get_wallet();
							$data->truewallet = false;
							if(isset($_SESSION['truemoney']['logged_in'])&&($_SESSION['truemoney']['logged_in']==true)){
								if($this->user_model->dateToTime($this->user_model->get_time_now()) <= $_SESSION['truemoney']['expire']){
									$data->truewallet = true;
								}
							}else{
								$this->new_wallet_model->generate_identity();
							}
							$this->_set_view('panel/addpoint', $data);
							
							$data_tmp['text'] = $_SESSION['username']." เติมเงินเข้าสู่ระบบ เลขอ้างอิง ".$ref_no;
							$data_tmp['user'] = $_SESSION['username'];
							$data_tmp['date'] = $this->user_model->get_time_now();
							$this->log_model->insert_log($data_tmp);
						}else{
							redirect(base_url('/main/addpoint'));
						}
					}else{
						$data->message = '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a><strong>ผิดพลาด!</strong> เลขอ้างอิงนี้ถูกใช้ไปแล้ว</div>';
						$data->mobile = $this->wallet_model->get_wallet();
						$data->truewallet = false;
						if(isset($_SESSION['truemoney']['logged_in'])&&($_SESSION['truemoney']['logged_in']==true)){
							if($this->user_model->dateToTime($this->user_model->get_time_now()) <= $_SESSION['truemoney']['expire']){
								$data->truewallet = true;
							}
						}else{
							$this->new_wallet_model->generate_identity();
						}
						$this->_set_view('panel/addpoint', $data);
					}
				}else{
					$data->message = '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a><strong>ผิดพลาด!</strong> ไม่มีเลขอ้างอิงนี้ในระบบ</div>';
					$data->mobile = $this->wallet_model->get_wallet();
					$data->truewallet = false;
					if(isset($_SESSION['truemoney']['logged_in'])&&($_SESSION['truemoney']['logged_in']==true)){
						if($this->user_model->dateToTime($this->user_model->get_time_now()) <= $_SESSION['truemoney']['expire']){
							$data->truewallet = true;
						}
					}else{
						$this->new_wallet_model->generate_identity();
					}
					$this->_set_view('panel/addpoint', $data);
				}
			}else{
				if($this->tokenLine){
					$this->line_model->addMsg('*******************************');
					$this->line_model->addMsg("✖ : ไม่สามารถเข้าสู่ระบบวอเล็ทได้ ");
					$this->line_model->addMsg("✖ : แก้ไขทรูวอเล็ท");
					$this->line_model->addMsg("🌍 : ".base_url('/'));
					$this->line_model->addMsg('*******************************');
					$this->line_model->sendNotify();
				}
				
				$data->message = '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a><strong>ผิดพลาด!</strong> ไม่สามารถเข้าสู่ระบบวอเล็ทได้ <br> กรุณาแจ้งแอดมิน</div>';
				$data->mobile = $this->wallet_model->get_wallet();
				$data->truewallet = false;
				if(isset($_SESSION['truemoney']['logged_in'])&&($_SESSION['truemoney']['logged_in']==true)){
					if($this->user_model->dateToTime($this->user_model->get_time_now()) <= $_SESSION['truemoney']['expire']){
						$data->truewallet = true;
					}
				}else{
					$this->new_wallet_model->generate_identity();
				}
				$this->_set_view('panel/addpoint', $data);
			}
		}
	}
}
