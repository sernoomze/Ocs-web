<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
	<div style="clear:both"></div>
	<p style="padding-bottom:50px"></p>
	</div>
	<footer class="main-footer text-center" id="footer">
		<strong style="padding-left: 50px;" class="text-center">
			<a href="/"><?php if(isset($websitename)) echo $websitename; else echo "Reseller VPN";?></a> Copyright © 2019-<?=date('Y')?>
		</strong>
		<br>
		<div id="credit-web"></div>
	</footer>
	<script>
		$('#credit-web').html('');
	</script>
</body>
</html>