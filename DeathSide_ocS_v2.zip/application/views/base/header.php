<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <!--<title><?php if(isset($title)): echo $title; else: echo "Reseller VPN"; endif; ?></title>-->
  <?php if(isset($websitename)): ?>
  <title><?=$websitename?></title>
  <?php else: ?>
  <title>Reseller VPN</title>
  <?php endif; ?>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <link href="https://fonts.googleapis.com/css?family=Kanit" rel="stylesheet">
  <?php if(isset($icon)): ?>
  <link rel="shortcut icon" href="<?=$icon?>" title="Favicon"/>
  <?php else: ?>
  <link rel="shortcut icon" href="<?=base_url('/asset/img/ico/favicon.png')?>" title="Favicon"/>
  <?php endif; ?>
  <link rel="stylesheet" href="<?=base_url('/asset/main.css?t='.date('m-s'))?>">
  <link rel="stylesheet" href="<?=base_url('/asset/modal.css?t='.date('m-s'))?>">
  <link rel="stylesheet" href="<?=base_url('/asset/server.css?t='.date('m-s'))?>">
  <link rel="stylesheet" href="<?=base_url('/asset/server_checkbox.css?t='.date('m-s'))?>">
  <link rel="stylesheet" href="<?=base_url('/asset/setting.css?t='.date('m-s'))?>">
  <link rel="stylesheet" href="<?=base_url('/asset/index.css?t='.date('m-s'))?>">
  <link rel="stylesheet" href="<?=base_url('/asset/wallet.css?t='.date('m-s'))?>">
  <script src="<?=base_url('/asset/js/bootstrap.min.js?t='.date('m-s'))?>"></script>
  <script>
	function sleep(time){
	  return new Promise((resolve) => setTimeout(resolve, time));
	}
  </script>
</head>
<body>
	<div id="wrapper" class="">
		<div id="sidebar-wrapper">
			<ul class="sidebar-nav" id="sidebar">
				<li class="head-web-new"><i class="fa fa-home"></i><a href="<?=base_url('/')?>"><?php if(isset($websitename)) echo $websitename; else echo "Reseller VPN";?></a></li>
				<?php if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true): ?>
				<li class="user">
					<span class="label label-info text-black">
						<?=$_SESSION['username']?>
					</span>
					<a>
						<i class="fa fa-user-circle-o"></i>
					</a>
					<span>&nbsp;|</span>
					<span class="label label-success text-black">
						<?php if($_SESSION['admin']==true): echo "admin"; else: echo "member"; endif;?>
					</span>
				</li>
				<div style="clear: both;"></div>
				<li class="user" data-toggle="tooltip" data-placement="right">
					<span class="label bg-red1 text-black">
						ยอดคงเหลือ
					</span>
					<a><i class="fa fa-money"></i></a>
					<span>&nbsp;|</span> 
					<span class="label label-warning text-black">
						<?=$_SESSION['balance']?>
					</span>
				</li>
				<?php endif; ?>
				<?php if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true): ?>
				<li class="bg-drop"><small>เมนู</small></li>
				<li><a href="<?=base_url('/main/server')?>">เซิร์ฟเวอร์ <i class="fa fa-th-list"></i></a></li>
				<li><a href="<?=base_url('/truemoney/wallet')?>">True Wallet<i class="wallet-ico"><img src="/asset/img/wallet/wallet-icon-32x32-2.png"></i></a></li>
				<li><a href="<?=base_url('/main/addpoint')?>">เติมเงิน<i class="fa fa-credit-card"></i></a></li>
				<!--<li><a>link3 <i class="fa fa-question-circle-o"></i></a></li>-->
				<li><a href="<?=base_url('/server/download')?>">ดาวน์โหลดไฟล์ <i class="fa fa-cloud-download"></i></a></li>
				<li><a href="<?=base_url('/server/sshuser')?>">จัดการบัญชี <i class="fa fa-address-book-o"></i></a></li>
				<li><a href="<?=base_url('/panel/'.$_SESSION['username'].'/setting')?>">ตั้งค่า <i class="fa fa-wrench"></i></a></li>
				<?php if($_SESSION['admin']==true): ?>
				<li data-toggle="collapse" data-target="#demo"><a>เมนูแอดมิน<i class="fa fa-list-ul"></i></a>
					<ul id="demo" class="collapse">
						<li><a href="<?=base_url('/admin/user')?>"><i class="fa fa-group"></i> แสดงผู้ใช้</a></li>
						<li><a href="<?=base_url('/admin/sshuser')?>"><i class="fa fa-users"></i> แสดงผู้ใช้ openvpn</a></li>
						<li><a href="<?=base_url('/server/addwallet')?>"><i class="fa fa-users"></i>  แก้ไขเบอร์วอเล็ท</a></li>
						<li><a href="<?=base_url('/server/addfile')?>"><i class="fa fa-users"></i>  เพิ่มไฟล์ Config</a></li>
						<li><a href="<?=base_url('/admin/ref')?>"><i class="fa fa-users"></i> ดูรายการรับเงิน</a></li>
						<li><a href="<?=base_url('/admin/setting')?>"><i class="fa fa-users"></i> ตั้งค่าเว็บไซต์</a></li>
						
					</ul>
				</li>
				<?php endif; ?>
				<li><a href="<?=base_url('/logout')?>">ออกจากระบบ <i class="fa fa-sign-out"></a></i></li>
				<?php else: ?>
				<li><a href="<?=base_url('/register')?>">สมัครบัญชี <i class="fa fa-user-plus"></i></a></li>
				<li data-toggle="modal" data-target="#ModalLogin" id="login_b"><a>เข้าสู่ระบบ <i class="fa fa-sign-in"></i><a></li>
				<?php endif; ?>
			</ul>
		</div>
		<nav class="navbar navbar-inverse">
		  <div class="container-fluid">
			<div class="navbar-header">
			  <a class="navbar-brand" href="#" id="menu-toggle"><span class="glyphicon glyphicon-menu-hamburger"></span> Menu </a>
			</div>
		  </div>
		</nav>
		<?php if(empty($_SESSION['logged_in'])): ?>
		<center>
		<div id="ModalLogin" class="modal fade" role="dialog">
		  <div class="modal-dialog" style="width:300px;margin-top:10%">
			<div class="modal-content">
			  <div class="modal-body">
				<h3>ลงชื่อเข้าสู่ระบบ</h3>
				<hr>
				<center>
					<img src="<?=base_url('/asset/img/profile/default.png')?>" width="100px" id="profile-login">
				</center>
				<hr>
				  <div class="form-group">
					<label for="username">Username:</label>
					<input type="text" class="form-control" id="username">
				  </div>
				  <div class="form-group">
					<label for="pwd">Password:</label>
					<input type="password" class="form-control" id="pwd">
				  </div>
				  <center>
				  <!--<div class="checkbox">
					<label><input type="checkbox"> Remember me</label>
				  </div>-->
				  <button type="button" class="btn btn-default" id="login_submit">Login</button></center>
			  </div>
			  <div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">ปิด</button>
			  </div>
			</div>
		  </div>
		</div>
		</center>
		<script>
		</script>
		<?php else: ?>
		<script>
		</script>
		<?php endif; ?>
		<!---------------------------------------------------------------------------------------------->
		<!-- Modal -->
		<center>
			<div class="modal fade" id="success" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
				<div class="modal-dialog" role="document" style="width:300px;margin-top:10%">
					<div class="modal-content">
						<div class="modal-body">
							<button type="button" class="close" data-dismiss="modal" aria-label="Close">
								<span aria-hidden="true">&times;</span>
							</button>
							<svg version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 130.2 130.2">
							  <circle class="path circle" fill="none" stroke="#73AF55" stroke-width="6" stroke-miterlimit="10" cx="65.1" cy="65.1" r="62.1"/>
							  <polyline class="path check" fill="none" stroke="#73AF55" stroke-width="6" stroke-linecap="round" stroke-miterlimit="10" points="100.2,40.2 51.5,88.8 29.8,67.5 "/>
							</svg>
							<h2 style="text-align: center;">สำเร็จ</h2>
							<p class="success" id="s_txt"></p>
						</div>
					</div>
				</div>
			</div>
		</center>
		<!---------------------------------------------------------------------------------------------->
		<!-- Modal -->
		<center>
			<div class="modal fade" id="error" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
				<div class="modal-dialog" role="document" style="width:300px;margin-top:10%">
					<div class="modal-content">
						<div class="modal-body">
							<button type="button" class="close" data-dismiss="modal" aria-label="Close">
								<span aria-hidden="true">&times;</span>
							</button>
							<svg version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 130.2 130.2">
								<circle class="path circle" fill="none" stroke="#D06079" stroke-width="6" stroke-miterlimit="10" cx="65.1" cy="65.1" r="62.1"/>
								<line class="path line" fill="none" stroke="#D06079" stroke-width="6" stroke-linecap="round" stroke-miterlimit="10" x1="34.4" y1="37.9" x2="95.8" y2="92.3"/>
								<line class="path line" fill="none" stroke="#D06079" stroke-width="6" stroke-linecap="round" stroke-miterlimit="10" x1="95.8" y1="38" x2="34.4" y2="92.2"/>
							</svg>
							<h2 style="text-align: center;">ผิดพลาด</h2>
							<p class="error" id="e_txt"></p>
						</div>
					</div>
				</div>
			</div>
		</center>