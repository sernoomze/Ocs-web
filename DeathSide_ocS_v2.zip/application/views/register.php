<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<div class="content-setting">
	<div class="setting-col">
		<div class="setting-box">
			<?php if(isset($message)) echo $message; ?>
			<h4><span class="label label-primary">สมัครบัญชี</span> <span class="label label-warning text-black"></span></h4>
			<hr>
			<form method="post" action="/register/confirm_register">
				<div class="form-group">
					<label for=""><span class="label label-default">ชื่อบัญชี</span> :</label>
					<input type="text" class="form-control" name="user" id="username_r" placeholder="กรอกชื่อบัญชีที่ต้องการ" required>
				</div>
				<div class="form-group">
					<label for=""><span class="label label-default">รหัสผ่าน</span> :</label>
					<input type="password" class="form-control" name="pass" placeholder="รหัสผ่านอย่างน้อยหกหลัก" required>
				</div>
				<div class="form-group">
					<label for=""><span class="label label-default">รหัสผ่านอีกครั้ง</span> :</label>
					<input type="password" class="form-control" name="pass_re" placeholder="ยืนยันรหัสผ่าน" required>
				</div>
				<div class="form-group">
					<label for=""><span class="label label-default">อีเมลล์</span> :</label>
					<input type="email" class="form-control" name="email" id="email_r" placeholder="กรอกอีเมลล์ของคุณ" required>
				</div>
				<!--<div class="form-group">
					<label for=""><span class="label label-default">อัพโหลดรูปโปรไฟล์</span> :</label>
					<input type="file" class="form-control" name="profile">
				</div>-->
				<div class="text-center">
					<button type="submit" class="btn btn-warning text-black" name="register"><i class="fa fa-edit"></i>สมัคร</button>
				</div>
			</form>
		</div>
	</div>
</div>
<script>
	$("#username_r").on("focusout", function(){
		if($(this).val()==""){
			$("#username_r").removeClass("had-success");
			$("#username_r").addClass("had-error");
			$("#username_r").focus();
		}else{
			$.post("/login/get_profile",{
				username: $(this).val()
			},
			function(data){
				if(data!=false){
					$("#username_r").removeClass("had-success");
					$("#username_r").addClass("had-error");
					$("#username_r").focus();
				}else{
					$("#username_r").removeClass("had-error");
					$("#username_r").addClass("had-success");
				}
			});
		}
	});
	$("#email_r").on("focusout", function(){
		if($(this).val()!=""){
			$.post("/login/check_email",{
				email: $(this).val()
			},
			function(data){
				if(data==false){
					$("#email_r").removeClass("had-success");
					$("#email_r").addClass("had-error");
					$("#email_r").focus();
				}else{
					$("#email_r").removeClass("had-error");
					$("#email_r").addClass("had-success");
				}
			});
		}
	});
	$('[name="pass"]').on("focusout", function(){
		if($(this).val()!=""){
			if($(this).val().length < 6){
				$(this).removeClass("had-success");
				$(this).addClass("had-error");
			}else{
				$(this).removeClass("had-error");
				$(this).addClass("had-success");
			}
		}else{
			$(this).removeClass("had-success");
			$(this).addClass("had-error");
		}
	});
	
	$('[name="pass_re"]').on("focusout", function(){
		if($(this).val()!=""){
			if($(this).val()!=$('[name="pass"]').val()){
				$(this).removeClass("had-success");
				$('[name="pass"]').removeClass("had-success");
				$(this).addClass("had-error");
				$('[name="pass"]').addClass("had-error");
			}else{
				$(this).removeClass("had-error");
				$('[name="pass"]').removeClass("had-error");
				$(this).addClass("had-success");
				$('[name="pass"]').addClass("had-success");
			}
		}else{
			$(this).removeClass("had-success");
			$(this).addClass("had-error");
		}
	});
</script>