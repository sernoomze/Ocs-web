<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<div class="content-index">
	<div class="index-col">
		<div class="index-box">
			<?php if(isset($message)) echo $message; ?>
			<ul class="nav nav-tabs index-li">
			  <li class="active"><a data-toggle="tab" href="#home">ประกาศ</a></li>
			  <li><a data-toggle="tab" href="#menu1">โปรเสริมที่ต้องใช้</a></li>
			  <li><a data-toggle="tab" href="#menu2">FACEBOOK</a></li>
			</ul>
			<div class="tab-content sd-1">
			  <div id="home" class="tab-pane fade in active" style="word-break: break-word;">
				<div class="index-tab">
					<?php if(isset($_SESSION['admin'])&&$_SESSION['admin']==true): ?>
					<br>
					<form action="" method="POST">
						<div class="form-group">
							<label for="">เพิ่มข้อความ :</label>
							<textarea class="form-control" placeholder="ใส่ข้อความ สามารถใช้แท็ก html ได้" style="resize: vertical;" name="msg_notice"></textarea>
						</div>
						<div class="text-center">
							<button type="submit" class="btn btn-default">เพิ่ม</button>
						</div>
					</form>
					<?php endif; ?>
					<h3><b> ประกาศ : </b></h3>
					<?php foreach($msg as $row){ ?>
					<?=$row['text_']?><?php if(isset($_SESSION['admin'])&&$_SESSION['admin']==true): ?><a href="<?=base_url('/main/index/delnotice/'.$row['id'])?>" class="btn btn-danger">ลบ</a><?php endif; ?>
					<?php } ?>
				</div>
			  </div>
			  <div id="menu1" class="tab-pane fade" style="word-break: break-word;">
				<h3>โปรเสริม :</h3>
				<p>--ยังไม่มีรายละเอียด--</p>
			  </div>
			  <div id="menu2" class="tab-pane fade" style="word-break: break-word;">
				<h3>ช่องทางติดต่อ : </h3>
				<p>--ยังไม่มีช่องทางติดต่อ--</p>
			  </div>
			</div>
		</div>
	</div>
</div>
<div class="content-index">
	<div class="index-col">
		<div class="index-box">
			<ul class="nav nav-tabs index-li">
			  <li class="active"><a data-toggle="tab" href="#index_tab2_menu1">รายละเอียดเซิร์ฟเวอร์</a></li>
			</ul>
			<div class="tab-content sd-1">
			  <div id="index_tab2_menu1" class="tab-pane fade in active">
				<div class="index-tab">
					<div class="index-tab">
						<table class="table table-hover">
							<thead>
								<tr>
									<th class="text-center">Service</th>
									<th class="text-center">Port</th>
									<th class="text-center">รายละเอียด</th>
								</tr>
							</thead>
							<tbody>
								<tr>
									<td class="text-center">OpenVPN</td>
									<td class="text-center">1194</td>
									<td class="text-center"><img src="<?=base_url('/asset/img/service/openvpn.png')?>" width="25"></td>
								</tr>
								<tr>
									<td class="text-center">OpenSSH</td>
									<td class="text-center">22,143</td>
									<td class="text-center"><img src="<?=base_url('/asset/img/service/httpinjector.png')?>" width="25"></td>
								</tr>
								<tr>
									<td class="text-center">SquidProxy</td>
									<td class="text-center">3128,8000,8080</td>
									<td class="text-center"><img src="<?=base_url('/asset/img/service/squid.png')?>" width="25"></td>
								</tr>
							</tbody>
						</table>
					</div>
				</div>
			  </div>
			</div>
		</div>
	</div>
</div>

