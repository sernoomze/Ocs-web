<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<div class="content-setting">
	<?php if($_SESSION['admin']): ?>
		<p class="text-right">
			<a type="button" class="btn btn-default" href="<?=base_url('/server/addfile')?>">
				<i class="fa fa-plus" style="font-size:30px"></i>
			</a>
		</p>
	<?php endif; ?>
	<div class="setting-col" style="">
		<div class="setting-box">
			<h4><span class="label label-warning text-black"> ดาวน์โหลดไฟล์ Config</span></h4>
			<hr>
			<?php if(empty($row)): ?>
			<div class="text-center">
				<p> ยังไม่มีไฟล์ config </p>
			</div>
			<?php else: ?>
			<div class="table-responsive">
				<table class="table table-hover">
					<thead>
					<tr>
						<th>Server</th>
						<th>ไฟล์</th>
						<th>จัดการ</th>
					</tr>
					</thead>
					<tbody>
						<?php foreach($row as $data){ ?>
						<tr>
							<td><span class="label bg-blue2"><?=$data['s_id']?></span></td>
							<td><span class="label label-info"><a href="<?=base_url('/'.$data['link'])?>" style="color: black;text-decoration:none" download>ดาวน์โหลด</a></span></td>
							<td><span class="label label-danger"><a href="<?=base_url('/server/delfile/'.$data['s_id'])?>" style="color: black;text-decoration: none">ลบ</a></span></td>
						</tr>
						<?php } ?>
					</tbody>
				</table>
			</div>
			<?php endif; ?>
		</div>
	</div>
</div>