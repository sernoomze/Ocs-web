<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<div class="content-setting">
	<div class="setting-col">
		<div class="setting-box">
			<h4><span class="label label-primary"> User Online</span></h4>
			<!--<h5>เซิร์ฟ <?=$servername?> || <?=$usage?> GB</h5>-->
			<hr>
			<h5 class="text-left"><span class="label label-default">บัญชีที่กำลังใช้งาน</span></h5>
			<br>
			<div class="table-responsive">
				<table class="table table-hover">
					<thead>
					<tr>
						<th>Username</th>
						<th>เวลาที่เริ่ม</th>
						<th>เวลาล่าสุด</th>
						<th>ดาวน์โหลด</th>
						<th>อัพโหลด</th>
					</tr>
					</thead>
					<tbody>
						<?php if(isset($data['users'])){ ?>
							<?php foreach($data['users'] as $row) { ?>
								<?php $data2 = preg_split('/\s+/', $row["Since"]); ?>
								<?php $data3 = preg_split('/\s+/', $row["LastRef"]); ?>
								<tr style="font-weight:bold">
									<b>
									<td><?=$row["CommonName"]?></td>
									<td><?=$data2["3"]?></td>
									<td><?=$data3["3"]?></td>
									<td><?=$row["BytesSent"]?></td>
									<td><?=$row["BytesReceived"]?></td>
									</b>
								</tr>
							<?php } ?>
						<?php }else{ ?>
							<tr>
								<td class="text-muted text-center" colspan="6">ยังไม่มีบัญชีออนไลน์ขณะนี้</td>
							</tr>
						<?php } ?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>