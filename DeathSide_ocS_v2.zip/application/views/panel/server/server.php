<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<div class="content">
	<div class="row">
		<div class="" style="white-space: nowrap">
			<?php for($i=0;$i<count($row);$i++): ?>
			<div class="server-col">
				<div class="server-list" style="max-height: 500px;overflow-y: auto;">
					<?php
						if(isset($_SESSION['admin'])&&($_SESSION['admin']==true)):
							$check = "";
							if($row[$i]['s_status']==1):
								$check = "checked";
							endif;
					?>
						<div id="div-edit-<?=$row[$i]['s_id']?>">
							<div id="textbox">
								<p class="alignleft">
									<label class="switch" id="checkbox-server">
										<input type="checkbox" <?=$check?> data-server-id="<?=$row[$i]['s_id']?>" onclick="openserver(this)">
										<span class="slider"></span>
									</label>
								</p>
								<p class="alignright">
									<button type="button" class="btn label-info text-black" id="edit-<?=$row[$i]['s_id']?>" data-server-edit-id="<?=$row[$i]['s_id']?>" onclick="editserver(this)">แก้ไข</button>
									<button type="button" class="btn bg-red1 text-black" data-server-id="<?=$row[$i]['s_id']?>" onclick="delserver(this)">ลบ</button>
								</p>
							</div>
							<div style="clear: both;"></div>
							<hr class="server-hr">
							<script>
								function openserver(e){
									var s = 0;
									if($(e).is(':checked')){
										s = 1;
									}else{
										s = 0;
									}
									$.post("/server/open_server",{
										s_id : $(e).data("server-id"),
										value : s
									},
									function(data){
										location.reload();
									});
								}
								function delserver(e){
									$.post("/server/delserver",{
										s_id : $(e).data("server-id"),
									},
									function(data){
										location.reload();
									});
								}
								function editserver(e){
									if(tmp_edit!=''&&tmp_edit!=$(e).data("server-edit-id")){
										
										var a = $(document).find('#edit-'+tmp_edit).parent().parent().parent();
										a.parent().find('#edit_form').hide(500);
										a.parent().find('#edit_form').remove();
										a.siblings().show(500);
										temp_edit($(e).data("server-edit-id"));
									}else{
										temp_edit($(e).data("server-edit-id"));
									}
									var keep_sec = $(e).parent().parent().parent();
									keep_sec.siblings().hide();
									var edit_form = $('#form_edit_server_tmp').html();
									keep_sec.append('<div id="edit_form" style="display: none"><input type="hidden" value="">' + edit_form + '</div>');
									$('#edit_form').show(500);
									
									var input = $('#edit_form').find('input');
									var select = $('#edit_form').find('select');
									$.get("/server/getinfo",{
										s_id : $(e).data("server-edit-id"),
									},
									function(data){
										var obj = JSON.parse(data);
										input[0].value = $(e).data("server-edit-id");
										input[1].value = obj.s_name;
										input[2].value = obj.s_ip;
										input[3].value = obj.s_pass;
										input[4].value = obj.s_price;
										input[5].value = obj.s_expire;
										input[6].value = obj.s_limit;
										$(select[0]).val(obj.s_status);
									});
								}
								function cancle_edit(e){
									if(tmp_edit!=''){
										var a = $(e).parent().parent().parent();
										a.find('#edit_form').hide(500);
										sleep(500).then(() => {
											a.parent().find('#edit_form').remove();
										});
										a.siblings().show(500);
									}
								}
								var tmp_edit = '';
								function temp_edit(id){
									tmp_edit = id;
								}
								$(document).ready(function(){
									function slide_col_to_bottom(){
										var col = $(document).find('.server-list');
										col.animate({scrollTop:col.height()}, 500);
									}
									slide_col_to_bottom();
								});
							</script>
						</div>
					<?php endif; ?>
					<div class="server-head text-center">
						<span class="label bg-org2" id="s_id">DS Server <?=$i+1?></span>
					</div>
					<div style="clear: both;"></div>
					<h4 class="text-center">
						<span class="label bg-blue1"><?=$row[$i]['s_id']?></span>
						<?php
							if($row[$i]['s_status']==1):
								echo "<span class=\"label label-success\">Online</span>";
							else:
								echo "<span class=\"label label-danger\">Offline</span>";
							endif;
						?>
						<span class="label label-warning  bg-org1">รายละเอียด</span>
					</h4>
					<table border="0">
						<tbody>
							<hr style="border-top: 1px solid #eca117;">
							<tr>
								<td><b>Server</b></td>
								<td class="text-right"><span class="label label-info text-black"><?=$row[$i]['s_name']?></span></td>
							</tr>
							<tr>
								<td><b>IP</b></td>
								<td class="text-right"><span class="label label-warning text-black"><?=$row[$i]['s_ip']?></span></td>
							</tr>
							<tr>
								<td><b>ราคา</b></td>
								<td class="text-right"><span class="label bg-red1 text-black"><?=$row[$i]['s_price']?> บาท</span></td>
							</tr>
							<tr>
								<td><b>หมดอายุ</b></td>
								<td class="text-right"><span class="label bg-blue1 text-black"><?=$row[$i]['s_expire']?> วัน</span></td>
							</tr>
							<tr>
								<td><b>จำกัดบัญชี</b></td>
								<td class="text-right"><span class="label bg-blue2 text-black"><?=$row[$i]['s_limit']?> บัญชี</span></td>
							</tr>
							<tr>
								<td><b>สถานะบัญชี</b></td>
								<td class="text-right"><span class="label bg-red1 text-black"><?=$row[$i]['user']?>/<?=$row[$i]['s_limit']?> บัญชี</span></td>
							</tr>
							<tr>
								<td ><b>สถานะ</b></td>
								<td class="text-right">
									<?php if($row[$i]['s_status']): ?>
									<!--<span class="label label-success text-black">-->
										<?php
											$percent = ($row[$i]['user']*100)/$row[$i]['s_limit'];
											if($percent > 75):
												echo '<span class="label bg-red1 text-black">';
												echo "หนาแน่น";
											elseif($percent > 45):
												echo '<span class="label label-warning text-black">';
												echo "ปานกลาง";
											else:
												echo '<span class="label label-success text-black">';
												echo "ปกติ";
											endif;
										?>
									</span>
									<?php else: ?>
									<span class="label label-danger text-black">
										<?="เต็ม/ปิดชั่วคราว";?>
									</span>
									<?php endif; ?>
								</td>
							</tr>
						</tbody>
					</table>
					<div class="text-center">
						<button type="button" class="btn btn-info radius-btn btn-sm" id="<?=$row[$i]['s_id']?>" onclick="regis_account(this)"><i class="fa fa-shopping-cart"></i> สมัคร</button>
						<a href="<?=base_url('/server/online/'.$row[$i]['s_id'])?>" class="btn btn-success radius-btn btn-sm"><i class="fa fa-info-circle"></i> เช็ค</a>
					</div>
				</div>
			</div>
			<?php endfor; ?>
			<div id="temp_form" style="display:none">
				<div class="form-group">
					<label for=""><span class="label bg-red1 text-black">ชื่อผู้ใช้</span> :</label>
					<input type="text" class="form-control" id="ssh_user" pattern="[a-zA-Z0-9]+">
				</div>
				<div class="form-group">
					<label for=""><span class="label bg-red1 text-black">รหัสผ่าน</span> :</label>
					<input type="password" class="form-control" id="ssh_pass">
				</div>
				<div class="text-center" id="b_confirm">
					<button type="button" class="btn label-info text-white" onclick="confirm_regis(this)">ยืนยันการสมัคร</button>
					<button type="button" class="btn bg-red1 text-black" onclick="cancle_regis(this)">ยกเลิก</button>
				</div>
				<div class="text-center" id="loading-confirm" style="display: none">
					<i class="fa fa-refresh fa-spin"></i>
				</div>
				<script>
					var tmp_input = $('#regis_form').find('input');
					$(tmp_input).on('keypress',function(e) {
						if(e.which == 13) {
							var button = $(tmp_input).parent().find('button');
							confirm_regis($(button[0]));
						}
					});
					function confirm_regis(e){
						$('#b_confirm').hide(500);
						$('#loading-confirm').show(500);
						var form = $(e).parent().parent();
						var input = form.find('input');
						var ssh_id = input[0].value;
						var ssh_user = input[1].value;
						var ssh_pass = input[2].value;
						
						$.post("/server/create_user_ssh",{
							ssh_id		: ssh_id,
							ssh_user	: ssh_user,
							ssh_pass	: ssh_pass
						},
						function(data){
							if(data=='complete'){
								$('#s_txt').html("สมัครสำเร็จ! <br> User: " + ssh_user + "<br>Password: " + ssh_pass);
								$('#success').modal('show');
								input[0].value = "";
								input[1].value = "";
								input[2].value = "";
								cancle_regis(e);
								$('#success').on('hidden.bs.modal', function () {
									location.reload();
								})
							}else if(data=='emptyvalue'){
								$('#e_txt').html("กรุณากรอกให้ครบทุกช่อง");
								$('#error').modal('show');
							}else if(data=='repeat'){
								$('#e_txt').html("กรุณาใช้ชื่ออื่น");
								$('#error').modal('show');
							}else if(data=='engonly'){
								$('#e_txt').html("กรุณาใช้ภาษาอังกฤษและตัวเลข");
								$('#error').modal('show');
							}else if(data=='mustnotroot'){
								$('#e_txt').html("ห้ามตั้ง user เป็น root");
								$('#error').modal('show');
							}else if(data=='full'){
								$('#e_txt').html("เซิร์ฟเวอร์เต็มแล้ว");
								$('#error').modal('show');
							}else if(data=='incomplete'){
								$('#e_txt').html("สมัครไม่สำเร็จ");
								$('#error').modal('show');
							}else if(data=='notenough'){
								$('#e_txt').html("ยอดเงินไม่พอ");
								$('#error').modal('show');
							}else if(data=='cannotcn'){
								$('#e_txt').html("ไม่สามารถเชื่อมต่อโฮสได้");
								$('#error').modal('show');
							}
							else{
								$('#e_txt').html("มีบางอย่างผิดพลาด");
								$('#error').modal('show');
							}
							$('#b_confirm').show(500);
							$('#loading-confirm').hide(500);
						});
					}
				</script>
			</div>
			<script>
				function regis_account(e){
					if(tmp_id!=''&&tmp_id!=e.id){
						var a = $(document).find('#'+tmp_id).parent();
						a.show(500);
						a.parent().find('#regis_form').hide(500);
						sleep(500).then(() => {
							a.parent().find('#regis_form').remove();
						});
						temp_b(e.id);
					}else{
						temp_b(e.id);
					}
					$(e).parent().hide(500);
					var this_server = $(e).parent().parent();
					var form = $('#temp_form').html();
					this_server.animate({scrollTop:this_server.height()}, 1500);
					this_server.append('<div id="regis_form"><input type="hidden" value="' + e.id + '">' + form + '</div>');
				}
				function cancle_regis(e){
					if(tmp_id!=''){
						var a = $(e).parent().parent().parent();
						a.find('#regis_form').hide(500);
						sleep(500).then(() => {
							a.parent().find('#regis_form').remove();
						});
						a.find('#'+ tmp_id).parent().show(500);
					}
				}
				var tmp_id = '';
				function temp_b(id){
					tmp_id = id;
				}
			</script>
			<?php if(isset($_SESSION['admin'])&&($_SESSION['admin']==true)): ?>
			<div id="form_edit_server_tmp" style="display: none">
				<h3 onclick=""><span class="label label-success"> แก้ไขเซิร์ฟเวอร์ </span></h3><br>
				<div class="form-group">
					<label for=""><span class="label label-danger">ชื่อเซิร์ฟเวอร์</span> :</label>
					<input type="text" class="form-control" id="edit_name_server">
				</div>
				<div class="form-group">
					<label for=""><span class="label label-danger">ไอพีเซิร์ฟเวอร์</span> :</label>
					<input type="text" class="form-control" id="edit_ip_server">
				</div>
				<div class="form-group">
					<label for=""><span class="label label-primary">พาสเวิร์ด SSH</span> :</label>
					<input type="text" class="form-control" id="edit_pass_server">
				</div>
				<div class="form-group">
					<label for=""><span class="label label-danger">ราคา</span> :</label>
					<input type="number" min="0" class="form-control" id="edit_price_server">
				</div>
				<div class="form-group">
					<label for=""><span class="label label-danger">หมดอายุ</span> :</label>
					<input type="number" min="0" class="form-control" id="edit_expire_server">
				</div>
				<div class="form-group">
					<label for=""><span class="label label-danger">จำกัดบัญชี</span> :</label>
					<input type="number" min="0" class="form-control" id="edit_limit_server">
				</div>
				<div class="form-group">
					<label for=""><span class="label label-danger">สถานะ</span> :</label>
					<select class="form-control" id="edit_status_server">
						<option value="1">เปิด</option>
						<option value="0">ปิด</option>
					</select>
				</div>
				<div class="text-center">
					<button type="button" onclick="save_server(this)" class="btn btn-info radius-btn btn-sm"> บันทึก</button>
					<button type="button" onclick="cancle_edit(this)" class="btn btn-danger radius-btn btn-sm">ยกเลิก</button>
				</div>
				<div class="text-center" id="loading-edit-confirm" style="display: none">
					<i class="fa fa-refresh fa-spin"></i>
				</div>
				<script>
					var tmp_input = $('#edit_form').find('input');
					$(tmp_input).on('keypress',function(e) {
						if(e.which == 13) {
							var button = $(tmp_input).parent().find('button');
							save_server($(button[0]));
						}
					});
					function save_server(e){
						$(e).parent().hide(500);
						$('#loading-edit-confirm').show(500);
						var input = $('#edit_form').find('input');
						var select = $('#edit_form').find('select');
						$.post("/server/update_server",{
							s_id		: input[0].value,
							s_name		: input[1].value,
							s_ip		: input[2].value,
							s_price		: input[4].value,
							s_expire	: input[5].value,
							s_limit		: input[6].value,
							s_status	: select[0].value,
							s_pass		: input[3].value,
						},
						function(data){
							$(e).parent().show(500);
							$('#loading-edit-confirm').hide(500);
							if(data=='complete'){
								$('#s_txt').html("แก้ไขสำเร็จ!");
								$('#success').modal('show');
								$('#success').on('hidden.bs.modal', function () {
									location.reload();
								})
							}else if(data=='emptyvalue'){
								$('#e_txt').html("กรุณากรอกให้ครบทุกช่อง");
								$('#error').modal('show');
							}else{
								$('#e_txt').html("มีบางอย่างผิดพลาด");
								$('#error').modal('show');
							}
						});
					}
				</script>
			</div>
			<?php endif; ?>
			<?php if(isset($_SESSION['admin'])&&($_SESSION['admin']==true)): ?>
			<div class="server-col" id="">
				<div class="server-list" id="new_server_body" style="max-height: 500px;overflow: auto;">
					<div class="text-center" id="new_server">
						<i class="fa fa-plus" style="font-size:30px"></i>
					</div>
					<div id="form_new_server" style="display: none">
						<button type="button" class="close" onclick="swap()">
							<span aria-hidden="true">&times;</span>
						</button>
						<h3 onclick="swap()"><span class="label label-success"> เพิ่มเซิร์ฟเวอร์ </span></h3><br>
						<div class="form-group">
							<label for=""><span class="label label-danger">ชื่อเซิร์ฟเวอร์</span> :</label>
							<input type="text" class="form-control" id="s_name">
						</div>
						<div class="form-group">
							<label for=""><span class="label label-danger">ไอพีเซิร์ฟเวอร์</span> :</label>
							<input type="text" class="form-control" id="s_ip">
						</div>
						<div class="form-group">
							<label for=""><span class="label label-primary">พาสเวิร์ด SSH</span> :</label>
							<input type="text" class="form-control" id="s_pass">
						</div>
						<div class="form-group">
							<label for=""><span class="label label-danger">ราคา</span> :</label>
							<input type="number" min="0" class="form-control" id="s_price">
						</div>
						<div class="form-group">
							<label for=""><span class="label label-danger">หมดอายุ</span> :</label>
							<input type="number" min="0" class="form-control" id="s_expire">
						</div>
						<div class="form-group">
							<label for=""><span class="label label-danger">จำกัดบัญชี</span> :</label>
							<input type="number" min="0" class="form-control" id="s_limit">
						</div>
						<div class="form-group">
							<label for=""><span class="label label-danger">สถานะ</span> :</label>
							<select class="form-control" id="s_status">
								<option value="1">เปิด</option>
								<option value="0">ปิด</option>
							</select>
						</div>
						<center>
							<button type="button" onclick="addserver()" class="btn btn-info radius-btn btn-sm"> เพิ่ม</button>
							<button type="button" id="cancle_new" class="btn btn-danger radius-btn btn-sm">ยกเลิก</button>
						</center>
					</div>
				</div>
			</div>
			<script>
				$('#new_server').click(function(){
					$(this).hide(1000);
					$('#form_new_server').show(1000);
				});
				$('#cancle_new').click(function(){
					swap();
				});
				
				function addserver(){
					var s_name		= $('#s_name');
					var s_ip		= $('#s_ip');
					var s_price		= $('#s_price');
					var s_expire	= $('#s_expire');
					var s_limit		= $('#s_limit');
					var s_status	= $('#s_status');
					var s_pass		= $('#s_pass');
					
					$.post("/server/addServer",{
						s_name		: s_name.val(),
						s_ip		: s_ip.val(),
						s_price		: s_price.val(),	
						s_expire	: s_expire.val(),
						s_limit		: s_limit.val(),
						s_status	: s_status.val(),
						s_pass		: s_pass.val()
					},
					function(data){
						if(data=='complete'){
							$('#s_txt').html("เพิ่มเซิร์ฟเวอร์สำเร็จ!");
							$('#success').modal('show');
							sleep(1500).then(() => {
								location.reload();
							});
						}else if(data=='emptyvalue'){
							$('#e_txt').html("กรุณากรอกให้ครบทุกช่อง");
							$('#error').modal('show');
						}else{
							$('#e_txt').html("มีบางอย่างผิดพลาด");
							$('#error').modal('show');
						}
					});
				}
				function swap(){
					$('#form_new_server').hide(1000);
					$('#new_server').show(1000);
				}
			</script>
			<?php endif; ?>
		</div>
	</div>
</div>