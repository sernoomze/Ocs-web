<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<div class="content-setting">
	<div class="setting-col" style="width:100%">
		<div class="setting-box">
			<?php if(isset($message)) echo $message; ?>
			<h4><span class="label bg-blue1"> บัญชี Openvpn ทั้งหมด</span></h4>
			<hr>
			<div class="table-responsive">
				<table class="table table-hover">
					<thead>
					<tr>
						<th>ไอดี</th>
						<th>user</th>
						<th>pass</th>
						<th>เซิร์ฟเวอร์</th>
						<th>สร้างโดย</th>
						<th>หมดอายุ</th>
						<th>จัดการ</th>
					</tr>
					</thead>
					<tbody>
						<?php if(empty($row)): ?>
							<tr><td colspan="7" class="text-center"><small>-ยังไม่มีบัญชี-</small></td></tr>
						<?php else: ?>
						<?php foreach($row as $data){ ?>
							<tr>
								<td><?=$data['ssh_u_id']?></td>
								<td><?=$data['ssh_user']?></td>
								<td><?=$data['ssh_pass']?></td>
								<td><?=$data['s_id']?></td>
								<td><?=$data['create_by']?></td>
								<td><?=$data['expire_at']?></td>
								<td>
									<span class="label label-danger"><a href="<?=base_url('/server/sshuser/del/'.$data['ssh_u_id'])?>" class="nounderline text-black">ลบ</a></span>
									<span class="label label-primary"><a href="<?=base_url('/server/sshuser/renew/'.$data['ssh_u_id'])?>" class="nounderline text-black">ต่ออายุ</a></span>
								</td>
							</tr>
						<?php } ?>
						<?php endif; ?>
					</tbody>
				</table>
			</div>
			<div class="count-txt-right">
				<small>ทั้งหมด <?=count($row)?> บัญชี</small>
			</div>
		</div>
	</div>
</div>