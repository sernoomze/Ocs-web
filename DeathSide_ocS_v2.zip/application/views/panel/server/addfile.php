<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<div class="content-setting">
	<div class="setting-col" style="">
		<div class="setting-box">
			<?php if(isset($message)) echo $message; ?>
			<h4><span class="label label-primary"> เพิ่มไฟล์ Config</span></h4>
			<hr>
			<form action="<?=base_url('/server/confirmaddfile')?>" method="post" enctype="multipart/form-data">
				<div class="form-group">
					<label for="">Server</label>
					<select class="form-control" name="s_id">
						<?php foreach($row as $data){ ?>
							<option><?=$data['s_id']?></option>
						<?php } ?>
					</select>
				</div>
				<div class="form-group">
					<label for="">ไฟล์ config</label>
					<input type="file" class="form-control" name="file">
				</div>
				<div class="text-center">
					<button type="submit" class="btn btn-success">อัพโหลด</button>
					<a type="button" class="btn btn-danger" href="<?=base_url('/server/download')?>">ยกเลิก</a>
				</div>
			</form>
		</div>
	</div>
</div>