<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<div class="content-setting">
	<?php if($_SESSION['admin']): ?>
		<p class="text-right">
			<a type="button" class="btn btn-default" href="<?=base_url('/server/addwallet')?>">
				<i class="fa fa-plus" style="font-size:30px"></i>
			</a>
		</p>
	<?php endif; ?>
	<div class="setting-col">
		<div class="setting-box">
			<?php if(isset($message)) echo $message; ?>
			<h4><span class="label bg-red1"><i class="fa fa-bank"></i> เติมเงินเข้าสู่บัญชี</span> <span class="label label-warning text-black"><?=$_SESSION['username']?></span></h4>
			<hr>
			<!--<h5 class="text-left"><span class="label label-default">กรอกเลขอ้างอิงทรูวอเล็ท</span></h5>-->
			<?php if(isset($mobile)): ?>
			<div class="text-center">
				<p>โอนเงินทางทรูวอเล็ทมาที่เบอร์ <?=$mobile->mobile?></p>
			</div>
			<form action="<?=base_url('/main/confirmaddpoint')?>" method="POST">
				<div class="form-group">
					<label for="">เลขอ้างอิง</label>
					<input type="text" class="form-control" name="ref_no" placeholder="50000xxxxxxxxx" required>
				</div>
				<div class="text-center">
					<button type="submit" class="btn btn-success">ยืนยัน</button>
					<a type="button" class="btn btn-danger" href="<?=base_url('/')?>">ยกเลิก</a>
				</div>
			</form>
			<br>
			<div class="count-txt-right">
				<small>ยอดคงเหลือ : <?=$_SESSION['balance']?> บาท</small>
			</div>
		</div>
	</div>
	<p class="text-center">หรือ</p>
	<div class="setting-col">
		<div class="setting-box">
			<h4><span class="label bg-red1"><i class="fa fa-bank"></i> เติมเงินเข้าสู่บัญชี</span> <span class="label label-warning text-black"><?=$_SESSION['username']?></span></h4>
			<hr>
			<p class="text-red">*** ใช้วิธีนี้ กรณีที่วิธีข้างบนไม่สามารถใช้งานได้ ***</p>
			<hr>
				<?php if($truewallet==false): ?>
					<div id="login-true-wallet">
						<div class="form-group">
							<label for=""><span style="color: #ffa707">ชื่อบัญชี</span> :</label>
							<input type="text" class="form-control" placeholder="เบอร์หรืออีเมลล์ ทรูวอเลต" id="wallet_user">
						</div>
						<div class="form-group">
							<label for=""><span style="color: #ffa707">รหัสผ่าน</span> :</label>
							<input type="password" class="form-control" placeholder="รหัสผ่าน" id="wallet_psw">
						</div>
						<!--<div class="form-group">
							<label for="">จำนวนที่ต้องการ :</label>
							<input type="text" class="form-control" id="amount" placeholder="Ex. 1-1000">
						</div>-->
						<div class="text-center">
							<button type="button" class="btn btn-warning text-black" id="wallet_login">เข้าสู่ระบบ</button>
						</div>
					</div>
					<div id="login-true-wallet-otp">
						<h4><span class="label label-warning">ยืนยัน OTP</span> <span class="label label-warning text-black"></span></h4>
						<hr>
						<div>
							<div class="form-group">
								<label for=""><span style="color: #ffa707">otp</span> : (Ref: <span id="otp_ref"></span>)</label>
								<input type="text" class="form-control" id="wallet_otp">
							</div>
							<div class="text-center">
								<button type="button" class="btn btn-warning text-black" id="wallet_login_otp">ยืนยัน</button>
							</div>
						</div>
					</div>
					<script>
						$('#login-true-wallet-otp').hide();
						
						$("#wallet_user").on("keyup", function(e) {
							if (e.keyCode == 13) {
								wallet_login();
							}
						});
						$("#wallet_psw").on("keyup", function(e) {
							if (e.keyCode == 13) {
								wallet_login();
							}
						});
						$("#wallet_login").click(function() {
							wallet_login();
						});
						$("#wallet_otp").on("keyup", function(e) {
							if (e.keyCode == 13) {
								wallet_login_otp();
							}
						});
						$("#wallet_login_otp").click(function() {
							wallet_login_otp();
						});
						
						function wallet_login(){
							$("#wallet_user").removeClass("had-error");
							$("#wallet_psw").removeClass("had-error");
							$("#wallet_login").html('<i class="fa fa-refresh fa-spin"></i>');
							$.post("/newwallet/login",{
								wallet_user: $("#wallet_user").val(),
								wallet_psw: $("#wallet_psw").val(),
							},
							function(data){
								$("#wallet_login").html('เข้าสู่ระบบ');
								var obj = JSON.parse(data);
								if(obj.code==100){
									$('#e_txt').html("กรอกให้ครบทุกช่อง");
									$('#error').modal('show');
									$("#wallet_user").addClass("had-error");
									$("#wallet_psw").addClass("had-error");
								}else if(obj.code==300){
									$('#e_txt').html(obj.text);
									$('#error').modal('show');
								}else if(obj.code==200){
									$('#login-true-wallet').hide();
									$('#login-true-wallet-otp').show();
									$('#otp_ref').text(obj.otp_reference);
									$('#wallet_otp').attr("placeholder", obj.otp_reference);
								}else{
									$('#e_txt').html("ผิดพลาด");
									$('#error').modal('show');
								}
							});
						}
						function wallet_login_otp(){
							$.post("/newwallet/login_otp",{
								wallet_otp: $("#wallet_otp").val(),
							},
							function(data){
								if(data=="login"){
									$('#s_txt').html("เข้าสู่ระบบสำเร็จ!");
									$('#success').modal('show');
									sleep(1500).then(() => {
										location.reload();
									});
								}else if(data=="wrong"){
									$('#e_txt').html("OTP ไม่ถูกต้อง กรุณาลองใหม่อีกครั้ง");
									$('#error').modal('show');
								}
							});
						}
					</script>
				<?php else: ?>
					<div id="otp_form">
						<div class="form-group">
							<label for="">จำนวนที่ต้องการ :</label>
							<div class="input-group">
								<input type="text" class="form-control" id="wallet_amount" placeholder="Ex. 1-1000 บาท">
								<span class="input-group-addon">บาท</span>
							</div>
						</div>
						<div class="text-center">
							<button type="button" class="btn btn-warning text-black" id="wallet_addpoint">ยืนยัน</button>
						</div>
					</div>
					<div id="otp_form_2" style="display: none">
						<h4><span class="label label-warning">ตรวจสอบความถูกต้อง</span> <span class="label label-warning text-black"></span></h4>
						<hr>
						<div>
							<div class="form-group">
								<label for=""><span style="color: #ffa707">เบอร์โทรศัพท์มือถือผู้รับ</span> :</label>
								<input type="text" class="form-control" id="wallet_number_check" readonly>
							</div>
							<div class="form-group">
								<label for=""><span style="color: #ffa707">ชื่อผู้รับ</span> :</label>
								<input type="text" class="form-control" id="wallet_name_check" readonly>
							</div>
							<div class="form-group">
								<label for=""><span style="color: #ffa707">จำนวนเงิน</span> :</label>
								<input type="number" class="form-control" id="wallet_amount_check" readonly>
							</div>
							<div class="text-center">
								<button type="button" class="btn btn-warning text-black" id="wallet_transfer_confirm">ยืนยัน</button>
							</div>
						</div>
					</div>
					<script>
						$("#wallet_amount").on("keyup", function(e) {
							if (e.keyCode == 13) {
								wallet_transfer();
							}
						});
						$("#wallet_addpoint").click(function() {
							wallet_transfer();
						});
						
						function wallet_transfer(){
							$("#wallet_addpoint").html('<i class="fa fa-refresh fa-spin"></i>');
							$.post("/main/newconfirmaddpoint",{
								wallet_amount: $("#wallet_amount").val(),
							},
							function(data){
								$("#wallet_addpoint").html('ยืนยัน');
								
								var obj = JSON.parse(data);
								
								if(obj.code==100){
									$('#e_txt').html("กรุณากรอกให้ครบ");
									$('#error').modal('show');
								}else if(obj.code==200){
									$("#wallet_number_check").val(obj.mobileNumber);
									$("#wallet_name_check").val(obj.recipientName);
									$("#wallet_amount_check").val(obj.amount);
									$("#otp_form").hide();
									$("#otp_form_2").show();
									
								}else if(obj.code==300){
									$('#e_txt').html(obj.text);
									$('#error').modal('show');
								}else if(obj.code==400){
									$('#e_txt').html(obj.text);
									$('#error').modal('show');
								}else{
									$('#e_txt').html("ผิดพลาด");
									$('#error').modal('show');
								}
							});
						}
						$("#wallet_transfer_confirm").click(function() {
							wallet_transfer_confirm();
						});
						function wallet_transfer_confirm(){
							$("#wallet_transfer_confirm").html('<i class="fa fa-refresh fa-spin"></i>');
							$.post("/main/transfer_confirm",{
								//wallet_otp: $("#wallet_otp").val()
							},
							function(data){
								$("#wallet_transfer_confirm").html('ยืนยัน');
								if(data=="ok"){
									$('#s_txt').html("โอนสำเร็จ!");
									$('#success').modal('show');
									sleep(1500).then(() => {
										location.reload();
									});
								}else{
									$('#e_txt').html("ผิดพลาด กรุณาลองใหม่อีกครั้ง");
									$('#error').modal('show');
								}
							});
						}
					</script>
				<?php endif; ?>
			<?php else: ?>
				<div class="text-center">
					<p>ยังไม่รองรับการโอนเงิน</p>
				</div>
			<?php endif; ?>
			<br>
			<div class="count-txt-right">
				<small>ยอดคงเหลือ : <?=$_SESSION['balance']?> บาท</small>
			</div>
		</div>
	</div>
</div>