<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
	<nav class="navbar navbar-inverse bg-white-tmw">
	  <div class="container-fluid">
		<div class="navbar-header">
		<?php if(isset($_SESSION['truemoney'])): ?>
		  <button type="button" class="navbar-toggle br-black-tmw" data-toggle="collapse" data-target="#myNavbar">
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>                        
		  </button>
		<?php endif; ?>
		  <a class="navbar-brand" href="/truemoney/wallet" style="width: 100px;"><img src="/asset/img/wallet/wallet-logo.png" style="width: 100%;"></a>
		  <!--<img src="/asset/img/wallet/wallet-logo.png" style="width: 100px;">-->
		</div>
		<div class="collapse navbar-collapse br-white-tmw" id="myNavbar">
			<ul class="nav navbar-nav txt-black001">
				<?php if(empty($_SESSION['truemoney'])): ?>
				<?php else: ?>
				<li><a><img src="/asset/img/wallet/wallet-active.png"> ยอดคงเหลือ : <?=$balance?> บาท</a></li>
				<li><a href="/truemoney/wallet"><img src="/asset/img/wallet/wallet-active.png"> กระเป๋าเงิน</a></li>
				<!--<li><a href="/truemoney/wallet/topup"><img src="/asset/img/wallet/addm-active.png"> เติมเงิน</a></li>-->
				<li><a href="/truemoney/wallet/transfer"><img src="/asset/img/wallet/swap-active.png"> โอนเงิน</a></li>
				<li><a href="/newwallet/logout"><img src="/asset/img/wallet/signout-active.png"> ออกจากระบบ</a></li>
				<?php endif; ?>
			</ul>
		<?php if(isset($_SESSION['truemoney'])): ?>
		  <ul class="nav navbar-nav navbar-right header-tmw">
			<li class="tmw-profile"><img src="<?=$_SESSION['truemoney']['profile']?>"></li>
		  </ul>
		<?php endif; ?>
		</div>
	  </div>
	</nav>