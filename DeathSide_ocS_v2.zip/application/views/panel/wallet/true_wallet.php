<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<div class="head-nav-tmw">
	<?php include "tmw_nav.php" ?>
		<?php if($page=="index"): ?>
		<div style="background-color:white">
		<table class="table table-hover wallet-bag-table">
			<thead>
			  <tr>
				<th>ประเภท</th>
				<th>รายละเอียด</th>
				<th>จำนวนเงิน</th>
				<th>วันที่</th>
			  </tr>
			</thead>
			<tbody>
			<?php for($i=0;$i<count($row);$i++): ?>
			  <tr onclick="showdetail_tmw(this)" id="<?=$row[$i]['report_id']?>">
				<td width="10%"><img src="<?=$row[$i]['logo_url']?>" width="30px"></td>
				<td width="55%"><?=$row[$i]['title']."<br>".$row[$i]['sub_title']?></td>
				<td width="15%"><?=$row[$i]['amount']?></td>
				<td width="15%"><?=$row[$i]['date_time']?></td>
			  </tr>
			</tbody>
			<?php endfor; ?>
		</table>
		</div>
		<script>
			function showdetail_tmw(e){
				$('#tmp-detail').html('');
				$.post("/wallet/get_detail",{
					id: e.id
				},
				function(data){
					var obj = JSON.parse(data);
					$('#detail-tmw-title').html(obj[0].title);
					for(i=1;i<obj.length;i++){
						if(i==1){
							var tmp = '<div id="textbox"><p class="alignleft">' + obj[i].title + '<br> '+ obj[i].value +'</p><p class="alignright"><img src="' + obj[0].value + '" width="40px"></p></div><div style="clear: both;"></div><hr>';
							$('#tmp-detail').append(tmp);
						}else{
							$('#tmp-detail').append('<div id="textbox">');
							$('#tmp-detail').append('<p class="alignleft">' + obj[i].title + ' <br> ' + obj[i].value + '</p>');
							if(i+1 < obj.length){
								$('#tmp-detail').append('<p class="alignright">' + obj[i+1].title + ' <br> ' + obj[i+1].value + '</p>');
							}
							$('#tmp-detail').append('</div><div style="clear: both;"></div><hr>');
							i++;
						}
					}
					$('#tmw-modal-detail').modal('show');
				});
			}
		</script>
		<center>
			<div class="modal fade" id="tmw-modal-detail" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
				<div class="modal-dialog" role="document" style="width:300px;margin-top:10%">
					<div class="modal-content">
						<div class="modal-body">
							<h4 class="alignleft" id="detail-tmw-title"></h4>
							<div style="clear: both;"></div>
							<hr>
							<div id="tmp-detail">
							</div>
						</div>
					</div>
				</div>
			</div>
		</center>
		<?php elseif($page == "transfer"): ?>
			<div class="content-setting">
				<div class="setting-col">
					<div class="setting-box">
						<div id="otp_form">
							<h4><span class="label label-warning">โอนเงินทรูวอเล็ท</span> <span class="label label-warning text-black"></span></h4>
							<hr>
							<div>
								<div class="form-group">
									<label for=""><span style="color: #ffa707">เบอร์โทรศัพท์มือถือผู้รับ</span> :</label>
									<input type="text" class="form-control" id="wallet_number">
								</div>
								<div class="form-group">
									<label for=""><span style="color: #ffa707">จำนวนเงิน</span> :</label>
									<input type="number" class="form-control" id="wallet_amount">
								</div>
								<div class="form-group">
									<label for=""><span style="color: #ffa707">ข้อความ</span> :</label>
									<textarea class="form-control" width="100%" style="resize: none;" rows="5" id="wallet_msg" maxlength="140"></textarea>
								</div>
								<div class="text-center">
									<button type="button" class="btn btn-warning text-black" id="wallet_transfer">ยืนยัน</button>
								</div>
							</div>
						</div>
						<div id="otp_form_2" style="display: none">
							<h4><span class="label label-warning">ตรวจสอบความถูกต้อง</span> <span class="label label-warning text-black"></span></h4>
							<hr>
							<div>
								<div class="form-group">
									<label for=""><span style="color: #ffa707">เบอร์โทรศัพท์มือถือผู้รับ</span> :</label>
									<input type="text" class="form-control" id="wallet_number_check" readonly>
								</div>
								<div class="form-group">
									<label for=""><span style="color: #ffa707">ชื่อผู้รับ</span> :</label>
									<input type="text" class="form-control" id="wallet_name_check" readonly>
								</div>
								<div class="form-group">
									<label for=""><span style="color: #ffa707">จำนวนเงิน</span> :</label>
									<input type="number" class="form-control" id="wallet_amount_check" readonly>
								</div>
								<div class="text-center">
									<button type="button" class="btn btn-warning text-black" id="wallet_transfer_confirm">ยืนยัน</button>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<script>
				$("#wallet_number").on("keyup", function(e) {
					if (e.keyCode == 13) {
						wallet_transfer();
					}
				});
				$("#wallet_amount").on("keyup", function(e) {
					if (e.keyCode == 13) {
						wallet_transfer();
					}
				});
				$("#wallet_msg").on("keyup", function(e) {
					if (e.keyCode == 13) {
						wallet_transfer();
					}
				});
				$("#wallet_transfer").click(function() {
					wallet_transfer();
				});
				function wallet_transfer(){
					$("#wallet_transfer").html('<i class="fa fa-refresh fa-spin"></i>');
					$.post("/newwallet/transfer",{
						wallet_number: $("#wallet_number").val(),
						wallet_amount: $("#wallet_amount").val(),
						wallet_msg: $("#wallet_msg").val()
					},
					function(data){
						$("#wallet_transfer").html('ยืนยัน');
						
						var obj = JSON.parse(data);
						
						if(obj.code==100){
							$('#e_txt').html("กรุณากรอกให้ครบ");
							$('#error').modal('show');
						}else if(obj.code==200){
							$("#wallet_number_check").val(obj.mobileNumber);
							$("#wallet_name_check").val(obj.recipientName);
							$("#wallet_amount_check").val(obj.amount);
							$("#otp_form").hide();
							$("#otp_form_2").show();
							
						}else if(obj.code==300){
							$('#e_txt').html(obj.text);
							$('#error').modal('show');
						}else if(obj.code==400){
							$('#e_txt').html(obj.text);
							$('#error').modal('show');
						}else{
							$('#e_txt').html("ผิดพลาด");
							$('#error').modal('show');
						}
					});
				}
				$("#wallet_otp").on("keyup", function(e) {
					if (e.keyCode == 13) {
						wallet_transfer_confirm();
					}
				});
				$("#wallet_transfer_confirm").click(function() {
					wallet_transfer_confirm();
				});
				function wallet_transfer_confirm(){
					$("#wallet_transfer_confirm").html('<i class="fa fa-refresh fa-spin"></i>');
					$.post("/newwallet/transfer_confirm",{
						//wallet_otp: $("#wallet_otp").val()
					},
					function(data){
						$("#wallet_transfer_confirm").html('ยืนยัน');
						if(data=="ok"){
							$('#s_txt').html("โอนสำเร็จ!");
							$('#success').modal('show');
							sleep(1500).then(() => {
								location.replace('/truemoney/wallet/transfer');
							});
						}else{
							$('#e_txt').html("ผิดพลาด กรุณาลองใหม่อีกครั้ง");
							$('#error').modal('show');
						}
					});
				}
			</script>
		<?php endif; ?>
</div>