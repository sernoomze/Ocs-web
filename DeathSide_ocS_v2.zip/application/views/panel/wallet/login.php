<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<div class="head-nav-tmw">
	<?php include "tmw_nav.php" ?>
	<div class="content-setting">
		<div class="setting-col">
			<div class="setting-box" id="login-true-wallet">
				<h4><span class="label label-warning">ลงชื่อเข้าสู่ระบบ</span> <span class="label label-warning text-black"></span></h4>
				<hr>
				<div>
					<div class="form-group">
						<label for=""><span style="color: #ffa707">ชื่อบัญชี</span> :</label>
						<input type="text" class="form-control" placeholder="เบอร์หรืออีเมลล์ ทรูวอเลต" id="wallet_user">
					</div>
					<div class="form-group">
						<label for=""><span style="color: #ffa707">รหัสผ่าน</span> :</label>
						<input type="password" class="form-control" placeholder="รหัสผ่าน" id="wallet_psw">
					</div>
					<!--<div class="form-group">
						<label for=""><span style="color: #ffa707">รูปแบบ</span> :</label>
						<select class="form-control" id="wallet_type">
							<option>mobile</option>
							<option>email</option>
						</select>
					</div>-->
					<div class="text-center">
						<button type="button" class="btn btn-warning text-black" id="wallet_login">เข้าสู่ระบบ</button>
					</div>
				</div>
			</div>
			<div class="setting-box" id="login-true-wallet-otp">
				<h4><span class="label label-warning">ยืนยัน OTP</span> <span class="label label-warning text-black"></span></h4>
				<hr>
				<div>
					<div class="form-group">
						<label for=""><span style="color: #ffa707">otp</span> : (Ref: <span id="otp_ref"></span>)</label>
						<input type="text" class="form-control" id="wallet_otp">
					</div>
					<div class="text-center">
						<button type="button" class="btn btn-warning text-black" id="wallet_login_otp">ยืนยัน</button>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<script>
	$('#login-true-wallet-otp').hide();
	
	$("#wallet_user").on("keyup", function(e) {
		if (e.keyCode == 13) {
			wallet_login();
		}
	});
	$("#wallet_psw").on("keyup", function(e) {
		if (e.keyCode == 13) {
			wallet_login();
		}
	});
	$("#wallet_otp").on("keyup", function(e) {
		if (e.keyCode == 13) {
			wallet_login_otp();
		}
	});
	$("#wallet_login").click(function() {
		wallet_login();
	});
	$("#wallet_login_otp").click(function() {
		wallet_login_otp();
	});
	function wallet_login(){
		$("#wallet_user").removeClass("had-error");
		$("#wallet_psw").removeClass("had-error");
		$("#wallet_login").html('<i class="fa fa-refresh fa-spin"></i>');
		$.post("/newwallet/login",{
			wallet_user: $("#wallet_user").val(),
			wallet_psw: $("#wallet_psw").val(),
			//wallet_type: $("#wallet_type").val()
		},
		function(data){
			$("#wallet_login").html('เข้าสู่ระบบ');
			var obj = JSON.parse(data);
			if(obj.code==100){
				$('#e_txt').html("กรอกให้ครบทุกช่อง");
				$('#error').modal('show');
				$("#wallet_user").addClass("had-error");
				$("#wallet_psw").addClass("had-error");
			}else if(obj.code==300){
				$('#e_txt').html(obj.text);
				$('#error').modal('show');
			}else if(obj.code==200){
				$('#login-true-wallet').hide();
				$('#login-true-wallet-otp').show();
				$('#otp_ref').text(obj.otp_reference);
				$('#wallet_otp').attr("placeholder", obj.otp_reference);
			}else{
				$('#e_txt').html("ผิดพลาด");
				$('#error').modal('show');
			}
			
			/*$("#wallet_login").html('เข้าสู่ระบบ');
			if(data=="login"){
				$('#s_txt').html("เข้าสู่ระบบสำเร็จ!");
				$('#success').modal('show');
				sleep(1500).then(() => {
					location.replace('/truemoney/wallet');
				});
			}else if(data=="wrong"){
				$('#e_txt').html("ชื่อผู้ใช้ หรือ รหัสผ่าน ไม่ถูกต้อง");
				$('#error').modal('show');
			}else if(data=="emptyvalue"){
				$('#e_txt').html("กรอกให้ครบทุกช่อง");
				$('#error').modal('show');
				$("#wallet_user").addClass("had-error");
				$("#wallet_psw").addClass("had-error");
			}*/
		});
	}
	
	function wallet_login_otp(){
		$.post("/newwallet/login_otp",{
			wallet_otp: $("#wallet_otp").val(),
		},
		function(data){
			if(data=="login"){
				$('#s_txt').html("เข้าสู่ระบบสำเร็จ!");
				$('#success').modal('show');
				sleep(1500).then(() => {
					location.replace('/truemoney/wallet');
				});
			}else if(data=="wrong"){
				$('#e_txt').html("OTP ไม่ถูกต้อง กรุณาลองใหม่อีกครั้ง");
				$('#error').modal('show');
			}
		});
	}
</script>