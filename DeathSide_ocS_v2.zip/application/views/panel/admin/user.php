<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<div class="content-setting">
	<div class="setting-col" style="width:100%">
		<div class="setting-box">
			<?php if(isset($message)) echo $message; ?>
			<h4><span class="label label-primary"> บัญชีทั้งหมด</span></h4>
			<hr>
			<div class="table-responsive">
				<table class="table table-hover">
					<thead>
					<tr>
						<th>Username</th>
						<th>ยอดคงเหลือ</th>
						<th>Email</th>
						<th>สถานะ</th>
						<th>การจัดการ</th>
					</tr>
					</thead>
					<tbody>
						<?php if(empty($row)): ?>
							<tr><td colspan="4" class="text-center"><small>-ยังไม่มีบัญชี-</small></td></tr>
						<?php else: ?>
						<?php foreach($row as $data){ ?>
							<tr>
								<td><?=$data['user']?></td>
								<td><?=$data['balance']?></td>
								<td><?=$data['email']?></td>
								<td><?php if($data['active']==1) echo "ปกติ"; else echo "แบน"; ?></td>
								<td>
									<?php if($data['active']): ?>
									<span class="label label-warning"><a href="<?=base_url('/admin/user/ban/'.$data['user'])?>" class="nounderline text-black">แบน</a></span>
									<?php else: ?>
									<span class="label label-success"><a href="<?=base_url('/admin/user/unban/'.$data['user'])?>" class="nounderline text-black">ปลดแบน</a></span>
									<?php endif; ?>
									<span class="label label-danger"><a href="<?=base_url('/admin/user/del/'.$data['user'])?>" class="nounderline text-black">ลบ</a></span>
									<span class="label label-primary"><a href="<?=base_url('/admin/user/addpoint/'.$data['user'])?>" class="nounderline text-black">เติมเงิน</a></span>
								</td>
							</tr>
						<?php } ?>
						<?php endif; ?>
					</tbody>
				</table>
			</div>
			<div class="count-txt-right">
				<small>ทั้งหมด <?=count($row)?> บัญชี</small>
			</div>
		</div>
	</div>
</div>