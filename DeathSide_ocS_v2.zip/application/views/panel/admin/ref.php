<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<div class="content-setting">
	<div class="setting-col" style="width:100%">
		<div class="setting-box">
			<h4><span class="label label-primary"> รายการรับเงิน</span></h4>
			<hr>
			<div class="table-responsive">
				<table class="table table-hover">
					<thead>
					<tr>
						<th>#</th>
						<th>เลขอ้างอิง</th>
						<th>จำนวน</th>
						<th>เบอร์</th>
						<th>เวลา</th>
						<th>ชื่อ</th>
						<th>สถานะ</th>
					</tr>
					</thead>
					<tbody>
						<?php if(empty($row)): ?>
							<tr><td colspan="6" class="text-center"><small>-ยังไม่มีบัญชี-</small></td></tr>
						<?php else: ?>
						<?php foreach($row as $data){ ?>
							<tr>
								<td><?=$data['id']?></td>
								<td><?=$data['ref_no']?></td>
								<td><?=$data['point']?></td>
								<td><?=$data['phone_no']?></td>
								<td><?=$data['transaction_date']?></td>
								<td><?=$data['name']?></td>
								<td><?php if($data['status']) echo "ยังไม่ใช้"; else echo "ใช้แล้ว"; ?></td>
							</tr>
						<?php } ?>
						<?php endif; ?>
					</tbody>
				</table>
			</div>
			<div class="count-txt-right">
				<small>ทั้งหมด <?=count($row)?> รายการ</small>
			</div>
		</div>
	</div>
</div>