<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<div class="content-setting">
	<div class="setting-col">
		<div class="setting-box">
			<?php if(isset($message)) echo $message; ?>
			<h4><span class="label bg-red1"><i class="fa fa-bank"></i> เติมเงินเข้าสู่บัญชี</span> <span class="label label-warning text-black"><?=$user?></span></h4>
			<hr>
			<form action="<?=base_url('/admin/user')?>" method="POST">
				<div class="form-group">
					<label for="">จำนวนเงิน : </label>
					<input type="number" class="form-control" name="point" placeholder="500" min="1" required>
				</div>
				<div class="form-group">
					<label for="">บัญชี : </label>
					<input type="text" class="form-control" name="user" placeholder="บัญชี" value="<?=$user?>" readonly required>
				</div>
				<div class="text-center">
					<button type="submit" class="btn btn-success">ยืนยัน</button>
					<a type="button" class="btn btn-danger" href="<?=base_url('/admin/user')?>">ยกเลิก</a>
				</div>
			</form>
			<br>
			<div class="count-txt-right">
				<small>ยอดคงเหลือ : <?=$balance?> บาท</small>
			</div>
		</div>
	</div>
</div>