<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<div class="content-setting">
	<div class="setting-col">
		<div class="setting-box">
			<?php if(isset($message)) echo $message; ?>
			<h4><span class="label bg-red1">ตั้งค่าเว็บไซต์</span> <span class="label label-warning text-black"></span></h4>
			<hr>
			<form action="" method="POST">
				<div class="form-group">
					<label for="">ตั้งค่า Token แจ้งเตือน Line : </label>
					<input type="text" class="form-control" name="token_line" value="<?=$line_token?>" placeholder="Token line">
				</div>
				<div class="form-group">
					<label for="">ชื่อเว็บไซต์ : </label>
					<input type="text" class="form-control" name="website_name" value="<?=$website_name?>" placeholder="ชื่อเว็บไซต์ Example. Reseller">
				</div>
				<div class="form-group">
					<label for="">ไอคอนเว็บไซต์ : </label>
					<input type="text" class="form-control" name="website_icon" value="<?=$website_icon?>" placeholder="ลิ้งไอคอน">
				</div>
				<div class="form-group">
					<label for="">URL เว็บไซต์ : </label>
					<input type="text" class="form-control" name="website_url" value="<?=$website_url?>" placeholder="URL เว็บไซต์">
				</div>
				<div class="text-center">
					<button type="submit" class="btn btn-success">ยืนยัน</button>
					<a type="button" class="btn btn-danger" href="<?=base_url('/admin/setting')?>">ยกเลิก</a>
				</div>
			</form>
			<hr>
			<button type="button" class="btn btn-warning" id="backup_sql">Backup Database</button>
			<div class="count-txt-right">
				<small>ตั้งค่าเว็บไซต์ </small>
			</div>
			
		</div>
	</div>
</div>
<script>
$('#backup_sql').click(function() {
	location.replace("/admin/backup_sql");
});
</script>