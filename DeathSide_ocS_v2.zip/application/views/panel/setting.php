<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<div class="content-setting">
	<div class="setting-col">
		<div class="setting-box">
			<h4><span class="label label-primary"><i class="fa fa-gear fa-spin"></i> ตั้งค่าบัญชี</span> <span class="label label-warning text-black"><?=$_SESSION['username']?></span></h4>
			<hr>
			<div>
				<h5 class="text-left"><span class="label label-default">เปลี่ยนรหัสผ่าน</span></h5>
				<br>
				<div class="form-group">
					<label for="pwd_old">รหัสผ่านเก่า :</label>
					<input type="password" class="form-control" name="pwd_old" id="pwd_old" placeholder="รหัสผ่านเก่า">
				</div>
				<div class="form-group">
					<label for="pwd_new">รหัสผ่านใหม่ :</label>
					<input type="password" class="form-control" name="pwd_new" id="pwd_new" placeholder="รหัสผ่านใหม่">
				</div>
				<div class="form-group">
					<label for="pwd_new_re">รหัสผ่านใหม่อีกครั้ง :</label>
					<input type="password" class="form-control" name="pwd_new_re" id="pwd_new_re" placeholder="รหัสผ่านใหม่อีกครั้ง">
				</div>
				<div class="text-center">
					<button type="button" class="btn btn-warning text-black" id="changepassword"><i class="fa fa-edit"></i> บันทึก</button>
				</div>
			</div>
		</div>
	</div>
</div>
<script>
	$("#pwd_old").on("keyup", function(e) {
		if (e.keyCode == 13) {
			changepsw();
		}
	});
	$("#pwd_new").on("keyup", function(e) {
		if (e.keyCode == 13) {
			changepsw();
		}
	});
	$("#pwd_new_re").on("keyup", function(e) {
		if (e.keyCode == 13) {
			changepsw();
		}
	});
	$("#changepassword").click(function() {
		changepsw();
	});
	function changepsw(){
		$("#pwd_old").removeClass("had-error");
		$("#pwd_new").removeClass("had-error");
		$("#pwd_new_re").removeClass("had-error");
		$.post("/changepassword",{
			pwd_old: $("#pwd_old").val(),
			pwd_new: $("#pwd_new").val(),
			pwd_new_re: $("#pwd_new_re").val()
		},
		function(data){
			if(data=='notmatch'){
				$('#e_txt').html("รหัสผ่านไม่ตรงกัน");
				$('#error').modal('show');
				sleep(1500).then(() => {
					$("#pwd_new").addClass("had-error");
					$("#pwd_new_re").addClass("had-error");
				});
			}else if(data=="oldpasswrong"){
				$('#e_txt').html("รหัสผ่านเก่าไม่ถูกต้อง");
				$('#error').modal('show');
				sleep(1500).then(() => {
					$("#pwd_old").addClass("had-error");
				});
			}else if(data=="len6"){
				$('#e_txt').html("รหัสผ่านต้องมีความยาว<br>ไม่ต่ำกว่า 6 ตัว");
				$('#error').modal('show');
				sleep(1500).then(() => {
					$("#pwd_new").addClass("had-error");
					$("#pwd_new_re").addClass("had-error");
				});
			}else if(data=="empty"){
				$('#e_txt').html("กรุณากรอกให้ครบทุกช่อง");
				$('#error').modal('show');
				sleep(1500).then(() => {
					$("#pwd_old").addClass("had-error");
					$("#pwd_new").addClass("had-error");
					$("#pwd_new_re").addClass("had-error");
				});
			}else if(data=="ok"){
				$('#s_txt').html("เปลี่ยนรหัสผ่านสำเร็จ!");
				 $('#success').modal('show');
				 sleep(1500).then(() => {
					$("#pwd_old").val('');
					$("#pwd_new").val('');
					$("#pwd_new_re").val('');
				});
			}else{
				$('#e_txt').html("มีบางอย่างผิดพลาด");
				$('#error').modal('show');
			}
		});
	}
</script>