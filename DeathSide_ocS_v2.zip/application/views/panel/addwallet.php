<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<div class="content-setting">
	<div class="setting-col">
		<div class="setting-box">
			<?php if(isset($message)) echo $message; ?>
			<h4><span class="label label-primary"><i class="fa fa-bank"></i> เพิ่มเบอร์วอเล็ท</span></h4>
			<hr>
			<h5 class="text-left"><span class="label label-default">กรอกเบอร์วอเล็ทและพิน</span></h5>
			<br>
			<?php if(empty($edit)): ?>
			<form action="<?=base_url('/server/confirmaddwallet/')?>" method="POST">
				<div class="form-group">
					<label for="usr">เบอร์วอเล็ท:</label>
					<input type="text" class="form-control" name="mobile" pattern=".{10}" placeholder="เบอร์วอเล็ท 10 หลัก" required>
				</div>
				<div class="form-group">
					<label for="usr">พิน 4 หลัก:</label>
					<input type="text" class="form-control" name="pin" pattern=".{4}" placeholder="พิน 4 หลัก" required>
				</div>
				<div class="text-center">
					<button type="submit" class="btn btn-success">เพิ่ม</button>
					<a type="button" class="btn btn-danger" href="<?=base_url('/main/addpoint')?>">ยกเลิก</a>
				</div>
			</form>
			<?php else: ?>
			<form action="<?=base_url('/server/confirmeditwallet/')?>" method="POST">
				<div class="form-group">
					<label for="usr">เบอร์วอเล็ท:</label>
					<input type="text" class="form-control" name="mobile" pattern=".{10}" value="<?=$edit->mobile?>" placeholder="เบอร์วอเล็ท 10 หลัก" required>
				</div>
				<div class="form-group">
					<label for="usr">พิน 4 หลัก:</label>
					<input type="text" class="form-control" name="pin" pattern=".{4}" value="<?=$edit->pin?>" placeholder="พิน 4 หลัก" required>
				</div>
				<div class="form-group">
					<label for="usr">Ref.Token วอเลท:</label>
					<div class="input-group">
						<input type="text" class="form-control" name="ref_token" id="ref_token" value="<?=$edit->ref_token?>" placeholder="ref token">
						<div class="input-group-btn">
							<button type="button" class="btn btn-warning" id="generate_ref_token">สร้าง Ref.Token</button>
						</div>
					</div>
				</div>
				<div class="text-center">
					<button type="submit" class="btn btn-success">บันทึก</button>
					<a type="button" class="btn btn-danger" href="<?=base_url('/main/addpoint')?>">ยกเลิก</a>
					<a type="button" class="btn btn-danger" href="<?=base_url('/server/delwallet')?>">ลบ</a>
				</div>
			</form>
			<div id="generate_ref_token_otp" class="modal fade" role="dialog">
				<div class="modal-dialog">
					<div class="modal-content">
						<div class="modal-header">
							<button type="button" class="close" data-dismiss="modal">&times;</button>
							<h4><span class="label label-warning">ยืนยัน OTP</span> <span class="label label-warning text-black"></span></h4>
						</div>
						<div class="modal-body">
							<div>
								<div class="form-group">
									<label for=""><span style="color: #ffa707">OTP</span> : (Ref: <span id="otp_ref"></span>)</label>
									<input type="text" class="form-control" id="wallet_otp">
								</div>
								<div class="text-center">
									<button type="button" class="btn btn-warning text-black" id="wallet_login_otp">ยืนยัน</button>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<script>
				$('#generate_ref_token').click(function() {
					$('#generate_ref_token').html('<i class="fa fa-refresh fa-spin"></i>');
					$.post("/server/generate_ref_token",{
						
					},
					function(data){
						$('#generate_ref_token').html('สร้าง Ref.Token');
						
						var obj = JSON.parse(data);
						
						if(obj.code==100){
							$('#e_txt').html(obj.text);
							$('#error').modal('show');
						}else if(obj.code==200){
							$('#otp_ref').text(obj.otp_reference);
							$('#wallet_otp').attr("placeholder", obj.otp_reference);
							$("#wallet_otp").val('');
							$('#generate_ref_token_otp').modal('show');
						}else if(obj.code==300){
							$('#e_txt').html(obj.text);
							$('#error').modal('show');
						}else{
							$('#e_txt').html("ผิดพลาด");
							$('#error').modal('show');
						}
					});
				});
				
				$("#wallet_otp").on("keyup", function(e) {
					if (e.keyCode == 13) {
						wallet_login_otp();
					}
				});
				
				$("#wallet_login_otp").click(function() {
					wallet_login_otp();
				});
				
				function wallet_login_otp(){
					$('#wallet_login_otp').html('<i class="fa fa-refresh fa-spin"></i>');
					$.post("/server/generate_ref_token_otp",{
						wallet_otp: $("#wallet_otp").val(),
					},
					function(data){
						$('#wallet_login_otp').html('ยืนยัน');
						var obj = JSON.parse(data);
						
						if(obj.code==100){
							$('#e_txt').html(obj.text);
							$('#error').modal('show');
						}else if(obj.code==200){
							$('#ref_token').val(obj.reference_token);
							$('#generate_ref_token_otp').modal('hide');
						}else if(obj.code==300){
							$('#e_txt').html(obj.text);
							$('#error').modal('show');
						}else{
							$('#e_txt').html("ผิดพลาด");
							$('#error').modal('show');
						}
					});
				}
			</script>
			<?php endif; ?>
		</div>
	</div>
</div>