<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Website_model extends CI_Model {
	
	public function __construct() {
		parent::__construct();
		$this->load->database();
		$this->load->model('user_model');
		date_default_timezone_set("Asia/Bangkok");
	}
	
	public function get_website_info(){
		$query = $this->db->get('website_info');
		return $query->result_array();
	}
	
	public function get_line_token(){
		$this->db->where('desc_', 'line_token');
		$query = $this->db->get('website_info');
		return $query->row_array();
	}
	
	public function get_website_name(){
		$this->db->where('desc_', 'website_name');
		$query = $this->db->get('website_info');
		return $query->row_array();
	}
	
	public function get_website_icon(){
		$this->db->where('desc_', 'website_icon');
		$query = $this->db->get('website_info');
		return $query->row_array();
	}
	
	public function get_website_url(){
		$this->db->where('desc_', 'website_url');
		$query = $this->db->get('website_info');
		return $query->row_array();
	}
	
	public function update_website_name($website_name){
		$row = array(
			'value' => $website_name
		);
		$this->db->where('desc_', 'website_name');
		return $this->db->update('website_info', $row);
	}
	
	public function update_line_token($line_token){
		$row = array(
			'value' => $line_token
		);
		$this->db->where('desc_', 'line_token');
		return $this->db->update('website_info', $row);
	}
	
	public function update_website_icon($icon){
		$row = array(
			'value' => $icon
		);
		$this->db->where('desc_', 'website_icon');
		return $this->db->update('website_info', $row);
	}
	
	public function update_website_info($data){
		/*$s = false;
		if($this->update_website_name($data['website_name'])){
			$s = true;
		}
		if($this->update_line_token($data['line_token'])){
			$s = true;
		}
		if($this->update_website_icon($data['website_icon'])){
			$s = true;
		}
		return $s;*/
		
		foreach($data as $key => $val){
			$row = array(
				'value' => $val
			);
			$this->db->where('desc_', $key);
			$state = $this->db->update('website_info', $row);
			
			if($state==false){
				return $state;
			}
		}
		return $state;
	}
	
	public function update_config_website($ip){
		$path = $_SERVER["DOCUMENT_ROOT"]."/application/config/config.php";
		
		if(file_exists($path)){
			$lines = file($path);
			$result = '';

			foreach($lines as $line) {
				if(substr($line, 0, 19) == '$config[\'base_url\']') {
					$result .= '$config[\'base_url\'] = \''.$ip."';\n";
				} else {
					$result .= $line;
				}
			}

			file_put_contents($path, $result);
		}
	}
	
	public function get_msg_notice($order='asc'){
		$this->db->order_by('id', $order);
		$query = $this->db->get('msg_notice');
		return $query->result_array();
	}
	
	public function add_msg($msg){
		$row = array(
			'id' 		=> NULL,
			'text_'		=> "<p>".$msg."</p>"
		);
		return $this->db->insert('msg_notice', $row);
	}
	
	public function del_msg($id){
		$this->db->where('id', $id);
		return $this->db->delete('msg_notice');
	}
}
?>