<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Openvpn_model extends CI_Model {
	public function __construct() {
		parent::__construct();
		$this->load->database();
		$this->load->library('ssh_lib');
	}
	
	public function parseLog($log, $proto){
	$handle = fopen($log, "r");
	$status = array();
	$uid = 0;
		while (!feof($handle)) {
			$buffer = fgets($handle, 4096);
			unset($match);
			if (preg_match("/^Updated,(.+)/", $buffer, $match)) {
				$status['updated'] = $match[1];
			}
			if (preg_match("/^(.+),(\d+\.\d+\.\d+\.\d+\:\d+),(\d+),(\d+),(.+)$/", $buffer, $match)) {
				if ($match[1] <> "Common Name") {
					$cn = $match[1];
					$userlookup[$match[2]] = $uid;
					$status['users'][$uid]['CommonName'] = $match[1];
					$status['users'][$uid]['RealAddress'] = $match[2];
					$status['users'][$uid]['BytesReceived'] = $this->sizeformat($match[3]);
					$status['users'][$uid]['BytesSent'] = $this->sizeformat($match[4]);
					$status['users'][$uid]['Since'] = $match[5];
					$status['users'][$uid]['Proto'] = $proto;
					$uid++;
				}
			}
			if (preg_match("/^(\d+\.\d+\.\d+\.\d+),(.+),(\d+\.\d+\.\d+\.\d+\:\d+),(.+)$/", $buffer, $match)) {
				if ($match[1] <> "Virtual Address") {
					$address = $match[3];
					$uid = $userlookup[$address];
					$status['users'][$uid]['VirtualAddress'] = $match[1];
					$status['users'][$uid]['LastRef'] = $match[4];
				}
			}

		}
		fclose($handle);
		return($status);
	}
	
	public function sizeformat($bytesize){
		$i=0;
		while(abs($bytesize) >= 1024){
			$bytesize=$bytesize/1024;
			$i++;
			if($i==4) break;
		}
		$units = array("Bytes","KB","MB","GB","TB");
		$newsize=round($bytesize,2);
		return("$newsize $units[$i]");
	}
	
	public function create_openvpn_log($data, $sid){
		
		$data_tmp = $this->ssh_lib->get_openvpn_log($data);
		$svname = $sid;
		$strFileName = "openvpnlog/openvpn-status-$svname.log";
		$objFopen = fopen($strFileName, 'w');
        fwrite($objFopen, $data_tmp);
        fclose($objFopen);
	}
	
	public function get_openvpn_log($sid, $proto = "TCP"){
		$log = "openvpnlog/openvpn-status-$sid.log";
		return $this->parseLog($log, $proto);
	}
	
	public function get_server_usage($data){
		return $this->ssh_lib->get_server_usage($data);
	}
}
?>