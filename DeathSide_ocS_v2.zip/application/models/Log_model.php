<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Log_model extends CI_Model {
	public function __construct() {
		parent::__construct();
		$this->load->database();
	}
	
	public function insert_log($data){
		$row = array(
			'id' => NULL,
			'user' => $data['user'],
			'text' => $data['text'],
			'date_' => $data['date']
		);
		return $this->db->insert('log_', $row);
	}
}
?>