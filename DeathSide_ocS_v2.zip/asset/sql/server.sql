
create table server_user(
	s_id	varchar(5),
	s_user	varchar(30),
	s_pass	varchar(30),
	
	constraint server_pk PRIMARY KEY(s_id),
	constraint server_fk_2 FOREIGN KEY(s_id)
		REFERENCES server(s_id)
);

create table ssh_user(
	ssh_u_id	varchar(7),
	ssh_user	varchar(30),
	ssh_pass	varchar(30),
	s_id		varchar(5),
	create_by	varchar(255),
	create_at	varchar(30),
	expire_at	varchar(30),
	expire_day	int(3),
	constraint ssh_user_pk PRIMARY KEY(ssh_u_id),
	constraint ssh_user_fk_2 FOREIGN KEY(s_id)
		REFERENCES server(s_id)
);

create table user(
	id		int(10) NOT NULL AUTO_INCREMENT,
	user	varchar(255),
	password	varchar(255),
	admin_		int(1),
	constraint user_pk PRIMARY KEY(id, user)
);