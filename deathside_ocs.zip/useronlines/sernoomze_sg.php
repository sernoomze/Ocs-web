<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>SerNooMzE VPN</title>
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
<link rel="stylesheet" href="/bootstrap/plugins/datatables/dataTables.bootstrap.css">	 
<link rel="stylesheet" href="/bootstrap/asset/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">  
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
 <link rel="stylesheet" href="/bootstrap/asset/dist/css/AdminLTE.min.css">
 <link rel="stylesheet" href="/bootstrap/asset/dist/css/skins/_all-skins.min.css">
 <link href="/bootstrap/asset/css/bootstrap-dialog.min.css" rel="stylesheet">
 <link href="/bootstrap/asset/css/animate.min.css" rel="stylesheet"/>

  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>

  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->
 <style>
    .example-modal .modal {
      position: relative;
      top: auto;
      bottom: auto;
      right: auto;
      left: auto;
      display: block;
      z-index: 1;
    }

    .example-modal .modal {
      background: transparent !important;
    }
  </style>
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Merriweather:400,300,300italic,400italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="/bootstrap/asset/css/font-awesome/css/font-awesome.min.css" type="text/css">
    <!-- Plugin CSS -->
    <link rel="stylesheet" href="/bootstrap/asset/css/animate.min.css" type="text/css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="/bootstrap/asset/css/creativ.css" type="text/css">
	 
</head>
<body class="hold-transition skin-blue-light fixed sidebar-mini">

    
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <title>SerNooMzE VPN</title>
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
</head>
<body class="hold-transition skin-red-light fixed sidebar-mini">
<div class="wrapper">
  <header class="main-header">
    <a href="/main" class="logo">
      <span class="logo-mini">SerNooMzE</span>
      <span class="logo-md"><b> SerNooMzE </b>VPN</span>
    </a>
<body>
    <nav class="navbar navbar-static-top">
      <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
        <span class="sr-only">Toggle navigation</span> MENU
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </a>
	  
      <div class="navbar-custom-menu">
        <ul class="nav navbar-nav">
					<li class="dropdown messages-menu">
			<a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
              <i class="fa fa-btc">เติมเงิน</i>
              <span class="label label-danger fa-spin">➤</span>
            </a>
            <ul class="dropdown-menu">
				<p>
					<center><span class="description-text"><span style="font-size: 20px;"  class="btn btn-warning">ระบบการเติมเงิน</span></center>
				</p>
				<p>
					<center><span class="description-text"><span style="font-size: 16px;"  class="badge bg-aqua">เลือกระบบการเต็มเงินที่ท่านสะดวก</span></center>
				</p>
			<li>
				<ul class="menu">
					<li>
						<center>
							<div class="pull-left">
							<li><form action="/topup/input.php" method="post">
							<input name="user" type="hidden" value="{{ @me->username }}" id="user">			 
			 			        <class="glyphicon glyphicon-usd"> <button type="submit" class="btn btn-sm bg-orange"> TRUEWALLET</button></li></form>
								</div>
							<p>◄ ระบบเลขอ้างอิง</p>
							</a>
						</center>
					</li>
					<li>
						<center>
						<div class="pull-left">
							<a href="/home/topups"><class="glyphicon glyphicon-usd" class="btn btn-sm bg-orange"></i> TRUEMONEY</a>
							</div>
							</a>
						<p>◄ ระบบบัตรเงินสด</p>
						</center>
					</li>
				</ul>
			</li>           
			<li class="footer"><a href="#">ระบบเติมเงิน</a></li>
            </ul>
          </li>
          <li class="dropdown user user-menu">			 
            <a href="#" class="dropdown-toggle" data-toggle="dropdown"> 					 
				     <span class="fa fa-cog" alt="User Image"> 
              <span class="hidden-xs">MEMBER</span>
            </a>
            <ul class="dropdown-menu">             
              <li class="user-header">
                <img src="/bootstrap/asset/img/users.png" class="img-circle" alt="User Image">
                <p>
                 MEMBER	 <small></small> <strong>เงินของคุณ xxx บาท</strong>               <small>xxx@xxx.com</small>
                </p>
              </li>
              <li class="user-footer">
                <div class="pull-left">
                  <a href="/home/setting" class="btn btn-default"> เปลี่ยนรหัสผ่าน</a>
                </div>
                <div class="pull-right">
                  <a href="/logout"  class="btn btn-default" > ออกจากระบบ</a>
                </div>
              </li>
            </ul>
          </li>
          <li>
						      
          </li>
        </ul>
      </div>
    </nav>
  </header>
  <aside class="main-sidebar">
    <section class="sidebar">
      <div class="user-panel">
        <div class="pull-left image">
          <img src="/bootstrap/asset/img/users.png" class="img-circle" alt="User Image">
        </div>
        <div class="pull-left info">
          <p>MEMBER</p>
          <a href="#"><i class="fa fa-circle text-success"></i>MEMBER</a>
        </div>
      </div>
      <ul class="sidebar-menu">
				<li class="header">เมนู</li>
        <li><a href="/main"><i class="fa fa-home"></i> <span>หน้าหลัก</span></a></li>      
             		
<li class="treeview">
	<li><a href="/home/member/server/"><i class="fa fa-shopping-cart"></i> <span>เช่า VPN</span></a>
</li>
<li class="treeview">
	<li><a href="/userstatus"><i class="fa fa-calendar"></i> <span>เช็คสถานะวันหมดอายุ</span></a>
</li>
<li class="treeview">
	<a href="/useronline"><i class="fa fa-send"></i> <span>เช็คบัญชีที่ออนไลน์</span></a>
	</li>
	<li class="treeview">
	<li><a href="/home/config"><i class="fa fa-cloud-download"></i> <span>Download Config</span></a>
</li>
		<li class="treeview">
          <a href="#">
            <i class="fa fa-money"></i> <span>เติมเงินระบบอัตโนมัติ</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
		  <ul class="treeview-menu">
		  <center>
			<li><form action="/topup/input.php" method="post">
							<input name="user" type="hidden" value="{{ @me->username }}" id="user">			 
			 			        <class="glyphicon glyphicon-usd"> <button type="submit" class="btn btn-sm btn-default"> TRUEWALLET เลขอ้างอิง </button></li></form>
			<li><a href="/home/topups"><class="glyphicon glyphicon-usd" class="btn btn-sm btn-default"></i> TRUEMONEY บัตรเงินสด</a></li>
		</ul>
		</center>
	</li>        
        <li class="treeview">
          <a href="#">
            <i class="glyphicon glyphicon-phone"></i> <span>วิธีใช้งานเบื้องต้น</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
          	<li><a href="/home/android"><i class="fa fa-android"></i> วิธีใช้งานในระบบ Android.</a></li>
        </ul>       	
        
        		
         <li class="treeview">
          <a href="#">
            <i class="fa fa-facebook"></i>
				       <span>FACEBOOK</span>
                 <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">        
        <li><a href="https://www.facebook.com/groups/1796117170406824/"><i class="fa fa-facebook-official"></i> <span>กลุ่มFacebook</span></a></li>       
        <li><a href="https://www.facebook.com/aichinova.keawchan"><i class="fa fa-facebook-official"></i> <span>ติดต่อผู้ดูแล</span></a></li> 
          </ul>                   
        <li><a href="/home/setting"><i class="glyphicon glyphicon-wrench"></i> <span>เปลี่ยนรหัสผ่าน</span></a></li>
        <li><a href="/logout" ><i class="fa fa-sign-out" ></i><span>ออกจากระบบ</span></a></li>
      </ul>
    </section>
  </aside>

<div class="content-wrapper">
<section class="content-header">
<h1>
      <span class="description-text"><span style="font-size: 25px;"  class="badge bg-orange">USER ONLINE </span></span>
</h1>
<ol class="breadcrumb">
<li><a href="#"><i class="fa fa-home"></i> Home</a></li>
<li class="active">useronline</li>
</ol>
</section>
<section class="content">
<div class="row">
<div class="col-md-10">
<div class="box box-primary">
<div class="box-header with-border">
<h3 class="box-title">Ser_SG</h3>
<div class="box-tools pull-right">
<div class="has-feedback">
<a href="sernoomze_th.php" class="btn bg-navy btn-block margin-bottom">เซิฟถัดไป</a>
</div>
</div>
</div>
<div class="box-body no-padding">
<div class="mailbox-controls">
<h4 class="box-title text-center"><B>สถิติการใช้ Bandwidth ของ USER ประจำวัน</B></h4>
</div>
</div>
<div class="table-responsive">
                    <?php
    $urlWithoutProtocol = "http://sernoomze-vpn.info/online.php"; /// <-----แก้ตรงนี้
    $request         = "";
    $isRequestHeader = false;
 
    $exHeaderInfoArr   = array();
    $exHeaderInfoArr[] = "Content-type: text/xml";
    $exHeaderInfoArr[] = "Authorization: "."Basic ".base64_encode("authen_user:authen_pwd");
 
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $urlWithoutProtocol);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $request);
    curl_setopt($ch, CURLOPT_HEADER, (($isRequestHeader) ? 1 : 0));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    if( is_array($exHeaderInfo) && !empty($exHeaderInfo) )
    {
        curl_setopt($ch, CURLOPT_HTTPHEADER, $exHeaderInfo);
    }
    $response = curl_exec($ch);
    curl_close($ch);
 
    echo $response;
?> 

<tbody>
<tr>
﻿</tr>
</tbody>
</div>
</div>
</div>
</div>
</div>
</div>
</section>
</body>
</html>
<script src="/bootstrap/plugins/jQuery/jquery-2.2.3.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/metisMenu/2.0.0/metisMenu.min.js"></script>
<link rel="stylesheet" href="/bootstrap/plugins/daterangepicker/daterangepicker.css">
<link rel="stylesheet" href="/bootstrap/plugins/datepicker/datepicker3.css">
<script src="/bootstrap/asset/js/bootstrap.min.js"></script>
<script src="/bootstrap/plugins/slimScroll/jquery.slimscroll.min.js"></script>
<script src="/bootstrap/plugins/fastclick/fastclick.js"></script>
<script src="/bootstrap/asset/dist/js/app.min.js"></script>
<script src="/bootstrap/plugins/datatables/jquery.dataTables.min.js"></script>
<script src="/bootstrap/plugins/datatables/dataTables.bootstrap.min.js"></script>

<script>
  $(function () {
    $('#lowclass').DataTable({
	  	"aLengthMenu": [[1, -1]],
      "paging": true,
      "lengthChange": false,
      "searching": true,
      "ordering": false,
      "info": true,
      "autoWidth": false,
    });
  });
</script>

<script>
  $(function () {
    $('#fornesia').DataTable({
      "paging": true,
      "lengthChange": true,
      "searching": true,
      "ordering": true,
      "info": true,
      "autoWidth": false,
    });
  });
</script>
  <script src="/bootstrap/plugins/datepicker/bootstrap-datepicker.js"></script>
    <script src="/bootstrap/asset/js/bootstrap-dialog.min.js"></script>
    <script type="text/javascript">
        $('.input-group.date').datepicker({
            format: "yyyy/mm/dd",
            weekStart: 1,
            clearBtn: true,
            language: "th",
            autoclose: true,
            todayHighlight: true
        });
        $('.hapus').click(function(e) {
            e.preventDefault();
            BootstrapDialog.confirm({
                title: 'Confirm',
                message: ' Are you sure?',
                type: BootstrapDialog.TYPE_DANGER,
                closable: true,
                btnCancelLabel: 'Cancel',
                btnOKLabel: 'Delete',
                btnOKClass: 'btn-danger',
                callback: function(result) {
                    if(result) {
                        location.href = $('.hapus').attr('href');
                    }
                }
            });
        });
        function print_report() {
            window.print();
            return false;
        }
    </script>t>