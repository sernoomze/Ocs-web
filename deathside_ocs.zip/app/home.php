<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <title>DeathSide VPN</title>
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
</head>
<div class="wrapper">
  <header class="main-header">
    <a href="/main" class="logo bg-red">
      <span class="logo-md "><b> DeathSide </b>VPN</span>
    </a>
    <nav class="navbar navbar-static-top bg-orange">
      <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
        <span class="sr-only">Toggle navigation</span> MENU
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </b></a>
      <div class="navbar-custom-menu">
        <ul class="nav navbar-nav">
					<li class="dropdown messages-menu">
			<a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
              <i class="fa fa-btc">เติมเงิน</i>
              <span class="label label-danger fa-spin">➤</span>
            </a>
            <ul class="dropdown-menu">
				<p>
					<center><span class="description-text"><span style="font-size: 20px;"  class="btn btn-warning">ระบบการเติมเงิน</span></center>
				</p>
				<p>
					<center><span class="description-text"><span style="font-size: 16px;"  class="badge bg-aqua">เลือกระบบการเต็มเงินที่ท่านสะดวก</span></center>
				</p>
			<li>
				<ul class="menu">
					<li>
						<center>
							<div class="pull-left">
							<li><form action="/topup/input.php" method="post">
							<input name="user" type="hidden" value="{{ @me->username }}" id="user">			 
			 			        <class="glyphicon glyphicon-usd"> <button type="submit" class="btn btn-sm bg-orange"> TRUEWALLET</button></li></form>
								</div>
							<p><span class="description-text"><span style="font-size: 15px;"  class="badge bg-black">◄ ระบบเลขอ้างอิง</span></p>
							</a>
						</center>
					</li>
					<li>
						<center>
						<div class="pull-left">
							<a href="/home/topups"><class="glyphicon glyphicon-usd" class="btn btn-sm bg-orange"></i> TRUEMONEY</a>
							</div>
							</a>
						<p>  <span class="description-text"><span style="font-size: 15px;"  class="badge bg-black">◄ ระบบบัตรเงินสด</span></p>
						</center>
					</li>
				</ul>
			</li>           
			<li class="footer"><a href="#">ระบบเติมเงิน</a></li>
            </ul>
          </li>
          <li class="dropdown user user-menu">			 
            <a href="#" class="dropdown-toggle" data-toggle="dropdown"> 					 
				     <span class="fa fa-cog" alt="User Image"> 
              <span class="hidden-xs">{{ @me->username }}</span>
            </a>
            <ul class="dropdown-menu">             
              <li class="user-header bg-orange">
                <img src="/bootstrap/asset/img/users.png" class="img-circle" alt="User Image">
                <p>
                  {{ @me->username }} {{ @me->lastname }}
				 <small></small> <strong>เงินของคุณ : {{ @me->saldo }} บาท</strong>               <small>{{ @me->email }}</small>
                </p>
              </li>
              <li class="user-footer">
                <div class="pull-left">
                  <a href="/home/setting" class="btn btn-default"> เปลี่ยนรหัสผ่าน</a>
                </div>
                <div class="pull-right">
                  <a href="/logout"  class="btn btn-default" > ออกจากระบบ</a>
                </div>
              </li>
            </ul>
          </li>
          <li>
          </li>
        </ul>
      </div>
    </nav>
  </header>
  <aside class="main-sidebar">
    <section class="sidebar">
      <div class="user-panel">
        <div class="pull-left image">
       <img src="/bootstrap/asset/img/users.png" class="img-circle" alt="User Image">
        </div>
        <div class="pull-left info">
          <p>{{ @me->username }}</p>
          <a href="#"><i class="fa fa-circle text-success"></i> {{ @me->type==1?'ADMIN':'MEMBER' }}</a>
        </div>
      </div>
      <ul class="sidebar-menu">
				<li class="header">เมนู</li>
        <li><a href="/main"><i class="fa fa-home"></i> <span>หน้าหลัก</span></a></li>      
             <check if="{{ @me->type==1 }}">
           <true>					
        <li class="treeview">
          <a href="#">
            <i class="fa fa-cloud"></i> <span>รายชื่อเซิร์ฟเวอร์</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="/home/admin/server"><i class="fa fa-cloud-upload"></i> เซิร์ฟเวอร์ ทั้งหมด</a></li>
            <li><a href="/home/admin/server/add"><i class="fa fa-cloud-download"></i> เพิ่มเซิร์ฟเวอร์</a></li>
          </ul>
        </li>
        <li class="treeview">
          <a href="#">
            <i class="fa fa-group"></i> <span>รายชื่อบัญชี</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="/home/admin/seller"><i class="fa fa-user-md"></i> รายชื่อทั้งหมด</a></li>
            <li><a href="/home/admin/seller/add"><i class="fa fa-user-plus"></i> เพิ่มบัญชี</a></li>
          </ul>
        </li>
	<li class="treeview">
          <a href="#">
            <i class="fa fa-calendar"></i><span>เช็คสถานะบัญชี</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
									<li><a href="/userstatus" class="fa fa-calendar"></i> <span>เช็ควันหมดอายุ&การใช้งาน</span></a></li>
        </ul>
	</li>
	<li class="treeview">
          <a href="#">
            <i class="fa fa-send"></i><span>เช็คบัญชีที่ออนไลน์</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
									<li><a href="/useronline" class="fa fa-send"></i> <span>เช็คบัญชีที่ออนไลน์</span></a></li>
        </ul>
	</li>
		</true>
		<false>		
<li class="treeview">
	<li><a href="/home/member/server/"><i class="fa fa-shopping-cart"></i> <span>เช่า VPN</span></a>
</li>
<li class="treeview">
	<li><a href="/userstatus"><i class="fa fa-calendar"></i> <span>เช็คสถานะวันหมดอายุ</span></a>
</li>
<li class="treeview">
	<a href="/useronline"><i class="fa fa-send"></i> <span>เช็คบัญชีที่ออนไลน์</span></a>
	</li>
	</li>        
	<li class="treeview">
	<li><a href="/speedtest/testspeednet.html"><i class="fa fa-dashboard"></i> <span>Test Speed Net</span></a>
</li>
	<li class="treeview">
	<li><a href="/home/config"><i class="fa fa-cloud-download"></i> <span>Download Config</span></a>
</li>
<li class="treeview">
	<li><a href="/upload/file/SerNooMzE_VPN-Web.apk"><i class="fa fa-download"></i> <span>Download App เช่า</span></a>
</li>
		<li class="treeview">
          <a href="#">
            <i class="fa fa-money"></i> <span>เติมเงินระบบอัตโนมัติ</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
		  <ul class="treeview-menu">
		  <center>
			<li><form action="/topup/input.php" method="post">
							<input name="user" type="hidden" value="{{ @me->username }}" id="user">			 
			 			        <class="glyphicon glyphicon-usd"> <button type="submit" class="btn btn-sm btn-default"> TRUEWALLET เลขอ้างอิง </button></li></form>
			<p><li><a href="/home/topups"><class="glyphicon glyphicon-usd" class="btn btn-sm btn-default"></i> TRUEMONEY บัตรเงินสด</a></li></p>
		</ul>
		</center>
        <li class="treeview">
          <a href="#">
            <i class="glyphicon glyphicon-phone"></i> <span>วิธีใช้งานเบื้องต้น</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
          	<li><a href="/home/android"><i class="fa fa-android"></i> วิธีใช้งานในระบบ Android.</a></li>
        </ul>       	
        </false>
        </check>		
         <li class="treeview">
          <a href="#">
            <i class="fa fa-facebook"></i>
				       <span>FACEBOOK</span>
                 <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">        
        <li><a href="https://www.facebook.com/groups/1796117170406824/"><i class="fa fa-facebook-official"></i> <span>กลุ่มFacebook</span></a></li>       
        <li><a href="https://www.facebook.com/aichinova.keawchan"><i class="fa fa-facebook-official"></i> <span>ติดต่อผู้ดูแล</span></a></li> 
          </ul>                   
        <li><a href="/home/setting"><i class="glyphicon glyphicon-wrench"></i> <span>เปลี่ยนรหัสผ่าน</span></a></li>
        <li><a href="/logout" ><i class="fa fa-sign-out" ></i><span>ออกจากระบบ</span></a></li>
      </ul>
    </section>
  </aside>
  </body>

  <include href="{{ @subcontent }}"/> 

<footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>BY SerNooMzE VPN</b>
    </div>
    <strong>Copyright © 2018 <a href="/">SerNooMzE VPN</a>.</strong>
  </footer>

  <div class="control-sidebar-bg"></div>  
</div>