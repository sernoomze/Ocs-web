<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
  <div class="content-wrapper">
    <section class="content-header">
      <h1>
    <span class="description-text"><span style="font-size: 18px;"  class="badge bg-orange">   วิธีใช้งานเบื้องต้นสำหรับ App SerNooMzE VPN และ OpenVPN Connect</span></span>
      </h1>
    <ol class="breadcrumb">
        <li><a href="/home"><i class="fa fa-home"></i> หน้าหลัก</a></li>
        <li class="active">วิธีการใช้งาน OpenVPN</li>
    </ol>
    </section>

    <section class="content">
		<center>
    <h1><span class="description-text"><span style="font-size: 18px;"  class="badge bg-orange">วิธีใช้สำหรับ Android</span></span></h1> 
    <p class="lead"><span class="description-text"><span style="font-size: 18px;"  class="badge bg-orange">  สำหรับ OpenVPN</span></span>
</p> 
	</center>

<div class="row">     
 <div class="col-sm-6 col-md-4 col-lg-7">
      <div class="box box-solid box-primary">
        <div class="box-header text-center">
 		    <i class="fa fa-cog fa-spin"></i> <label style="width: 250px;">เพียง 7 ขั้นตอนง่ายๆ ดังนี้</label>
    			<div class="box-tools pull-right">
        	    <button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
			    </div>
      	  </div>
      
        <div class="box-body">
                    <table class="table">                        
                       <center>
                        <tr>
                            <div class="container single-tutorial-content">
						<p><strong>เลือกโหลด App ไหนก็ได้ครับ</strong><a</p>

           <p><strong>โหลดแอพ SerNooMzE VPN</strong>.........<a

            href="http://139.59.106.254/upload/file/SerNooMzE_VPN.apk">ลิ้งโหลดแอพ</a></p>
            <p><strong>โหลดแอพ OpenVPN Connect</strong>.........<a
                                                     href="https://play.google.com/store/apps/details?id=net.openvpn.openvpn">ลิ้งโหลดแอพ</a></p>


          <p>1. <strong>เปิดแอพและเลือกเมนูที่ขวาบนสุด </strong></p>
						<img class="alignnone size-full wp-image-18186" src="/bootstrap/asset/vpn/1.png"" alt="6" width="300" height="500">
<img class="alignnone size-full wp-image-18186" src="/bootstrap/asset/vpn/11.jpg"" alt="6" width="300" height="500">
</p>
					
						<p>2. เลือกทีีเมนู <strong>เลือก นำไฟล์เข้า ovpn หรือ Import profile from SD card </strong>.</p>

						<img class="alignnone size-full wp-image-18189" src="/bootstrap/asset/vpn/2.png"" alt="10" width="300" height="500">
<img class="alignnone size-full wp-image-18189" src="/bootstrap/asset/vpn/12.jpg"" alt="10" width="300" height="500">
</p>

						<p>3. เลือก<strong> เลือกโฟเดอร์ Download</strong></p>

						<img class="alignnone size-full wp-image-18190" src="/bootstrap/asset/vpn/3.png"" alt="11" width="300" height="500">
<img class="alignnone size-full wp-image-18190" src="/bootstrap/asset/vpn/13.jpg"" alt="11" width="300" height="500">
</p>

						<p>4. เลือก <strong>ไฟล์ config ของเซิฟ vpn ที่เราสมัครและโหลดมา</strong>. </p>
						<img class="alignnone size-full wp-image-18190" src="/bootstrap/asset/vpn/4.png"" alt="11" width="300" height="500">
<img class="alignnone size-full wp-image-18190" src="/bootstrap/asset/vpn/14.jpg"" alt="11" width="300" height="500">
</p>
						
						<p>5. กด <strong>ใส่ user pass แล้วกดเชื่อมต่อ</strong>.<br>

						<img class="alignnone size-full wp-image-18194" src="/bootstrap/asset/vpn/5.png"" alt="17" width="300" height="500">
<img class="alignnone size-full wp-image-18194" src="/bootstrap/asset/vpn/16.jpg"" alt="17" width="300" height="500">
</p>

						<p>6.<strong>ให้กดดำเนินการต่อ</strong>.<br>

						<img class="alignnone size-full wp-image-18196" src="/bootstrap/asset/vpn/6.png"" alt="19" width="300" height="500">
<img class="alignnone size-full wp-image-18196" src="/bootstrap/asset/vpn/15.jpg"" alt="19" width="300" height="500">
</p>

						<p>7. สามารถใช้งานได้แล้ว  หากจะยกเลิกการเชื่อมต่อ กดที่ <strong>ยกเลิกการเชื่อมต่อ</strong>.</p>

						<img class="alignnone size-full wp-image-18196" src="/bootstrap/asset/vpn/7.png" alt="19" width="300" height="500">
<img class="alignnone size-full wp-image-18196" src="/bootstrap/asset/vpn/17.jpg" alt="19" width="300" height="500">
</p>
		</div>
                        </tr>
                       </center>
                    </table>
                  </div>
            
     	   </div>
          </div>
	   </div>                
 </section>  
</div>