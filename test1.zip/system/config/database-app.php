<?php die();
[globals]
DEBUG=0
AUTOLOAD="bootstrap/asset/js-signup"
UI="app/"
APP_KEY="5eb7ae8ba04ebd8ce2a9829b2e41d2c4bd32c1e935c3ee409ce3ec1b93b0a3b9"
DB_SET="mysql:host=localhost;port=3306;dbname=sernoomze"
DB_USER="root"
DB_PASS="xxxx" <<< พาส
?>