<?php
    $connection = mysqli_connect("localhost", "root", "พาส", "ดาด้าเบส");    
    if (!$connection) {
        die("<br/>Database connection failed<br/>");
    }
?>