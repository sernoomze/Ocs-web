<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
  <div class="content-wrapper">
    <section class="content-header">
      <h1>
       วิธีใช้งานเบื้องต้นสำหรับ ANDROID
      </h1>
    <ol class="breadcrumb">
        <li><a href="/home"><i class="fa fa-dashboard"></i> หน้าหลัก</a></li>
        <li class="active">วิธีการใช้งาน OpenVPN</li>
    </ol>
    </section>

    <section class="content">
		<center>
    <h1>วิธีใช้สำหรับ Android</h1> 
    <p class="lead">สำหรับ OpenVPN.</p> 
	</center>

<div class="row">     
 <div class="col-sm-6 col-md-4 col-lg-3">
      <div class="box box-solid box-primary">
        <div class="box-header text-center">
 		    <i class="fa fa-cog fa-spin"></i> <label style="width: 250px;">เพียง 7 ขั้นตอนง่ายๆ ดังนี้</label>
    			<div class="box-tools pull-right">
        	    <button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
			    </div>
      	  </div>
      
        <div class="box-body">
                    <table class="table">                        
                       <center>
                        <tr>
                            <div class="container single-tutorial-content">
						<p>1. ดาวน์โหลดแอพ OpenVPN Connect <a href="https://play.google.com/store/apps/details?id=net.openvpn.openvpn">ลิ้งโหลดแอพ</a>.</p>

						<img class="alignnone size-full wp-image-18186" src="https://s20.postimg.org/dlm625ckt/Screenshot_2017-09-27-06-18-08.png" alt="6" width="300" height="500"></p>
					
						<p>2. เปิดแอพและเลือกเมนูที่ขวาบนสุด <strong>เลือก Import</strong>.</p>

						<img class="alignnone size-full wp-image-18189" src="https://s20.postimg.org/p0in6rox9/Screenshot_2017-09-27-07-48-39.png" alt="10" width="300" height="500"></p>

						<p>3. เลือก<strong> Import profile from SD card</strong> และเลือกไฟล์ config vpn .ovpn ที่คุณ Download มา</p>

						<img class="alignnone size-full wp-image-18190" src="https://s20.postimg.org/caeetogz1/Screenshot_2017-09-27-07-48-27.png" alt="11" width="300" height="500"></p>

						<p>4. ใส่ชื่อและรหัสผ่านของคุณ ที่คุณสมัครมาของ เซิร์ฟเวอร์ นั้นๆ.</p>
						<img class="alignnone size-full wp-image-18190" src="https://s20.postimg.org/fep2qgxrh/Screenshot_2017-09-27-07-32-18.png" alt="11" width="300" height="500"></p>
						
						<p>5. กด <strong>Connect</strong>.<br>

						<img class="alignnone size-full wp-image-18194" src="https://s20.postimg.org/709g2dwq5/Screenshot_2017-09-27-07-39-01.png" alt="17" width="300" height="500"></p>

						<p>6. ติ้กถูก ฉันวางใจแอพพลิเคชั่นนี้ และกด ตกลง.<br>

						<img class="alignnone size-full wp-image-18196" src="https://s20.postimg.org/6dajcuzu5/Screenshot_2017-09-27-07-37-39.png" alt="19" width="300" height="500"></p>

						<p>7. เพียงเท่านี้ก้อสามารถใช้งานได้แล้วครับ หากจะยกเลิกการเชื่อมต่อ กดที่ <strong>Disconnect</strong>.</p>

						<img class="alignnone size-full wp-image-18196" src="https://s20.postimg.org/59qf0wf71/Screenshot_2017-09-27-07-47-26.png" alt="19" width="300" height="500"></p>
		</div>
                        </tr>
                       </center>
                    </table>
                  </div>
            
     	   </div>
          </div>
	   </div>                
 </section>  
</div>