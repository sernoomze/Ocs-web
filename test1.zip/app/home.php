<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<div class="wrapper">
  <header class="main-header">
    <a href="/main" class="logo">
      <span class="logo-mini">SerNooMzE</span>
      <span class="logo-md"><b> SerNooMzE </b>VPN</span>
    </a>
    <nav class="navbar navbar-static-top">
      <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
        <span class="sr-only">Toggle navigation</span> MENU
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </a>
	
      <div class="navbar-custom-menu">
        <ul class="nav navbar-nav">
					<li class="dropdown messages-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <i class="fa fa-btc"></i>
              <span class="label label-danger">N</span>
            </a>
            <ul class="dropdown-menu">
              <li class="header">เลือกระบบการเติมเงิน</li>
              <li>
                <ul class="menu">
                  <li>
                    <a href="#">
                      <div class="pull-left">
                       	<center><form action="/topup/input.php" method="post">
							<input name="user" type="hidden" value="{{ @me->username }}" id="user">			 
			 			        <li class="glyphicon glyphicon-usd"> <button type="submit" class="btn btn-md btn-primary"> TRUEWALLET เลขอ้างอิง </button></li></form>	</center>  
                      </div>
                      <h4>
                        
                        <small><i class="fa fa-clock-o"></i>  </small>
                      </h4>
                      
                    </a>
                  </li>
                  <li>
                    <a href="#">
                      <div class="pull-left">
                       <a href="/home/topups" class="glyphicon glyphicon-usd"></i>  <span class="btn btn-md btn-success"> TRUEMONEY บัตรเงินสด</span></a>
                      </div>
                      <h4>
                                                
                      </h4>                      
                    </a>
                  </li>
                  <!-- end message -->
                </ul>
              </li>
              <li class="footer"><a href="#">TOPUP</a></li>
            </ul>
          </li>
          <li class="dropdown user user-menu">			 
            <a href="#" class="dropdown-toggle" data-toggle="dropdown"> 					 
				     <span class="fa fa-cog" alt="User Image"> 
              <span class="hidden-xs">{{ @me->username }}</span>
            </a>
            <ul class="dropdown-menu">             
              <li class="user-header">
                <img src="/bootstrap/asset/img/users.png" class="img-circle" alt="User Image">
                <p>
                  {{ @me->username }} {{ @me->lastname }}
				 <small></small> <strong>เงินของคุณ : {{ @me->saldo }} บาท</strong>               <small>{{ @me->email }}</small>
                </p>
              </li>
              <li class="user-footer">
                <div class="pull-left">
                  <a href="/home/setting" class="btn btn-default"> เปลี่ยนรหัสผ่าน</a>
                </div>
                <div class="pull-right">
                  <a href="/logout"  class="btn btn-default" > ออกจากระบบ</a>
                </div>
              </li>
            </ul>
          </li>
          <li>
						      
          </li>
        </ul>
      </div>
    </nav>
  </header>
  <aside class="main-sidebar">
    <section class="sidebar">
      <div class="user-panel">
        <div class="pull-left image">
          <img src="/bootstrap/asset/img/users.png" class="img-circle" alt="User Image">
        </div>
        <div class="pull-left info">
          <p>{{ @me->username }}</p>
          <a href="#"><i class="fa fa-circle text-success"></i> {{ @me->type==1?'ADMIN':'MEMBER' }}</a>
        </div>
      </div>
      <ul class="sidebar-menu">
				<li class="header">เมนู</li>
        <li><a href="/main"><i class="fa fa-home"></i> <span>หน้าหลัก</span></a></li>      
             <check if="{{ @me->type==1 }}">
           <true>					
        <li class="treeview">
          <a href="#">
            <i class="fa fa-cloud"></i> <span>รายชื่อเซิร์ฟเวอร์</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="/home/admin/server"><i class="fa fa-cloud-upload"></i> เซิร์ฟเวอร์ ทั้งหมด</a></li>
            <li><a href="/home/admin/server/add"><i class="fa fa-cloud-download"></i> เพิ่มเซิร์ฟเวอร์</a></li>
          </ul>
        </li>
        <li class="treeview">
          <a href="#">
            <i class="fa fa-group"></i> <span>รายชื่อบัญชี</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="/home/admin/seller"><i class="fa fa-user-md"></i> รายชื่อทั้งหมด</a></li>
            <li><a href="/home/admin/seller/add"><i class="fa fa-user-plus"></i> เพิ่มบัญชี</a></li>
          </ul>
        </li>
	<li class="treeview">
          <a href="#">
            <i class="fa fa-cloud-download"></i><span>เช็คสถานะบัญชี</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
									<li><a href="/userstatus" class="fa fa-mixcloud"></i> <span>เช็ควันหมดอายุ&การใช้งาน</span></a></li>
        </ul>
	</li>
	<li class="treeview">
          <a href="#">
            <i class="fa fa-send"></i><span>เช็คบัญชีที่ออนไลน์</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
									<li><a href="/useronline" class="fa fa-send"></i> <span>เช็คบัญชีที่ออนไลน์</span></a></li>
        </ul>
	</li>
		</true>
		<false>		
	<li><a href="/home/member/server/"><i class="fa fa-mixcloud"></i> <span>เช่า VPN</span></a></li>
	<li class="treeview">
          <a href="#">
            <i class="fa fa-cloud-download"></i><span>เช็คสถานะบัญชี</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
									<li><a href="/userstatus" class="fa fa-mixcloud"></i>         <span>เช็ควันหมดอายุ&การใช้งาน</span></a></li>
        </ul>
	</li>
	<li class="treeview">
          <a href="#">
            <i class="fa fa-send"></i><span>เช็คบัญชีที่ออนไลน์</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
									<li><a href="/useronline" class="fa fa-send"></i> <span>เช็คบัญชีที่ออนไลน์</span></a></li>
        </ul>
	</li>
		<li class="treeview">
          <a href="#">
            <i class="fa fa-btc"></i> <span>เติมเงินระบบอัตโนมัติ</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu text-center">
		  	<li><a href="/home/topups" class="glyphicon glyphicon-usd"></i> <span class="btn btn-sm btn-default">TRUEMONEY บัตรเงินสด</span></a></li>
				<center><form action="/topup/input.php" method="post">
							<input name="user" type="hidden" value="{{ @me->username }}" id="user">			 
			 			        <li class="glyphicon glyphicon-usd"> <button type="submit" class="btn btn-sm btn-default"> TRUEWALLET เลขอ้างอิง </button></li></form>	</center>
        </ul>       
	</li>        
        <li class="treeview">
          <a href="#">
            <i class="glyphicon glyphicon-phone"></i> <span>วิธีใช้งานเบื้องต้น</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
          	<li><a href="/home/android"><i class="fa fa-android"></i> วิธีใช้งาน Android.</a></li>
        </ul>       	
        </false>
        </check>		
        <li class="header">เพิ่มเติม</li>
         <li class="treeview">
          <a href="#">
            <i class="fa fa-facebook"></i>
				       <span>FACEBOOK</span>
                 <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">        
        <li><a href="https://www.facebook.com/groups/"><i class="fa fa-facebook-official"></i> <span>กลุ่มFacebook</span></a></li>       
        <li><a href="https://m.me/"><i class="fa fa-facebook-official"></i> <span>ติดต่อผู้ดูแล</span></a></li> 
          </ul>                   
        <li><a href="/home/setting"><i class="glyphicon glyphicon-wrench"></i> <span>เปลี่ยนรหัสผ่าน</span></a></li>
        <li><a href="/logout" ><i class="fa fa-sign-out" ></i><span>ออกจากระบบ</span></a></li>
      </ul>
    </section>
  </aside>

  <include href="{{ @subcontent }}"/> 

<footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>BY SerNooMzE VPN</b>
    </div>
    <strong>Copyright © 2018 <a href="/">SerNooMzE VPN</a>.</strong>
  </footer>

  <div class="control-sidebar-bg"></div>  
</div>