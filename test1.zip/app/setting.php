<?php if (!defined('BASEPATH')) exit('No direct script access allowed'); ?>
 <div class="content-wrapper">
    <section class="content-header">
      <h1>
        โปรไฟล์
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-home"></i> หน้าหลัก</a></li>
        <li class="active">Profile</li>
      </ol>
    </section>

	<section class="content">
 		<div class="row">
	      <div class="col-md-4 col-sm-6 col-xs-6">
          <div class="small-box bg-maroon text-center">
            <span class="small-box-icon"><i class="fa fa-btc"></i></span>
            <div class="small-box-content">
              <span class="small-box-text">ยอดเงินคงเหลือ </span>
              <span class="small-box-number text-center"><h2>{{ @me->saldo }} บาท</h2></span>             
            </div>
            <a href="/home/topups" class="small-box-footer bg-dark">เติมเงิน <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>

		 <div class="col-md-4 col-sm-6 col-xs-6">
		 <div class="small-box bg-teal text-center">
            <span class="small-box-icon"><i class="fa fa-user"></i></span>
            <div class="small-box-content">
              <span class="small-box-text">ชื่อบัญชี {{ @me->type==1?'ADMIN':'Member' }}</span>
              <span class="small-box-number text-center"><h2>{{ @me->username }}</h2></span>        
            </div>
             <a href="/setting" class="small-box-footer bg-dark">เพิ่มเติม <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>          
    </div> 

<div class="row">       
	 <div class="col-md-8">
	        <check if="{{ @message }}">     
				<div class="alert alert-success alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <h4><i class="icon fa fa-warning"></i>Alert!</h4>
                {{ @message['data'] }}
              </div>
            </check>

        <div class="box box-danger">
            <div class="box-header with-border">
               <i class="fa fa-cog fa-spin"></i><h3 class="box-title">เปลี่ยนรหัสผ่าน</h3>
            </div>
              <form role="form" action="{{ @URI }}" method="POST">
           			   <div class="box-body">
                        <div class="form-group">
                            <label>รหัสผ่านเก่า</label>
                            <input class="form-control" placeholder="Old Password" name="oldpass" type="password" required>
                        </div>
                        <div class="form-group">
                            <label>รหัสผ่านใหม่</label>
                            <input class="form-control" placeholder="รหัสผ่านที่ต้องการ" name="password" type="password" required>
                        </div>
                        <div class="form-group">
                            <label>รหัสผ่านใหม่ อีกครั้ง</label>
                            <input class="form-control" placeholder="ยืนยันรหัสผ่านอีกครั้ง" name="password_confirmation" type="password" required>
                        </div>
                     </div>&nbsp;&nbsp;           
			 			<button type="button" class="btn btn-danger form-control" data-toggle="modal" data-target="#modal-danger">
              เปลี่ยนรหัสผ่าน
              </button>				 
				 <div class="modal modal-danger fade" id="modal-danger">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">แจ้งเตือนการเปลี่ยนรหัสผ่าน</h4>
              </div>
              <div class="modal-body">
                <p>กรุณาเช็ครหัสก่อนที่จะกดยืนยัน</p>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-outline pull-left" data-dismiss="modal">ยกเลิก</button>
                <button type="submit" class="btn btn-outline">ยืนยัน</button>
              </div>
            </div>
          </div>
        </div>
				</form>     
      </div>
		</div>

    </div>
    </section>          
</div>