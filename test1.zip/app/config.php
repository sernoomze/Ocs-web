<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
       Config VPN
      </h1>
    <ol class="breadcrumb">
        <li><a href="/home"><i class="fa fa-dashboard"></i> หน้าหลัก</a></li>
        <li class="active">config</li>
    </ol>
    </section>

			<div class="row">
                    <div class="col-md-12 text-center">
                        <label class="label label-danger">การถ่ายโอนข้อมูลอย่างรวดเร็ว</label>
                        <label class="label label-danger">เซิร์ฟเวอร์ความเร็วสูง</label>
                        <label class="label label-warning">เซิฟเวอร์มาตรฐาน</label>
                        <label class="label label-warning">ไม่ลดสปีด</label>
                        <label class="label label-warning">ไม่จำกัดbandwidth</label>
                        <label class="label label-primary">ความเป็นส่วนตัวทางอินเทอร์เน็ตการ</label>
                        <label class="label label-primary">รักษาความปลอดภัยเฉพาะ</label>
                        <label class="label label-success">โซลูชั่นรักษาความปลอดภัย</label>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12 text-center">
                        <label class="label label-info">ไม่มี DDOS</label>
                        <label class="label label-info">ไม่มี Hacking</label>
                        <label class="label label-info">ไม่มี Carding</label>
                        <label class="label label-info">ไม่มี Spam</label>
                        <label class="label label-danger">ไม่มี Torrent</label>
                        <label class="label label-danger">ไม่มีการฉ้อโกง </label>
                        <label class="label label-danger">ไม่มี Repost</label>
                    </div>
                </div>
			    <p></p>
		<center>
    <h1>Config VPN</h1> 
    <p class="lead">สำหรับ OpenVPN</p> 
	</center>

    <!-- Main content -->
    <section class="content">
    <div class="row">        
	        <check if="{{ @message }}">     
				<div class="alert alert-{{ @message['type'] }} alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
               <i class="icon fa fa-info"></i>
                {{ @message['data'] }}
              </div>
            </check>
     
 <div class="col-sm-6 col-md-4 col-lg-3">
      <div class="box box-solid box-primary">
        <div class="box-header text-center">
     <i class="fa fa-cog fa-spin"></i> <label style="width: 250px;">Config VPN สำหรับ (OpenVPN)</label>
    <div class="box-tools pull-right">
            <button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
    </div><!-- /.box-tools -->
        </div><!-- /.box-header -->
        <div class="box-body">
                    <table class="table">                        
                       <center>
                        <tr>
                            <td><b> Digital SG 1</b></td><td><b><a href="/web/vpn/SG-1.LOWCLASS.ovpn" class="btn btn-danger"><i class="fa fa-cloud-download"></i> VPN SG-1</a><b></td>
                        </tr>
                        <tr>
                            <td><b> ชื่อไฟล์บนเว็บ</b></td><td><b><a href="/web/vpn/SG-2.2.LOWCLASS.ovpn" class="btn btn-info"><i class="fa fa-cloud-download"></i> ชื่อไฟล์ที่โหลลด</a><b></td>
                        </tr>
                            <td><b> ชื่อไฟล์บนเว็บ</b></td><td><b><a href="/web/vpn/SG-3.LOWCLASS.ovpn" class="btn btn-warning"><i class="fa fa-cloud-download"></i> ชื่อไฟล์ที่โหลด</a><b></td>
##กรุณาดาวน์โหลด "Configหรือไฟล์OpenVPN" ให้ตรงตามเซิฟเวอร์ที่ท่านสั่งซื้อ##
                        </tr>
                       </center>
                    </table>
                  </div><!-- /.box-body -->
            	
     			   </div><!-- /.box -->
						      </center>
               </table>
	       		</div>
	       
        	</div>
       </div>

	</div>                
 </section>  
</div>

  <!-- /.content-wrapper -->