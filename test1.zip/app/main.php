<?php if (!defined('BASEPATH')) exit('No direct script access allowed'); ?>
 <div class="content-wrapper">
    <section class="content-header">
      <h1>
        กิจกรรม และ โปรไฟล์
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Profile</li>
      </ol>
    </section>

    				<section class="content">
                    <div class="row">        
                        <div class="col-md-6">
                            <div class="nav-tabs-custom">
                                <ul class="nav nav-tabs pull-left">
                                    <li class="active"><a href="#tab_1-1" data-toggle="tab">กิจกรรม</a></li>
                                    <li><a href="#tab_2-2" data-toggle="tab">ประกาศ</a></li>
                                    <li><a href="#tab_3-3" data-toggle="tab">วิธีเติมเงิน</a></li>            
																		<li><span><iframe src="http://free.timeanddate.com/clock/i5yocovd/n28/tlth39/fn6/fs16/ftb/th1" frameborder="0" width="70" height="35"></iframe></span></li>
                      
                                    <li class="pull-left header"><i class="fa fa-th"></i> กิจกรรมและประกาศต่างๆ</li>
												
                                </ul>
                          <div class="tab-content">
                             <div class="tab-pane active" id="tab_1-1">
                             <h3><b>  </b></h3>	
                     <br><br><p><B> SerNooMzE VPN </B></p>
             														
									 	 <h5>#หมายเหตุ: มีปัญหาด้านการใช้งานหรือด้านอื่นๆ  <b><a href="https://m.me/"> กดตรงนี้</a></b></h5>
                            </div>                               
					 <div class="tab-pane" id="tab_2-2">
              <h3><b>ประกาศ:</b></h3>								
					    	  <h3><b> </b></h3>
								 <h4> <b><a href="https://m.me/"> กดตรงนี้</a></b></h4>								
                                    </div>

					 <div class="tab-pane" id="tab_3-3">
							 <h3><b>วิธีเติมเงินระบบอัติโนมัติ:</b></h3>							 
                                   
																 </div>
                                </div>
                            </div>
                        </div>
                    </div>
                     
 		<div class="row">
	      <div class="col-md-6 col-md-6 col-xs-12">
         <div class="info-box bg-green">
            <span class="info-box-icon"><i class="fa fa-money"></i></span>
            <div class="info-box-content">
              <span class="info-box-text">ยอดเงินคงเหลือ</span>
              <span class="info-box-number">{{ @me->saldo }} บาท</span>
              <div class="progress">
                <div class="progress-bar" style="width: 70%"></div>
                 </div>
                  <span class="progress-description">
										<a href="/home/topups">เติมเงิน <i class="fa fa-arrow-circle-right"></i></a>
                  </span>
            </div>
          </div>
        </div>

		 <div class="col-md-6 col-md-6 col-xs-12">
          <div class="info-box bg-yellow">
            <span class="info-box-icon"><i class="fa fa-user"></i></span>
            <div class="info-box-content">
              <span class="info-box-text">ชื่อบัญชี</span>
              <span class="info-box-number">{{ @me->username }}</span>
              <div class="progress">
                <div class="progress-bar" style="width: 40%"></div>
                 </div>
                  <span class="progress-description">
                     <a href="/home/setting">เพิ่มเติม <i class="fa fa-arrow-circle-right"></i></a>
                  </span>
            </div>
          </div>
        </div> 						

    </section>
  </div>           