<?php

$f3 = require('system/lib/base.php');
$f3->config('system/config/database-app.php');
$f3->config('system/config/route.php');
$f3->run();