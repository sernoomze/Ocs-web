﻿<?php
SESSION_START();
include 'config.php';

$walletmoney = $_POST['wallet'];

//Show all error, remove it once you finished you code.
ini_set('display_errors', 1);
//Include TrueWallet class.
include_once('manager/TrueWallet.php');
$wallet = new TrueWallet();
//Login with your username and password.

$username = "xxxx"; //ใส่เมล์ wallet
$password = "xxxx"; //ใส่รหัส wallet
//Logout incase your previous session still exist, no need if you only use 1 user.
$wallet->logout();

//Login into TrueWallet
if($wallet->login($username,$password)){

	$profile = $wallet->get_profile();

	$transaction = $wallet->get_transactions();
	//เช็ค ย้อนหลัง 10 อัน

	for($i = 0;$i < 20;$i++){

			$report = $wallet->get_report($transaction[$i]->reportID);

			$checkid = $report->section4->column2->cell1->value; //เลขที่อ้างอิง

			$money = $report->section3->column1->cell1->value; //จำนวนเงิน


			//เช็คเลขที่อ้างอินกับจำนวนเงินที่โอนมา ถ้าไม่ตรงเงือนไข จะแสดง    รายการผิดพลาดลองใหม่อีกครั้ง
			if($walletmoney == $checkid && $money == 10){
				$sql = "SELECT * FROM user WHERE username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				// ถ้า status กับเลขที่อ้างอิง ไม่มี
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into user (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update user set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 2){
				$sql = "SELECT * FROM user WHERE username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into user (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update user set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 3){
				$sql = "SELECT * FROM user WHERE username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into user (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update user set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 4){
				$sql = "SELECT * FROM user WHERE username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into user (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update user set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 5){
				$sql = "SELECT * FROM user WHERE username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into user (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update user set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 6){
				$sql = "SELECT * FROM user WHERE username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into user (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update user set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 7){
				$sql = "SELECT * FROM user WHERE username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into user (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update user set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 8){
				$sql = "SELECT * FROM user WHERE username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into user (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update user set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 9){
				$sql = "SELECT * FROM user WHERE username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into user (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update user set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 1){
				$sql = "SELECT * FROM user WHERE username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into user (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update user set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 11){
				$sql = "SELECT * FROM user WHERE username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into user (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update user set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 12){
				$sql = "SELECT * FROM user WHERE username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into user (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update user set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 13){
				$sql = "SELECT * FROM user WHERE username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into user (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update user set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 14){
				$sql = "SELECT * FROM user WHERE username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into user (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update user set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 15){
				$sql = "SELECT * FROM user WHERE username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into user (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update user set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 16){
				$sql = "SELECT * FROM user WHERE username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into user (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update user set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 17){
				$sql = "SELECT * FROM user WHERE username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into user (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update user set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 18){
				$sql = "SELECT * FROM user WHERE username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into user (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update user set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
			}else if($walletmoney == $checkid && $money == 19){
				$sql = "SELECT * FROM user WHERE username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into user (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update user set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
			}else if($walletmoney == $checkid && $money == 20){
				$sql = "SELECT * FROM user WHERE username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into user (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update user set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 21){
				$sql = "SELECT * FROM user WHERE username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into user (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update user set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 22){
				$sql = "SELECT * FROM user WHERE username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into user (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update user set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 23){
				$sql = "SELECT * FROM user WHERE username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into user (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update user set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 24){
				$sql = "SELECT * FROM user WHERE username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into user (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update user set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 25){
				$sql = "SELECT * FROM user WHERE username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into user (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update user set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 26){
				$sql = "SELECT * FROM user WHERE username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into user (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update user set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 27){
				$sql = "SELECT * FROM user WHERE username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into user (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update user set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 28){
				$sql = "SELECT * FROM user WHERE username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into user (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update user set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
			}else if($walletmoney == $checkid && $money == 29){
				$sql = "SELECT * FROM user WHERE username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into user (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update user set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 30){
				$sql = "SELECT * FROM user WHERE username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into user (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update user set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 31){
				$sql = "SELECT * FROM user WHERE username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into user (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update user set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 32){
				$sql = "SELECT * FROM user WHERE username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into user (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update user set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 33){
				$sql = "SELECT * FROM user WHERE username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into user (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update user set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 34){
				$sql = "SELECT * FROM user WHERE username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into user (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update user set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 35){
				$sql = "SELECT * FROM user WHERE username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into user (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update user set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 36){
				$sql = "SELECT * FROM user WHERE username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into user (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update user set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 37){
				$sql = "SELECT * FROM user WHERE username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into user (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update user set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 38){
				$sql = "SELECT * FROM user WHERE username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into user (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update user set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
			}else if($walletmoney == $checkid && $money == 39){
				$sql = "SELECT * FROM user WHERE username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into user (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update user set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 40){
				$sql = "SELECT * FROM user WHERE username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into user (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update user set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 41){
				$sql = "SELECT * FROM user WHERE username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into user (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update user set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 42){
				$sql = "SELECT * FROM user WHERE username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into user (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update user set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 43){
				$sql = "SELECT * FROM user WHERE username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into user (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update user set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 44){
				$sql = "SELECT * FROM user WHERE username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into user (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update user set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 45){
				$sql = "SELECT * FROM user WHERE username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into user (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update user set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 46){
				$sql = "SELECT * FROM user WHERE username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into user (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update user set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 47){
				$sql = "SELECT * FROM user WHERE username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into user (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update user set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 48){
				$sql = "SELECT * FROM user WHERE username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into user (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update user set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
			}else if($walletmoney == $checkid && $money == 49){
				$sql = "SELECT * FROM user WHERE username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into user (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update user set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 50){
				$sql = "SELECT * FROM user WHERE username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into user (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update user set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 51){
				$sql = "SELECT * FROM user WHERE username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into user (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update user set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 52){
				$sql = "SELECT * FROM user WHERE username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into user (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update user set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 53){
				$sql = "SELECT * FROM user WHERE username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into user (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update user set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 54){
				$sql = "SELECT * FROM user WHERE username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into user (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update user set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 55){
				$sql = "SELECT * FROM user WHERE username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into user (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update user set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 56){
				$sql = "SELECT * FROM user WHERE username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into user (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update user set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 57){
				$sql = "SELECT * FROM user WHERE username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into user (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update user set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 58){
				$sql = "SELECT * FROM user WHERE username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into user (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update user set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
			}else if($walletmoney == $checkid && $money == 59){
				$sql = "SELECT * FROM user WHERE username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into user (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update user set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 60){
				$sql = "SELECT * FROM user WHERE username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into user (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update user set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
			}else if($walletmoney == $checkid && $money == 65){
				$sql = "SELECT * FROM user WHERE username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into user (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update user set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 70){
				$sql = "SELECT * FROM user WHERE username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into user (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update user set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
			}else if($walletmoney == $checkid && $money == 75){
				$sql = "SELECT * FROM user WHERE username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into user (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update user set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 80){
				$sql = "SELECT * FROM user WHERE username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into user (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update user set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
			}else if($walletmoney == $checkid && $money == 85){
				$sql = "SELECT * FROM user WHERE username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into user (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update user set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 90){
				$sql = "SELECT * FROM user WHERE username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into user (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update user set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
			}else if($walletmoney == $checkid && $money == 95){
				$sql = "SELECT * FROM user WHERE username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into user (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update user set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 100){
				$sql = "SELECT * FROM user WHERE username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into user (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update user set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
			}else if($walletmoney == $checkid && $money == 105){
				$sql = "SELECT * FROM user WHERE username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into user (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update user set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 110){
				$sql = "SELECT * FROM user WHERE username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into user (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update user set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
			}else if($walletmoney == $checkid && $money == 115){
				$sql = "SELECT * FROM user WHERE username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into user (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update user set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 120){
				$sql = "SELECT * FROM user WHERE username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into user (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update user set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 125){
				$sql = "SELECT * FROM user WHERE username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into user (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update user set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 130){
				$sql = "SELECT * FROM user WHERE username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into user (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update user set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 135){
				$sql = "SELECT * FROM user WHERE username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into user (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update user set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 140){
				$sql = "SELECT * FROM user WHERE username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into user (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update user set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 145){
				$sql = "SELECT * FROM user WHERE username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into user (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update user set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 150){
				$sql = "SELECT * FROM user WHERE username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into user (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update user set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 155){
				$sql = "SELECT * FROM user WHERE username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into user (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update user set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 160){
				$sql = "SELECT * FROM user WHERE username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into user (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update user set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 165){
				$sql = "SELECT * FROM user WHERE username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into user (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update user set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 170){
				$sql = "SELECT * FROM user WHERE username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into user (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update user set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 175){
				$sql = "SELECT * FROM user WHERE username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into user (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update user set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 180){
				$sql = "SELECT * FROM user WHERE username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into user (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update user set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 185){
				$sql = "SELECT * FROM user WHERE username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into user (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update user set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 190){
				$sql = "SELECT * FROM user WHERE username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into user (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update user set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 195){
				$sql = "SELECT * FROM user WHERE username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into user (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update user set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 200){
				$sql = "SELECT * FROM user WHERE username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into user (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update user set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 250){
				$sql = "SELECT * FROM user WHERE username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
					echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into user (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update user set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
				}else if($walletmoney == $checkid && $money == 300){
				$sql = "SELECT * FROM user WHERE username='".$_SESSION['user']['username']."'";
				$sqle = "SELECT * FROM histrory WHERE NumberWallet='$walletmoney'";
				$query = mysqli_query($con,$sqle);
				$result = mysqli_fetch_assoc($query);
				if($result['status'] == ''){
				echo "<center><B style='font-size: 60px;'><h1 style='color:green'>เติมเงินเรียบร้อย</h1>
					<h1>จำนวนเงิน ที่คุณเติมคือ $money บาท</h1>
					<h1>ขอบคุณที่ใช้บริการครับ !</h1></B>  
					<p><a href='/main'>[ไปเช่าเน็ตกันเถอะ]</a> </p></center>";
					$sql = "insert into histrory (NumberWallet,money,username,status) values ('$walletmoney','$money','".$_SESSION['user']['username']."',1)";
					mysqli_query($con,$sql);
					$sql1 = "insert into user (saldo) values ('$money') where username='".$_SESSION['user']['username']."'";
					$sql1 = "update user set saldo=saldo+'".$money."'where username='".$_SESSION['user']['username']."'";
					mysqli_query($con,$sql1) or die; ('Error Query');
				}else{
					echo "<center><B style='color:red'><h1 style='font-size: 80px;'>เกิดข้อผิดพลาด</h1>
		<h1 style='font-size: 80px;'>หมายเลขอ้างอิงนี้</h1>
		<h1 style='font-size: 80px;'>ถูกใช้งานแล้ว</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				}
				break;
			}else{
					echo "<center><B style='font-size: 60px;'><h1 style='color:red'>เกิดข้อผิดพลาด</h1>
		<h1>เลขอ้างอิงไม่ครบหรือไม่ถูกต้อง</h1></B>
		<p><a href='/topup/get.php'>[กลับไปลองอีกครั้ง]</a> </p></center>";
				
				break;
			}
	}

	//Logout
	$wallet->logout();
}else{
	echo 'ยังไม่มีการเชื่อมต่อบัญชี!';
}
?>
