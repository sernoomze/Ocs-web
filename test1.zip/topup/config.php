<?php
$host = 'localhost';
$user = 'root';
$pass = 'xxxx'; //ใส่รหัสครับ database
$db = 'xxx'; //ใส่ชื่อ database
$con = mysqli_connect($host,$user,$pass,$db);
mysqli_set_charset($con);