<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>SerNooMzE VPN</title>
  <link rel="shortcut icon" href="/asset/img/icons/favicon.ico" type="image/x-icon" />
<link rel="apple-touch-icon" href="/asset/img/icons/apple-touch-icon.png" />
<link rel="apple-touch-icon" sizes="57x57" href="/asset/img/icons/apple-touch-icon-57x57.png" />
<link rel="apple-touch-icon" sizes="72x72" href="/asset/img/icons/apple-touch-icon-72x72.png" />
<link rel="apple-touch-icon" sizes="76x76" href="/asset/img/icons/apple-touch-icon-76x76.png" />
<link rel="apple-touch-icon" sizes="114x114" href="/asset/img/icons/apple-touch-icon-114x114.png" />
<link rel="apple-touch-icon" sizes="120x120" href="/asset/img/icons/apple-touch-icon-120x120.png" />
<link rel="apple-touch-icon" sizes="144x144" href="/asset/img/icons/apple-touch-icon-144x144.png" />
<link rel="apple-touch-icon" sizes="152x152" href="/asset/img/icons/apple-touch-icon-152x152.png" />
<link rel="apple-touch-icon" sizes="180x180" href="/asset/img/icons/apple-touch-icon-180x180.png" />
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">

  <link rel="stylesheet" href="/asset/css/bootstrap.min.css">
  <link href="/asset/css/bootstrap-dialog.min.css" rel="stylesheet">

  <!-- Bootstrap core CSS     -->
    <link href="/topup/assets/css/bootstrap.min.css" rel="stylesheet" />
    <!--  Material Dashboard CSS    -->
    <link href="/topup/assets/css/material-dashboard.css" rel="stylesheet" />
    <!--  CSS for Demo Purpose, don't include it in your project     -->
    <link href="/topup/assets/css/demo.css" rel="stylesheet" />
    <!-- Custom Fonts -->
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
  	<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  
	  <link href='https://fonts.googleapis.com/css?family=Kanit|Mitr|Pridi:400,300&subset=thai,latin' rel='stylesheet' type='text/css'>
    <style>
		body {
		  font-family: 'Kanit', sans-serif;
		  font-family: 'Pridi', serif;
		  font-family: 'Mitr', sans-serif;
		}
		h1 {
		  font-family: 'Kanit', sans-serif;
		  font-family: 'Pridi', serif;
		  font-family: 'Mitr', sans-serif;
		}
    </style>
</head>
<body class="hold-transition register-page">
<br><br>
<div class="register-box">           
	<section class="content">
          <div class="main-panel">                                   
             <div class="content">
                 <div class="container-fluid">
                     <div class="row">  
                   	
                    	 <div class="col-md-4">
                            <div class="card card-profile">
                                <div class="card-avatar">
                                    <a href="#">
                                        <img class="img" src="/topup/assets/img/logo.png" />
                                    </a>
                                </div>
                                <div class="content">
                                    <h6 class="category text-gray">WELCOME to SerNooMzE VPN</h6>
                                    <h4 class="card-title">TRUE WALLET</h4>
                                    <p class="card-content">
                                        ระบุ ชื่อบัญชี (username) ของท่านก่อน
                                    </p>
                                    <button class="btn btn-primary btn-round">USERNAME</button>
                                    <form action="input.php" method="post">

<div class="col-sm-4">
		<div class="input-group text-center">
		<span class="input-group-addon">
			<i class="material-icons">group</i>
		</span>
		<input type="text" placeholder="Username" class="form-control" name="user">
	</div>    
	</div>    
    
  <div class="col-sm-4">
	<div class="form-group text-center">
		<button class="btn btn-danger btn-round">Let'go!</button> 
	</div>
</div>
     
      </div>
    </form>

		<div><a href="http://tmwallet.thaighost.net/images/transactionid.jpg" target="_transactionid">ตัวอย่างการดู เลขที่อ้างอิง</a></div></font>
<p>สามารถโอนเท่าไหร่ก็ได้ ตามสะดวก ไม่มีขั้นต่ำ</p>
<p>เบอร์สำหรับโอน<br><B>0909160090</B></p>

                                </div>
                            </div>
                        </div>
                    </div>
                 </div>
             </div>
        </section>
    </div>
 <script src="/topup/assets/js/sweetalert2.min.js"></script>                  
</body>
</html>