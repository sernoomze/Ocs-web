<?php
SESSION_START();
include 'config.php';
if(!$_SESSION['user']['username']){
header("location: login.php");
}

$sql = "SELECT * FROM user WHERE username='".$_SESSION['user']['username']."'";
$query = mysqli_query($con,$sql) or die ("Error Query");
$result = mysqli_fetch_assoc($query);

?>
<?php include "includes/header.php"; ?>
  <div class="content-wrapper">
    <section class="content-header">
      <h1>
       TOPUP TRUEWALLET
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-home"></i> Home</a></li>
        <li class="active">TRUEWALLET</li>
      </ol>
    </section>

    <section class="content">
      <div class="row">               
      <div class="col-sm-6 col-md-4 col-lg-3">
          <div class="box box-widget widget-user">
         	<div class="widget-user-header bg-black" style="background: url('/bootstrap/asset/img/photo1.jpg') center center;">
              <h3 class="widget-user-username"> <B> USERNAME </B><span class="pull-right"><B> ยอดเงินคงเหลือ </span></h3>
              <h4 class="widget-user-desc"><span style="font-size: 16px;" class="badge bg-purple"><B> <?php echo $result['username'];?> </B></span><span style="font-size: 16px;" class="pull-right badge bg-blue"><B> <?php echo $result['saldo'];?> บาท </B></span></h4>
            </div>
            <div class="widget-user-image">
              <img class="img-circle" src="/bootstrap/asset/img/user3-128x128.png" alt="User Avatar">
            </div>
 
				 <div class="box-footer no-padding">
      	<div class="description-block"><br><br>
            <span class="description-text"><span style="font-size: 16px;"  class="badge bg-red">เบอร์สำหรับเติมเงิน</span></span>
         </div>
         
              <ul class="nav nav-stacked">
                <li><a href="#"><B> ชื่อ WALLET </B><span class="pull-right"><B> เบอร์ WALLET </B></span></a></li>
                <li><a href="#"><span style="font-size: 16px;" class="badge bg-aqua"> ประพนธ์ แก้วจันทร์ </span> <span style="font-size: 16px;" class="pull-right badge bg-purple"> 0909160090 </span></a></li>                                        
              </ul>
            </div>

	<div class="box-footer">
           <center><span class="description-text"><span style="font-size: 16px;"  class="badge bg-red">กรอกหมายเลขอ้างอิง</span></span></center>
         <br>
    		<form action="confirm.php" method="post">
							<div class="form-group">
										<input class="form-control" placeholder="เลขอ้างอิง" name="wallet" type="number">								
										
								</div>    
							</div> 																																			            
                  <div class="form-group text-center">
									<input class="btn btn-info btn-round" type="submit" value="ยืนยันเลขอ้างอิง" name="wallet" onClick="this.disabled=1;this.value='รอสักครู่กำลังตรวจสอบเลขอ้างอิง...';document.forms[0].submit();loading()" style="height:30px;font-size16px">	                 
                        <a href="/main" class="btn btn-warning"><i class="fa fa-home"></i> ย้อนกลับ</a>
								</div>
    						</form>
<center><a href="http://tmwallet.thaighost.net/images/transactionid.jpg" target="_transactionid">ตัวอย่างการดู เลขที่อ้างอิง</a></div></font> </center>
 						</div>
					 </div>        
 				</div> 
			</div>
 </div>                  
            
            </div>
          </div>
        </div>
      </div>
    </section>
  
<footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>BY SerNooMzE VPN</b>
    </div>
    <strong>Copyright © 2018 <a href="/">SerNooMzE VPN</a>.</strong>
  </footer>

  <div class="control-sidebar-bg"></div>  
</div>