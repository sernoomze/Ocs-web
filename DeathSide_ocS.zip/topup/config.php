<?php
$host = 'localhost';
$user = 'root';
$pass = '####'; //ใส่รหัสครับ database
$db = '####'; //ใส่ชื่อ database
$con = mysqli_connect($host,$user,$pass,$db);
mysqli_set_charset($con);