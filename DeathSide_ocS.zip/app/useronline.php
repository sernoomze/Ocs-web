<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
  <div class="content-wrapper">
    <section class="content-header">
      <h1>
      <span class="description-text"><span style="font-size: 25px;"  class="badge bg-orange">เช็คบัญชีที่กำลังใช้งาน</span></span>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-home"></i> Home</a></li>
        <li class="active">useronline</li>
      </ol>
    </section>

    <section class="content">             
      <div class="row">
        <div class="col-md-10">        

          <div class="box box-solid">
            <div class="box-header with-border">
              <h3 class="box-title text-center"> <B>เช็คบัญชี ONLINE</B></h3>
              <div class="box-tools">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                </button>
              </div>
            </div>
            <div class="box-body no-padding">
              <ul class="nav nav-pills nav-stacked">
                <li><a href="/useronlines/Bangmod.php"><i class="fa fa-mixcloud"></i> <B> Death Side VPN </B>
                  <span class="badge bg-primary pull-right"> เช็คบัญชี online </span></a></li>
                
              </ul>
            </div>
            </div>
          </div>
                        
      </div>
      </section>       
</div>v>