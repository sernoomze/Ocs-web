<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
  <div class="content-wrapper">
    <section class="content-header">
<h1>
        <span class="description-text"><span style="font-size: 25px;"  class="badge bg-orange">All Config</span></span>
</h1>
<ol class="breadcrumb">
<li><a href="#"><i class="fa fa-home"></i> Home</a></li>
<li class="active">config</li>
</ol>
</section>
<section class="content">
<div class="row">
<div class="col-md-6">
<div class="box box-solid box-primary">
<div class="box-header text-center">
<i class="fa fa-cog fa-spin"></i> <label style="width: 250px;">Config VPN สำหรับ (OpenVPN)</label>
<div class="box-tools pull-right">
<button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
</div>
</div>
<div class="box-body">
<table class="table">
<center>
<tr>
<td><span class="label label-success">Server Thailand</span></td><td><span class="label label-warning"> OPENVPN</span></td>
</tr>
<tr>
<td><b> Ser_TH </b></td><td><b><a href="/upload/vpn/Ser_TH.ovpn" class="btn btn-success"><i class="fa fa-cloud-download"></i> Ser_TH</a><b></td>
</tr>
<tr>
<td><span class="label label-success">Server Singapore</span></td><td><span class="label label-warning"> OPENVPN</span></td>
</tr>
<tr>
<td><b> Ser_SG </b></td><td><b><a href="/upload/vpn/Ser_SG.ovpn" class="btn btn-danger"><i class="fa fa-cloud-download"></i> Ser_SG</a><b></td>
</tr>
<tr>
</tr>
</center>
</table>
</div>
</div>
</div>
</div>
</section>
</div>