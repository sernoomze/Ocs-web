<?php
    $connection = mysqli_connect("localhost", "root", "ninjanum", "sernoomze");    
    if (!$connection) {
        die("<br/>Database connection failed<br/>");
    }
?>