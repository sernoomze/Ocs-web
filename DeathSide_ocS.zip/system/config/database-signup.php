<?php
    $connection = mysqli_connect("localhost", "root", "pass sqli", "ชื่อฐานข้อมูล");    
    if (!$connection) {
        die("<br/>Database connection failed<br/>");
    }
?>