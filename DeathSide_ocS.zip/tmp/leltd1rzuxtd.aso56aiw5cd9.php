
  <div class="content-wrapper">
    <section class="content-header">
      <h1>
	<span class="description-text"><span style="font-size: 25px;"  class="badge bg-orange">    ชำระเงินเรียบร้อย   </span></span>
     </h1>
      <ol class="breadcrumb">
        <li><a href="/main"><i class="fa fa-home"></i> หน้าหลัก</a></li>
        <li><a href="/home/member/server">SUCCESS</a></li>
        <li class="active">ชำระเงินเรียบร้อย</li>
      </ol>
    </section>

    <section class="content">
     <div class="row">  
     	<div class="col-sm-6 col-md-4 col-lg-3">
	        <?php if ($message): ?>     
				<div class="alert alert-<?php echo $message['type']; ?> alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
               <i class="icon fa fa-info"></i>
                <?php echo $message['data']; ?>
              </div>
            <?php endif; ?>
            </div>
            
		    <div class="col-sm-6 col-md-4 col-lg-3">
                <div class="box box-widget widget-user">
                	<div class="widget-user-header bg-red">
            		  <h3 class="widget-user-username"><B> <?php echo $server->servername; ?> <span style="font-size: 16px;" class="pull-right badge bg-green"> <?php echo $server->Status; ?> </span><B></h3>
        		      <h4 class="widget-user-desc"><B>สมัครบัญชีและชำระเงิน เรียบร้อย <B></h4>
            </div>
            <div class="widget-user-image">
              <img class="img-circle" src="/bootstrap/asset/img/user3-128x128.png" alt="User Avatar">
            </div>
                          
   	  <div class="box-footer no-padding">
      	<div class="description-block"><br><br>
            <span class="description-text"><span style="font-size: 16px;"  class="badge bg-red">รายละเอียด</span></span>
         </div>
         
              <ul class="nav nav-stacked">
          	  <li><a href="#"><B> USERNAME </B><span class="pull-right"><B> PASSWORD </B></span></a></li>
                <li><a href="#"><span style="font-size: 16px;" class="badge bg-aqua"> <?php echo $user->user; ?> </span> <span style="font-size: 16px;" class="pull-right badge bg-purple"> <?php echo $user->pass; ?> </span></a></li>
                
                <li><a href="#"><B> IP ADDRS </B><span class="pull-right"><B> HOSTNAME </B></span></a></li>
                <li><a href="#"><span style="font-size: 16px;" class="badge bg-maroon"> <?php echo $server->host; ?> </span><span style="font-size: 16px;" class="pull-right badge bg-navy"> <?php echo $server->ip; ?> </span></a></li>
                
                <li><a href="#"><B> VPN PORT </B><span class="pull-right"><B> SQUID PROXY </B></span></a></li>
                <li><a href="#"><span style="font-size: 16px;" class="badge bg-purple"> <?php echo $server->dropbear; ?> </span><span style="font-size: 16px;" class="pull-right badge bg-blue"> <?php echo $server->info; ?> </span></a></li>
                
                <li><a href="#"><B> วันหมดอายุ </B><span class="pull-right"><B> จำกัดการเชื่อมต่อ </B></span></a></li>
                <li><a href="#"><span style="font-size: 16px;" class="badge bg-orange"> <?php echo \Webmin::exp_decode($user->expire); ?> </span><span style="font-size: 16px;" class="pull-right badge bg-green"> VPN <?php echo $server->limitvpn; ?> </span></a></li>
                
              </ul>
            </div>
						 
      	   <div class="box-footer text-center"> 
					<a href="<?php echo '/upload/vpn/'.$server->config; ?>" class="btn btn-success"><i class="glyphicon glyphicon-cloud-download"></i> โหลดไฟล์ VPN </a> 
               	<a href="/home/member/server" class="btn btn-warning btn-fill pull-left">ย้อนกลับ</a>
              </div>
          </div>        
        </div>
     
    </div>
       
    </section>
  </div>