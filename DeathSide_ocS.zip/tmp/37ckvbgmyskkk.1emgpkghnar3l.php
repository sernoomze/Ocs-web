
  <div class="content-wrapper">
    <section class="content-header">
      <h1>
 <?php echo $server->servername; ?>
      </h1>
      <ol class="breadcrumb">
        <li><a href="/home"><i class="fa fa-home"></i> Home</a></li>
        <li><a href="/home/member/server">List Server</a></li>
        <li class="active"><?php echo $server->servername; ?></li>
      </ol>
    </section>

    <section class="content">
   <div class="row">
    <div class="col-sm-6 col-md-2 col-lg-6">     
	    <?php if ($message): ?>     
				<div class="alert alert-<?php echo $message['type']; ?> alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
               <i class="icon fa fa-info"></i>
                <?php echo $message['data']; ?>
              </div>
            <?php endif; ?>
       </div>
    <br>
			  
           <div class="col-sm-6 col-md-4 col-lg-3">
                <div class="box box-widget widget-user">
                	<div class="widget-user-header bg-red">
              <h3 class="widget-user-username"> <?php echo $server->servername; ?></b> <?php echo $server->active==1?'':'( เต็ม )'; ?></h3>
              <h4 class="widget-user-desc"><?php echo $server->Exp; ?> วัน   <?php echo $server->price; ?> บาท</h4>
              
            </div>
            <div class="widget-user-image">
              <img class="img-circle" src="/bootstrap/asset/img/ds2.png" alt="User Avatar">
            </div>
 
				 <div class="box-footer no-padding">
      	<div class="description-block"><br><br>
            <span class="description-text"><span style="font-size: 16px;"  class="badge bg-red">รายละเอียด</span></span>
         </div>
         
              <ul class="nav nav-stacked">
                <li><a href="#"><B> เซิร์ฟเวอร์ </B><span class="pull-right"><B> IP HOST </B></span></a></li>
                <li><a href="#"><span style="font-size: 16px;" class="badge bg-aqua"> <?php echo $server->country; ?> </span> <span style="font-size: 16px;" class="pull-right badge bg-purple"><B> แสดงเมื่อเช่าแล้ว </B></span></a></li>
                
                <li><a href="#"><B> PORT </B><span class="pull-right"><B> จำกัดเชื่อมต่อ </B></span></a></li>
                <li><a href="#"><span style="font-size: 16px;" class="badge bg-maroon"> <?php echo $server->dropbear; ?> </span><span style="font-size: 16px;" class="pull-right badge bg-navy"> VPN <?php echo $server->limitvpn; ?> </span></a></li>
                
                <li><a href="#"><B> วันใช้งาน </B><span class="pull-right"><B> จำกัดการเช่า </B></span></a></li>
                <li><a href="#"><span style="font-size: 16px;" class="badge bg-purple"> <?php echo $server->Exp; ?> วัน</span><span style="font-size: 16px;" class="pull-right badge bg-blue"> <?php echo $server->limitacc; ?> บัญชี/เดือน </span></a></li>
                
                <li><a href="#"><B> ราคา </B><span class="pull-right"><B> สถานะเซิร์ฟเวอร์ </B></span></a></li>
                <li><a href="#"><span style="font-size: 16px;" class="badge bg-orange"> <?php echo $server->price; ?> บาท </span><span style="font-size: 16px;" class="pull-right badge bg-green"> <?php echo $server->Status; ?> </span></a></li>
                
              </ul>
            </div>

	<div class="box-footer">
           <center><span class="description-text"><span style="font-size: 16px;"  class="badge bg-red">กำหนดชื่อและรหัสผ่านสำหรับใช้งาน</span></span></center>
         <br>
			<form role="form" action="<?php echo $URI; ?>" method="POST">
					<div class="form-group">
							<label for="user">ชื่อบัญชี</label>
							<input type="text" name="user" class="form-control" minlength="5" placeholder="อย่างน้อย 5 ตัวอักษร" required>
						</div>
						<div class="form-group">
							<label for="pass">รหัสผ่าน </label>
							<input class="form-control" placeholder="อย่างน้อย 5 ตัวอักษร" name="pass" minlength="5" type="text" required>
						</div>
            <div class="form-group">
							 <label for="pass_confirmation">ยืนยันรหัสผ่าน </label>
							<input class="form-control" placeholder="ยืนยันรหัสผ่านอีกครั้ง" name="pass_confirmation" minlength="5" type="text" required>
						 </div>                     
                  <div class="form-group text-center">
									<button class="btn btn-success"><i class="fa fa-mixcloud"></i> ยืนยัน</button>                   
                        <a href="/home/member/server" class="btn btn-warning"><i class="fa fa-home"></i> ย้อนกลับ</a>
																		</div>
    										       </form>
 											   	</div>
							   			 </div>        
		
 						  </div> 
					</div>
 
    </section>
  </div>