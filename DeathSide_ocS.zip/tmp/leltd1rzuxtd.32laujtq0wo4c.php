
 <div class="content-wrapper">
    <section class="content-header">
      <h1>
        <span class="description-text"><span style="font-size: 25px;"  class="badge bg-orange">   ประกาศ และ  กิจกรรม </span></span>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-home"></i> Home</a></li>
        <li class="active">Profile</li>
      </ol>
    </section>

    				<section class="content">
                    <div class="row">        
                        <div class="col-md-12">
                            <div class="nav-tabs-custom">
                                <ul class="nav nav-tabs pull-left">
                                    <li class="active"><a href="#tab_1-1" data-toggle="tab">ประกาศ</a></li>
                                    <li><a href="#tab_2-2" data-toggle="tab">กิจกรรม</a></li>
                                    <li><a href="#tab_3-3" data-toggle="tab">วิธีเติมเงิน</a></li>            
																		                     
                                    <li class="pull-left header"><i class="fa fa-th"></i> กิจกรรมและประกาศต่างๆ</li>												
                                </ul>
                          <div class="tab-content">
                             <div class="tab-pane active" id="tab_1-1">
							<marquee behavior="alternate"><font color=red><h3><b><i class="fa fa-send" class="btn btn-sm bg-dark">SerNooMzE VPN  <i class="fa fa-send"></i></h3></b></font></marquee>
							<font color=black><h3><b>ซิม True ต้องสมัครโปรก่อนนะครับถึงใช้ vpn ได้</i></h3></b></font>                    		
 <span class="description-text"><span style="font-size: 16px;">**สมัคร True ID *900*3956# 9.43 บาท/1วัน  **</span>
<span class="description-text"><span style="font-size: 16px;">**สมัคร True ID *900*3957# 20.33 บาท/7วัน **</span>
<span class="description-text"><span style="font-size: 16px;">**สมัคร True ID *900*3958# 63.13 บาท/30วัน  **</span>
							<font color=black><h3><b>**ความเร็วเน็ตจะอยู่ที่ 3-5MB แต่ดูหนังออนไลน์ youtube สบายๆ  **</i></h3></b></font>                    		
            				<h5>#หมายเหตุ: มีปัญหาด้านการใช้งานหรือด้านอื่นๆ  <b><a href="https://m.me/"> กดตรงนี้</a></b></h5>
                            </div>                               
					 <div class="tab-pane" id="tab_2-2">
              <h3><b>ประกาศ:</b></h3>								
					    	  <h3><b> </b></h3>
								 <h4> <b><a href="https://m.me/"> กดตรงนี้</a></b></h4>								
                                    </div>

					 <div class="tab-pane" id="tab_3-3">
							 <h3><b>วิธีเติมเงินระบบอัติโนมัติ:</b></h3>							 
                                   <div class="carousel-inner">
<div class="box-body">
<div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
<ol class="carousel-indicators">
<li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
<li data-target="#carousel-example-generic" data-slide-to="1" class=""></li>
<li data-target="#carousel-example-generic" data-slide-to="2" class=""></li>
</ol>
<div class="carousel-inner">
<div class="item active">
<img src="bootstrap/asset/vpn/18.png" alt="First slide">
<div class="carousel-caption">
</div>
</div>
<div class="item">
<img src="bootstrap/asset/vpn/19.png" alt="Second slide">
<div class="carousel-caption">
</div>
</div>
<div class="item">
<img src="bootstrap/asset/vpn/20.png" alt="Third slide">
<div class="carousel-caption">
</div>
</div>
</div>
<a class="left carousel-control" href="#carousel-example-generic" data-slide="prev">
<span class="fa fa-angle-left"></span>
</a>
<a class="right carousel-control" href="#carousel-example-generic" data-slide="next">
<span class="fa fa-angle-right"></span>
</a>
</div>
</div>
</div>
</div>
                                </div>
                            </div>
                        </div>
                    </div>
                     
 		<div class="row">
	      <div class="col-md-6 col-md-6 col-xs-12">
			<div class="info-box bg-red">
            <span class="info-box-icon"><i class="fa fa-money"></i></span>
            <div class="info-box-content">
              <span class="info-box-number">ยอดเงิน</span>
			  <span class="info-box-number">คงเหลือที่ใช้ได้ » <span style="font-size: 16px;" class="info-box-number pull-right badge bg-green"><?php echo $me->saldo; ?> บาท</span>
              <div class="progress">
                <div class="progress-bar" style="width: 30%"></div>
                 </div>
                  <span class="progress-description">
				  <button class="btn btn-sm bg-dark"><a href="/home/topups"> เติมเงิน <i class="fa fa-arrow-circle-right"></i></a></button>
                  </span>
            </div>
          </div>
        </div>
		 <div class="col-md-6 col-md-6 col-xs-12">
          <div class="info-box bg-orange">
            <span class="info-box-icon"><i class="fa fa-user-secret"></i></span>
            <div class="info-box-content">
			  <span class="info-box-number">USERNAME ID» <span style="font-size: 16px;" class="info-box-number pull-right badge bg-green"><?php echo $me->username; ?> » <?php echo $me->id; ?></span>
              <span class="info-box-number">Email » <span style="font-size: 16px;" class="info-box-number pull-right badge bg-green"><?php echo $me->email; ?></span>
              <div class="progress">
                <div class="progress-bar" style="width: 70%"></div>
                 </div>
                  <span class="progress-description">
				  <button class="btn btn-sm bg-dark"><a href="/home/setting"> เพิ่มเติม <i class="fa fa-arrow-circle-right"></i></a></button>
                  </span>
   </div>
          </div>
        </div>
		 <div class="col-md-6 col-md-6 col-xs-12">
          <div class="info-box bg-yellow">
            <span class="info-box-icon"><i class="icon fa fa-server"></i></span>
            <div class="info-box-content">
			  <span class="info-box-number">SerNooMzE_TH » <span style="font-size: 16px;" class="info-box-number pull-right badge bg-green">ONLINE</span>
              <span class="info-box-number">SerNooMzE_SG » <span style="font-size: 16px;" class="info-box-number pull-right badge bg-green">ONLINE</span>
  <div class="progress">
                <div class="progress-bar" style="width: 50%"></div>
                 </div>
                  <span class="progress-description">
<button class="btn btn-sm bg-dark"><a href="/home/member/server/"> เช่า VPN <i class="fa fa-arrow-circle-right"></i></a></button>
   </span>
            </div>
          </div>
        </div> 						
    </div> 
    </section>
  </div>           