

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="SerNooMzE VPN">
    <meta name="author" content="SerNooMzE VPN">
    <title>SerNooMzE VPN</title>
    <!-- Bootstrap Core CSS -->
    <link rel="stylesheet" href="/signup/css/bootstrap.min.css" type="text/css">
    <!-- Custom Fonts -->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Merriweather:400,300,300italic,400italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="/signup/font-awesome/css/font-awesome.min.css" type="text/css">
    <!-- Plugin CSS -->
    <link rel="stylesheet" href="/signup/css/animate.min.css" type="text/css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="/signup/css/creative.css" type="text/css">
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
   
    <meta name="msapplication-TileColor" content="#ffffff">
    <meta name="msapplication-TileImage" content="img/favicon/ms-icon-144x144.png">
    <meta name="theme-color" content="#ffffff">
</head>
<body id="page-top">
<nav id="mainNav" class="navbar navbar-dark bg-black navbar-fixed-top">
<div class="container-fluid">
<div class="navbar-header">
<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
<span class="sr-only">Toggle navigation</span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>
</button>
                <a class="navbar-brand page-scroll" href="/">
               </a>
           </div>
</div>
</div>
</nav>


<section id="services" class="bg-black">
         <div class="container">
            <div class="row">
				<div class="text-center">
<i class="fa fa-4x fa fa-user-secret bounceIn text-primary"></i>
<font color=red><h3><b>S e r N o o M z E - V P N</h3></b></font>
                 <div class="text-center">
<font color=white><h3><b>[----- ยินดีต้อนรับ -----] </h3></b></font>
             </div>   
            </div>
        </div>
</div>
</div>
</div>
<div class="container">
<div class="row">
<div class="col-md-4 col-md-offset-4">
<form action="/login" method="post">
<div class="col-md-12">
<div class="panel-body">
<div class="form-group">
<label for="username">ชื่อบัญชี</label>
<input type="text" name="username" placeholder="Username" class="form-control" required>
</div>
<div class="form-group">
<label for="password">รหัส Password</label>
<input type="password" name="password" placeholder="Password" class="form-control" required>
</div>
<div class="form-group">
<button type="submit" name="submit" class="btn bg-red pull-left"><i class="fa fa-lock"></i> เข้าสู่ระบบ </button>
<a href="/signup" class="btn bg-green pull-right"><i class="fa fa-unlock"></i> สมัครสมาชิก </a>
</div>
</div>
<footer class="footer text-center">
<a href="/">SerNooMzE VPN</a> © 2018</strong>
</footer>
<aside class="bg-black" style="padding-top:40px; height:20px">
    <script src="/bootstrap/asset/js-signup/jquery.js"></script>
    <script src="/bootstrap/asset/js-signup/bootstrap.min.js"></script>
    <script src="/bootstrap/asset/js-signup/jquery.easing.min.js"></script>
    <script src="/bootstrap/asset/js-signup/jquery.fittext.js"></script>
    <script src="/bootstrap/asset/js-signup/wow.min.js"></script>
    <script src="/bootstrap/asset/js-signup/creative.js"></script>
</body>
</html>
  <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
</body>
</html>