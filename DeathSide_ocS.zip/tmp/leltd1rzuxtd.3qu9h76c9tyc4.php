  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
	  <span class="description-text"><span style="font-size: 25px;"  class="badge bg-orange">   บัญชีทั้งหมด    </span></span>
      </h1>
      <ol class="breadcrumb">
        <li><a href="/home"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">UserLogin</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
	        <?php if ($message): ?>     
				<div class="alert alert-<?php echo $message['type']; ?> alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
               <i class="icon fa fa-info"></i>
                <?php echo $message['data']; ?>
              </div>
            <?php endif; ?>
   
      <div class="row">
        <div class="col-md-8">
          <div class="box box-primary">
            <div class="box-header">
              <i class="fa fa-group fa-fw"></i><h3 class="box-title">รายชื่อบัญชี</h3>
			  <a href="<?php echo $URI; ?>/add" class="btn btn-info pull-right"><i class="fa fa-plus"></i> เพิ่มบัญชี</a>
            </div>
            <!-- /.box-header -->    
          
            <div class="box-body">
              <table id="fornesia" class="table table-bordered table-hover">
                <thead>
                <tr>
                                    	<th>ตั้งค่า</th>
                                    	<th>ชื่อ</th>
                                    	<th>เครดิต</th>                            
                </tr>
                </thead>
                <tbody>
                                <?php $no=0; foreach (($sellers?:array()) as $seller): $no++; ?>
                                     <tr>
                                        <td> 
     <a href="/home/admin/seller/<?php echo $seller->id; ?>" class="btn btn-info">แก้ไข</a>&nbsp;
                                           
                                        </td>
                                        <td><?php echo $seller->username; ?></td>                                    
                                        <td><?php echo $seller->saldo; ?> <?php if ($seller->active==1): ?>
                                                
<a href="/home/admin/seller/<?php echo $seller->id; ?>/active/0" class="btn btn-primary"> ล็อค </a>
                                                
                                                <?php else: ?>
<a href="/home/admin/seller/<?php echo $seller->id; ?>/active/1" class="btn btn-danger"> ปลด </a>
                                                
                                            <?php endif; ?> 								
                                    </td> 									
                                    </tr>
                                <?php endforeach; ?>                                
                 <tfoot>
                <tr>
                                    	<th>ตั้งค่า</th>
                                    	<th>ชื่อ</th>
                                    	<th>เครดิต</th>                                 	    
                </tr>
                </tfoot>
              </table>               
             </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
		
    
      <div class="col-md-4">		  
         <div class="box box-danger">
            <div class="box-header with-border">
                <i class="fa fa-money fa-fw"></i><h3 class="box-title">เพิ่มเครดิต</h3>
            </div>
            <!-- /.box-header -->  
       
            <form role="form" action="/home/admin/seller/deposit" method="POST">
              <div class="box-body">
                       <div class="form-group">
                            <label>บัญชีที่จะเพิ่ม</label>
                           <select class="form-control" name="id">
                                <?php foreach (($sellers?:array()) as $seller): ?>
                                    <option value="<?php echo $seller->id; ?>"><?php echo $seller->username; ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>จำนวน</label>
                            <div class="input-group">
                                <span class="input-group-addon">เครดิต. </span>
                                <input class="form-control" placeholder="100" name="deposit" type="number" min="10" step="10" required>
                            </div>
                        </div>
              </div>
              <!-- /.box-body -->

              <div class="box-footer">
                <button type="submit" class="btn btn-primary">ยืนยัน</button>
                <button type="reset" class="btn btn-danger">Reset</button>                        
              </div>
              
            </form>
          </div>
          <!-- /.box -->
  </div>

</div>    
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->