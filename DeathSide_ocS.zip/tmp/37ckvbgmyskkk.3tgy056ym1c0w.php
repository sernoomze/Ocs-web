
  <div class="content-wrapper">
    <section class="content-header">
      <h1>
               <span class="description-text"><span style="font-size: 25px;"  class="badge bg-orange"> SERVER OPENVPN </span></span>
      </h1>
    <ol class="breadcrumb">
        <li><a href="/"><i class="fa fa-home"></i> หน้าหลัก</a></li>
        <li class="active">OPENVPN</li>
    </ol>
    </section>
<section class="content">               
      <div class="row">
        <div class="col-md-10">        
          <div class="box box-solid">
            <div class="box-header with-border">
              <h3 class="box-title text-center"><B><p><span class="description-text"><span style="font-size: 15px;"  class="badge bg-orange"> Server TH เหมาะเล่นเกมส์ในประเทศ ปิงน้อย </span></p><p><span class="description-text"><span style="font-size: 14px;"  class="badge bg-green"> Server SG เหมาะเล่นดูหนังออนไลน์ โหลดไฟล์ youtube</span></p></B></h3>
              <div class="box-tools">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                </button>
              </div>
            </div>
            <div class="box-body no-padding">
              <ul class="nav nav-pills nav-stacked">
   <div class="row">
	  <?php if ($message): ?>
		<div class="col-sm-5 col-md-4 col-lg-4">     
		   <div class="alert alert-success alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <h4><i class="icon fa fa-info"></i></h4>
                <?php echo $message['data']; ?>
              </div>
            </div>
            <?php endif; ?>
        
        <?php foreach (($servers?:array()) as $server): ?>
           <div class="col-sm-5 col-md-4 col-lg-4">
                <div class="box box-widget widget-user">
                	<div class="widget-user-header bg-red">
              <h3 class="widget-user-username"><B> <?php echo $server->servername; ?> <span style="font-size: 15px;" class="pull-right badge bg-green"> <?php echo $server->Status; ?> </span><B></h3>
              <h4 class="widget-user-desc"><B><?php echo $server->Exp; ?> วัน   <?php echo $server->price; ?> บาท<B></h4>
              
            </div>
            <div class="widget-user-image">
              <img class="img-circle" src="/bootstrap/asset/img/ds2.png" alt="User Avatar">
            </div>
                          
     <div class="box-footer no-padding">
      	<div class="description-block"><br><br>
            <span class="description-text"><span style="font-size: 16px;"  class="badge bg-red">รายละเอียด</span></span>
         </div>
         
              <ul class="nav nav-stacked">
                <li><a href="#"><B> เซิร์ฟเวอร์ </B><span class="pull-right">IP HOST</span></a></li>
                <li><a href="#"><span style="font-size: 16px;" class="badge bg-aqua"> <?php echo $server->country; ?> </span> <span style="font-size: 16px;" class="pull-right badge bg-purple">แสดงเมื่อเช่าแล้ว</span></a></li>
                
                <li><a href="#"> VPN PORT <span class="pull-right">จำกัดเชื่อมต่อ</span></a></li>
                <li><a href="#"><span style="font-size: 16px;" class="badge bg-maroon"> <?php echo $server->dropbear; ?> </span><span style="font-size: 16px;" class="pull-right badge bg-navy"> VPN <?php echo $server->limitvpn; ?></span></a></li>
                
                <li><a href="#"> วันใช้งาน <span class="pull-right"> จำกัดการเช่า </span></a></li>
                <li><a href="#"><span style="font-size: 16px;" class="badge bg-purple"> <?php echo $server->Exp; ?> วัน</span><span style="font-size: 16px;" class="pull-right badge bg-blue"> <?php echo $server->limitacc; ?> บัญชี/เดือน </span></a></li>
                
                <li><a href="#"> ราคา <span class="pull-right"> สถานะเซิร์ฟเวอร์ </span></a></li>
                <li><a href="#"><span style="font-size: 16px;" class="badge bg-orange"> <?php echo $server->price; ?> บาท </span><span style="font-size: 16px;" class="pull-right badge bg-green"> <?php echo $server->Status; ?> </span></a></li>
                
              </ul>
            </div>
						 
         <div class="box-footer text-center">                
             <button class="btn btn-primary" data-toggle="modal" data-target="#<?php echo $server->id; ?>"><i class="fa fa-mixcloud"></i>
  เช่า VPN					 
           </button>
<a href="<?php echo '/upload/vpn/'.$server->config; ?>" class="btn btn-success"><i class="glyphicon glyphicon-cloud-download"></i> Config </a> 						 
                  </div>

<div class="modal fade" id="<?php echo $server->id; ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 class="modal-title" id="myModalLabel">คำเตือน!!!</h4>
      </div>
       <div class="modal-body">
        <B>การใช้งานความเร็วและความแรงของอินเตอร์เน็ตแต่ละพื้นที่ก็ต่างกันไปถ้าหากเน็ตของลูกค้าช้าหรือมีปันหาอื่นๆ ก่อนที่จะมาแจ้งปัญหากรุณาให้ลูกค้าตรวจสอบปัญหาให้แน่ชัดก่อนว่าเกิดจากอะไรถ้าหากปันหาที่เป็นอยู่เกียวกับพืันที่หรือเครื่องของลูกค้าเองและอื่นๆ ที่ไม่เกียวกับเซิฟร์เวอร์ ทางเราก็ไม่สารถแก้ปันหานั้นได้  ทางเราแก้ได้เฉพาะปัญหาที่เกียวกับเซิฟร์เวอร์ของเราเท่านั้นจะเช่าหรือไม่นั้น ทางเราไม่บังคับ เป็นการตัดสิ้นใจของลูกค้าเองเพราะฉะนั้นถ้าเช่าไปแล้ว จะไม่มีการคืนเงินไม่ว่ากรณีใดๆก็ตาม</B>
      </div>
      <div class="modal-footer">
        <a href="<?php echo $URI.'/'.$server->id; ?>" class="btn btn-info"><i class="glyphicon glyphicon-gift"></i> เลือกเช่า</a>
        <button type="button" class="btn btn-danger btn-simple" data-dismiss="modal">ยกเลิก</button>
      </div>
    </div>
  </div>
</div>

            </div>        
        </div>
   <?php endforeach; ?>
                              
        </div>  
                
              </ul>
            </div>
            </div>
          </div>                       
      </div>                                                 
    </section>
  </div>