
  <div class="content-wrapper">
    <section class="content-header">
      <h1>
        <strong> <?php echo $server->servername; ?></strong>
      </h1>
      <ol class="breadcrumb">
        <li><a href="/home"><i class="fa fa-home"></i> หน้าหลัก</a></li>
        <li><a href="/home/admin/server"><?php echo $server->servername; ?></a></li>
        <li class="active"> เช็คบัญชี </li>
      </ol>
    </section>

    <section class="content">
      <div class="row">
			<div class="col-md-4">
          <div class="box box-widget widget-user">
            <div class="widget-user-header bg-red"center;">
              <h3 class="widget-user-username"><B>เช็ครายละเอียดบัญชีที่เช่า<B></h3>
              <h5 class="widget-user-desc"><?php echo $server->servername; ?></h5>
            </div>
            <div class="widget-user-image">
              <img class="img-circle" src="/bootstrap/asset/img/profile.png" alt="User Avatar">
            </div>
            <div class="box-footer">
              <div class="row">
                <div class="col-sm-5 border-right">
									<center><span class="badge bg-red">ค้นหาชื่อบัญชีของคุณ</span></center>
                   <div class="description-block">
						     		<ul class="nav nav-stacked">
							 <table id="lowclass" class="table table-order-column text-center">
					</div>						 
                <thead>
                <tr>
                  <th>USERNAME</th>
                  <th>วันหมดอายุ</th>
                  <th>สถานะ</th>
                </tr>
                </thead>
						 <tbody>
							<tr>
                   <?php if ($users): ?>
                   
                   <?php $no=0; foreach (($users?:array()) as $user): $no++; ?>
									
                      <td><span class="pull-right badge bg-maroon"> <?php echo $user->user; ?> </span></td>
											<td><span class="pull-right badge bg-purple"> <?php echo $user->exp; ?> </span></td>
									<td>	
									<?php if ($user->lock): ?>
									  
                    <span class="badge bg-red">ล็อค</span>
                    
									  <?php else: ?>
                    <span class="badge bg-green">พร้อมใช้งาน</span>
                    
									 <?php endif; ?>
									</td>
                  </tr>
                                        <?php endforeach; ?>
                                    
                                    <?php else: ?>
                                        <tr>
                                            <td class="text-muted text-center" colspan="6">ไม่มีบัญชีที่คุณค้นหา</td>
                                        </tr>
                                    
																		</tbody>
                                <?php endif; ?>
														</tr>
              					</table>
                      </ul>
                  </div>			
                </div>               

              </div>
            </div>
          </div>
        </div>
      </div>
   
    </section>
  </div>