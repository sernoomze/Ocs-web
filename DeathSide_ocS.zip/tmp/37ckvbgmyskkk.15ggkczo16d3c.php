
  <div class="content-wrapper">
    <section class="content-header">
<h1>
        <span class="description-text"><span style="font-size: 25px;"  class="badge bg-orange">All Config</span></span>
</h1>
<ol class="breadcrumb">
<li><a href="#"><i class="fa fa-home"></i> Home</a></li>
<li class="active">config</li>
</ol>
</section>
<section class="content">
<div class="row">
<div class="col-md-6">
<div class="box box-solid box-primary">
<div class="box-header text-center">
<i class="fa fa-cog fa-spin"></i> <label style="width: 250px;">Bangmod</label>
<div class="box-tools pull-right">
<button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
</div>
</div>
<div class="box-body">
<table class="table">
<center>
<tr>
<td><span class="label label-success">Pro Sim</span></td><td><span class="label label-warning"> AIS </span></td>
</tr>
<tr>
<td><b> Easy 64k </b></td><td><b><a href="/upload/vpn/Bangmod.ovpn" class="btn btn-success"><i class="fa fa-cloud-download"></i> กด</a><b></td>
</tr>
<tr>
<td><b> Ais Play </b></td><td><b><a href="/upload/vpn/Bangmod.ovpn" class="btn btn-danger"><i class="fa fa-cloud-download"></i> กด</a><b></td>
</tr>
<tr>
</tr>
</center>
</table>
</div>
</div>
</div>
</div>
</section>
</div>