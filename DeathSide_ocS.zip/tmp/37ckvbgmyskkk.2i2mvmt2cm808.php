<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>DeathSide VPN</title>
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
<link rel="stylesheet" href="/bootstrap/plugins/datatables/dataTables.bootstrap.css">	 
<link rel="stylesheet" href="/bootstrap/asset/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">  
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
 <link rel="stylesheet" href="/bootstrap/asset/dist/css/AdminLTE.min.css">
 <link rel="stylesheet" href="/bootstrap/asset/dist/css/skins/_all-skins.min.css">
 <link href="/bootstrap/asset/css/bootstrap-dialog.min.css" rel="stylesheet">
 <link href="/bootstrap/asset/css/animate.min.css" rel="stylesheet"/>

  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>

  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->
 <style>
    .example-modal .modal {
      position: relative;
      top: auto;
      bottom: auto;
      right: auto;
      left: auto;
      display: block;
      z-index: 1;
    }

    .example-modal .modal {
      background: transparent !important;
    }
  </style>
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Merriweather:400,300,300italic,400italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="/bootstrap/asset/css/font-awesome/css/font-awesome.min.css" type="text/css">
    <!-- Plugin CSS -->
    <link rel="stylesheet" href="/bootstrap/asset/css/animate.min.css" type="text/css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="/bootstrap/asset/css/creativ.css" type="text/css">
	 
</head>
<body class="hold-transition skin-blue-light fixed sidebar-mini">

    <?php echo $this->render($content,$this->mime,get_defined_vars()); ?>

<script src="/bootstrap/plugins/jQuery/jquery-2.2.3.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/metisMenu/2.0.0/metisMenu.min.js"></script>
<link rel="stylesheet" href="/bootstrap/plugins/daterangepicker/daterangepicker.css">
<link rel="stylesheet" href="/bootstrap/plugins/datepicker/datepicker3.css">
<script src="/bootstrap/asset/js/bootstrap.min.js"></script>
<script src="/bootstrap/plugins/slimScroll/jquery.slimscroll.min.js"></script>
<script src="/bootstrap/plugins/fastclick/fastclick.js"></script>
<script src="/bootstrap/asset/dist/js/app.min.js"></script>
<script src="/bootstrap/plugins/datatables/jquery.dataTables.min.js"></script>
<script src="/bootstrap/plugins/datatables/dataTables.bootstrap.min.js"></script>

<script>
  $(function () {
    $('#lowclass').DataTable({
	  	"aLengthMenu": [[1, -1]],
      "paging": true,
      "lengthChange": false,
      "searching": true,
      "ordering": false,
      "info": true,
      "autoWidth": false,
    });
  });
</script>

<script>
  $(function () {
    $('#fornesia').DataTable({
      "paging": true,
      "lengthChange": true,
      "searching": true,
      "ordering": true,
      "info": true,
      "autoWidth": false,
    });
  });
</script>
  <script src="/bootstrap/plugins/datepicker/bootstrap-datepicker.js"></script>
    <script src="/bootstrap/asset/js/bootstrap-dialog.min.js"></script>
    <script type="text/javascript">
        $('.input-group.date').datepicker({
            format: "yyyy/mm/dd",
            weekStart: 1,
            clearBtn: true,
            language: "th",
            autoclose: true,
            todayHighlight: true
        });
        $('.hapus').click(function(e) {
            e.preventDefault();
            BootstrapDialog.confirm({
                title: 'Confirm',
                message: ' Are you sure?',
                type: BootstrapDialog.TYPE_DANGER,
                closable: true,
                btnCancelLabel: 'Cancel',
                btnOKLabel: 'Delete',
                btnOKClass: 'btn-danger',
                callback: function(result) {
                    if(result) {
                        location.href = $('.hapus').attr('href');
                    }
                }
            });
        });
        function print_report() {
            window.print();
            return false;
        }
    </script>
    
</body>
</html>