
  <div class="content-wrapper">
    <section class="content-header">
      <h1>
        <span class="description-text"><span style="font-size: 25px;"  class="badge bg-orange">เช็คสถานะและวันหมดอายุ</span></span>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-home"></i> Home</a></li>
        <li class="active">userstatus</li>
      </ol>
    </section>

    <section class="content">               
      <div class="row">
        <div class="col-md-10">        
          <div class="box box-solid">
            <div class="box-header with-border">
              <h3 class="box-title text-center"> <B>เช็คสถานะบัญชี </B></h3>
              <div class="box-tools">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                </button>
              </div>
            </div>
            <div class="box-body no-padding">
              <ul class="nav nav-pills nav-stacked">
                <li><a href="/home/member/server/check/8"><i class="fa fa-mixcloud"></i> <B> SerNooMzE.TH </B>
                <span class="badge bg-primary pull-right"> เช็คบัญชี </span></a></li>
				<li><a href="/home/member/server/check/7"><i class="fa fa-mixcloud"></i> <B> SerNooMzE.SG </B>
                <span class="badge bg-primary pull-right"> เช็คบัญชี </span></a></li>

                
              </ul>
            </div>
            </div>
          </div>                       
      </div>
    </section>
</div>