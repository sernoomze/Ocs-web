  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
       รายชื่อบัญชี
        <strong>๏ <?php echo $server->servername; ?></strong>
      </h1>
      <ol class="breadcrumb">
        <li><a href="/home"><i class="fa fa-dashboard"></i> หน้าหลัก</a></li>
        <li><a href="/home/admin/server">All-Server</a></li>
        <li class="active"> รายชื่อบัญชี </li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box box-primary">
            <div class="box-header">
              <i class="fa fa-group fa-fw"></i><h3 class="box-title">บัญชีทั้งหมดในเซิฟเวอร์</h3>
			  <a href="<?php echo $URI; ?>/add" class="btn btn-info pull-right"><i class="fa fa-plus"></i> สร้างบัญชี</a>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
					 <table id="fornesia" class="table table-order-column">
                                    
                <thead>
                <tr>
                  <th>User</th>
                  <th>คนสมัคร</th>
                  <th>วันหมด</th>
                  <th>ตั้งค่า</th>
                </tr>
                </thead>
                <tbody>
                                <?php if ($users): ?>
                                    
                                        <?php $no=0; foreach (($users?:array()) as $user): $no++; ?>
                <tr>
                  <td><?php echo $user->user; ?></td>
                  <td><?php echo $user->real; ?></td>
                  <td><?php echo $user->exp; ?></td>
                  <td>
                  <a href="<?php echo $URI.'/'.$user->uid; ?>" class="btn btn-info">แก้ไข</a>
                   <?php if ($user->lock): ?>
                    
                    <a href="<?php echo $URI.'/'.$user->uid; ?>/active/1" class="btn btn-success">ปลด</a>
                     
                    <?php else: ?>
                    <a href="<?php echo $URI.'/'.$user->uid; ?>/active/0" class="btn btn-warning">ล็อค</a>
                    
                     <?php endif; ?>
            				 <a href="<?php echo $URI.'/'.$user->uid; ?>/delete" class="btn btn-danger">ลบ</a>
                     </td>
                     </tr>
                     <?php endforeach; ?>
                                    
                                    <?php else: ?>
                                        <tr>
                                            <td class="text-muted text-center" colspan="6">User Not available</td>
                                        </tr>
                                    

                                <?php endif; ?>
              					</table>
           			 </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    

    
    
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->